
<?php
require_once __DIR__ . "/../config/securite.php";

// Supprimer les données de la session.
$_SESSION = [];

// Supprimer également le cookie de session du navigateur.
if (ini_get("session.use_cookies")) {
    $parametres = session_get_cookie_params();

    setcookie(
        session_name(),
        "",
        time() - 42000,
        $parametres["path"],
        $parametres["domain"],
        $parametres["secure"],
        $parametres["httponly"]
    );
}

// Détruire la session.
session_destroy();

// Retourner à la page de connexion.
header("Location: /journal-caisse/admin/connexion.php");
exit;
