
<?php
// ======================================================
// 1. CHARGEMENT DES FICHIERS ET SÉCURISATION
// ======================================================

// Charger les fonctions de sécurité, la connexion PDO et les fonctions communes.
require_once __DIR__ . "/../../config/authentification.php";
require_once __DIR__ . "/../../config/connexion.php";
require_once __DIR__ . "/../../includes/fonctions.php";

// Vérifier que l'administrateur est bien connecté.
exiger_connexion();

// Initialiser les messages destinés à l'administrateur.
$message = "";
$erreur = "";


// ======================================================
// 2. RÉCUPÉRATION DES INFORMATIONS DE L'ADMINISTRATEUR
// ======================================================

// Rechercher les informations du compte connecté dans la base de données.
$requete = $pdo->prepare(
    "SELECT id, nom, identifiant, mot_de_passe, date_creation
     FROM administrateur
     WHERE id = :id
     LIMIT 1"
);

$requete->execute([
    "id" => $_SESSION["administrateur_id"]
]);

$administrateur = $requete->fetch();

// Vérifier que le compte administrateur existe toujours.
if (!$administrateur) {

    // Supprimer les informations de la session.
    $_SESSION = [];

    // Détruire la session actuelle.
    session_destroy();

    // Rediriger vers la page de connexion.
    header("Location: /journal-caisse/admin/connexion.php");
    exit;
}


// ======================================================
// 3. TRAITEMENT DES FORMULAIRES
// ======================================================

// Vérifier si un formulaire a été envoyé.
if ($_SERVER["REQUEST_METHOD"] === "POST") {

    // Vérifier la validité du jeton CSRF.
    csrf_verifier();

    // Identifier le formulaire qui a été soumis.
    $action = $_POST["action"] ?? "";


    // ==================================================
    // A. MODIFICATION DU NOM ET DE L'IDENTIFIANT
    // ==================================================

    if ($action === "modifier_informations") {

        // Récupérer les valeurs envoyées par le formulaire.
        $nom = trim($_POST["nom"] ?? "");
        $identifiant = trim($_POST["identifiant"] ?? "");

        // Calculer la longueur des champs en caractères.
        $longueurNom = function_exists("mb_strlen")
            ? mb_strlen($nom, "UTF-8")
            : strlen($nom);

        $longueurIdentifiant = function_exists("mb_strlen")
            ? mb_strlen($identifiant, "UTF-8")
            : strlen($identifiant);

        // Vérifier que les deux champs sont renseignés.
        if ($nom === "" || $identifiant === "") {

            $erreur = "Tous les champs sont obligatoires.";

        } elseif ($longueurNom > 100 || $longueurIdentifiant > 100) {

            $erreur = "Le nom et l'identifiant ne doivent pas dépasser 100 caractères.";

        } else {

            // Vérifier si l'identifiant est déjà utilisé par un autre compte.
            $verification = $pdo->prepare(
                "SELECT id
                 FROM administrateur
                 WHERE identifiant = :identifiant
                 AND id != :id
                 LIMIT 1"
            );

            $verification->execute([
                "identifiant" => $identifiant,
                "id" => $administrateur["id"]
            ]);

            if ($verification->fetch()) {

                // Refuser un identifiant déjà utilisé.
                $erreur = "Cet identifiant est déjà utilisé.";

            } else {

                // Mettre à jour le nom et l'identifiant dans la base.
                $miseAJour = $pdo->prepare(
                    "UPDATE administrateur
                     SET nom = :nom,
                         identifiant = :identifiant
                     WHERE id = :id"
                );

                $miseAJour->execute([
                    "nom" => $nom,
                    "identifiant" => $identifiant,
                    "id" => $administrateur["id"]
                ]);

                // Actualiser le nom dans la session.
                $_SESSION["administrateur_nom"] = $nom;

                // Actualiser les informations affichées sur la page.
                $administrateur["nom"] = $nom;
                $administrateur["identifiant"] = $identifiant;

                $message = "Vos informations ont été modifiées avec succès.";
            }
        }
    }


    // ==================================================
    // B. MODIFICATION DU MOT DE PASSE
    // ==================================================

    elseif ($action === "modifier_mot_de_passe") {

        // Récupérer les trois mots de passe saisis.
        $ancienMotDePasse = $_POST["ancien_mot_de_passe"] ?? "";
        $nouveauMotDePasse = $_POST["nouveau_mot_de_passe"] ?? "";
        $confirmation = $_POST["confirmation_mot_de_passe"] ?? "";

        // Vérifier que les trois champs sont renseignés.
        if (
            $ancienMotDePasse === ""
            || $nouveauMotDePasse === ""
            || $confirmation === ""
        ) {

            $erreur = "Veuillez remplir tous les champs du mot de passe.";

        } elseif (
            (function_exists("mb_strlen")
                ? mb_strlen($nouveauMotDePasse, "UTF-8")
                : strlen($nouveauMotDePasse)) < 12
        ) {

            // Imposer une longueur minimale de 12 caractères.
            $erreur = "Le nouveau mot de passe doit contenir au moins 12 caractères.";

        } elseif (strlen($nouveauMotDePasse) > 72) {

            // Éviter une troncature avec l'algorithme bcrypt utilisé par certaines versions de PHP.
            $erreur = "Le nouveau mot de passe est trop long. Réduisez sa longueur.";

        } elseif ($nouveauMotDePasse !== $confirmation) {

            // Vérifier que les deux nouveaux mots de passe correspondent.
            $erreur = "Les deux nouveaux mots de passe ne correspondent pas.";

        } elseif ($ancienMotDePasse === $nouveauMotDePasse) {

            $erreur = "Le nouveau mot de passe doit être différent de l'ancien.";

        } else {

            // Vérifier une nouvelle fois le mot de passe actuel dans la base.
            $verification = $pdo->prepare(
                "SELECT mot_de_passe
                 FROM administrateur
                 WHERE id = :id
                 LIMIT 1"
            );

            $verification->execute([
                "id" => $administrateur["id"]
            ]);

            $compte = $verification->fetch();

            // Comparer l'ancien mot de passe avec son empreinte enregistrée.
            if (
                !$compte
                || !password_verify(
                    $ancienMotDePasse,
                    $compte["mot_de_passe"]
                )
            ) {

                $erreur = "L'ancien mot de passe est incorrect.";

            } else {

                // Générer une empreinte sécurisée du nouveau mot de passe.
                $nouveauHash = password_hash(
                    $nouveauMotDePasse,
                    PASSWORD_DEFAULT
                );

                // Enregistrer le nouveau mot de passe dans la base de données.
                $miseAJour = $pdo->prepare(
                    "UPDATE administrateur
                     SET mot_de_passe = :mot_de_passe
                     WHERE id = :id"
                );

                $miseAJour->execute([
                    "mot_de_passe" => $nouveauHash,
                    "id" => $administrateur["id"]
                ]);

                // Renouveler l'identifiant de session après cette opération sensible.
                session_regenerate_id(true);

                // Générer un nouveau jeton CSRF.
                $_SESSION["csrf_token"] = bin2hex(random_bytes(32));

                $message = "Votre mot de passe a été modifié avec succès.";
            }
        }
    }

    // Refuser toute action qui ne correspond à aucun formulaire connu.
    else {

        $erreur = "Action non reconnue.";
    }
}


// ======================================================
// 4. CHARGEMENT DE L'INTERFACE
// ======================================================

// Fermer le bloc PHP avant de commencer l'affichage HTML.
?>

<?php require_once __DIR__ . "/../../includes/header.php"; ?>
<?php require_once __DIR__ . "/../../includes/sidebar.php"; ?>

<main class="main-content">

    <!-- En-tête de la page -->
    <div class="page-header">
        <div>
            <h1>Mon compte administrateur</h1>
            <p>Gérez vos informations personnelles et la sécurité de votre compte.</p>
        </div>
    </div>

    <div class="dashboard-grid">

        <!-- ==========================================
             FORMULAIRE DE MODIFICATION DES INFORMATIONS
        =========================================== -->

        <section class="dashboard-card">

            <h2>Modifier mes informations</h2>

            <!-- Afficher le message de réussite ou d'erreur -->
            <?php if ($message !== ""): ?>
                <div class="message-success">
                    <?= e($message) ?>
                </div>
            <?php endif; ?>

            <?php if ($erreur !== ""): ?>
                <div class="message-erreur">
                    <?= e($erreur) ?>
                </div>
            <?php endif; ?>

            <form method="POST" action="">

                <!-- Jeton de sécurité contre les requêtes CSRF -->
                <input
                    type="hidden"
                    name="csrf_token"
                    value="<?= e(csrf_token()) ?>"
                >

                <!-- Indiquer au traitement quel formulaire a été envoyé -->
                <input
                    type="hidden"
                    name="action"
                    value="modifier_informations"
                >

                <div class="form-group">
                    <label for="nom">Nom de l'administrateur</label>

                    <input
                        type="text"
                        id="nom"
                        name="nom"
                        maxlength="100"
                        value="<?= e(
                            $_POST["action"] ?? "" === "modifier_informations"
                                ? ($_POST["nom"] ?? "")
                                : $administrateur["nom"]
                        ) ?>"
                        required
                    >
                </div>

                <div class="form-group">
                    <label for="identifiant">Identifiant de connexion</label>

                    <input
                        type="text"
                        id="identifiant"
                        name="identifiant"
                        maxlength="100"
                        value="<?= e(
                            ($_POST["action"] ?? "") === "modifier_informations"
                                ? ($_POST["identifiant"] ?? "")
                                : $administrateur["identifiant"]
                        ) ?>"
                        autocomplete="username"
                        required
                    >
                </div>

                <button type="submit" class="btn-primary">
                    Enregistrer les modifications
                </button>

            </form>

            <hr>

            <!-- Informations générales du compte -->
            <h3>Informations du compte</h3>

            <p>
                <strong>Date de création :</strong>
                <?= e(
                    date(
                        "d/m/Y",
                        strtotime($administrateur["date_creation"])
                    )
                ) ?>
            </p>

        </section>


        <!-- ==========================================
             FORMULAIRE DE MODIFICATION DU MOT DE PASSE
        =========================================== -->

        <section class="dashboard-card">

            <h2>Sécurité du compte</h2>

            <p>Modifiez régulièrement votre mot de passe pour protéger votre compte.</p>

            <form method="POST" action="">

                <!-- Jeton CSRF pour protéger ce formulaire également -->
                <input
                    type="hidden"
                    name="csrf_token"
                    value="<?= e(csrf_token()) ?>"
                >

                <!-- Identifier le formulaire de changement de mot de passe -->
                <input
                    type="hidden"
                    name="action"
                    value="modifier_mot_de_passe"
                >

                <div class="form-group">
                    <label for="ancien_mot_de_passe">
                        Ancien mot de passe
                    </label>

                    <input
                        type="password"
                        id="ancien_mot_de_passe"
                        name="ancien_mot_de_passe"
                        autocomplete="current-password"
                        required
                    >
                </div>

                <div class="form-group">
                    <label for="nouveau_mot_de_passe">
                        Nouveau mot de passe
                    </label>

                    <input
                        type="password"
                        id="nouveau_mot_de_passe"
                        name="nouveau_mot_de_passe"
                        minlength="12"
                        autocomplete="new-password"
                        required
                    >

                    <small>Minimum 12 caractères.</small>
                </div>

                <div class="form-group">
                    <label for="confirmation_mot_de_passe">
                        Confirmer le nouveau mot de passe
                    </label>

                    <input
                        type="password"
                        id="confirmation_mot_de_passe"
                        name="confirmation_mot_de_passe"
                        minlength="12"
                        autocomplete="new-password"
                        required
                    >
                </div>

                <button type="submit" class="btn-primary">
                    Modifier mon mot de passe
                </button>

            </form>

        </section>

    </div>

</main>

<?php require_once __DIR__ . "/../../includes/footer.php"; ?>
