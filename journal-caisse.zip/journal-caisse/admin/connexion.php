
<?php

// Charger les fichiers nécessaires à la connexion.
require_once __DIR__ . "/../config/securite.php";
require_once __DIR__ . "/../config/connexion.php";
require_once __DIR__ . "/../includes/fonctions.php";
require_once __DIR__ . "/../config/authentification.php";

// Si un administrateur est déjà connecté,
// le rediriger vers le tableau de bord.
if (administrateur_connecte()) {
    header("Location: /journal-caisse/index.php");
    exit;
}

$erreur = "";

// Traitement du formulaire de connexion.
if ($_SERVER["REQUEST_METHOD"] === "POST") {

    // Vérifier la protection CSRF du formulaire.
    csrf_verifier();

    $identifiant = trim($_POST["identifiant"] ?? "");
    $motDePasse = $_POST["mot_de_passe"] ?? "";

    // Vérifier que les champs sont renseignés.
    if ($identifiant === "" || $motDePasse === "") {

        $erreur = "Veuillez renseigner tous les champs.";

    } else {

        // Rechercher le compte avec son rôle et son statut.
        $requete = $pdo->prepare(
            "SELECT
                id,
                nom,
                identifiant,
                mot_de_passe,
                role,
                statut
             FROM administrateur
             WHERE identifiant = :identifiant
             LIMIT 1"
        );

        $requete->execute([
            "identifiant" => $identifiant
        ]);

        $administrateur = $requete->fetch();

        // Vérifier l'identifiant et le mot de passe.
        if (
            $administrateur
            && password_verify(
                $motDePasse,
                $administrateur["mot_de_passe"]
            )
        ) {

            // Vérifier si le compte est actif.
            if ($administrateur["statut"] !== "actif") {

                $erreur = "Identifiant ou mot de passe incorrect.";

            } else {

                // Vérifier que le rôle est autorisé.
                if (
                    !in_array(
                        $administrateur["role"],
                        ["principal", "secondaire"],
                        true
                    )
                ) {
                    $erreur = "Identifiant ou mot de passe incorrect.";

                } else {

                    // Renouveler l'identifiant de session.
                    session_regenerate_id(true);

                    // Enregistrer les informations de l'administrateur.
                    $_SESSION["administrateur_id"] =
                        (int) $administrateur["id"];

                    $_SESSION["administrateur_nom"] =
                        $administrateur["nom"];

                    $_SESSION["administrateur_role"] =
                        $administrateur["role"];

                    // Créer un nouveau jeton CSRF.
                    $_SESSION["csrf_token"] =
                        bin2hex(random_bytes(32));

                    // Rediriger vers le tableau de bord.
                    header("Location: /journal-caisse/index.php");
                    exit;
                }
            }

        } else {

            // Message générique pour ne pas révéler
            // si l'identifiant ou le mot de passe est incorrect.
            $erreur = "Identifiant ou mot de passe incorrect.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Connexion administrateur</title>

    <link
        rel="stylesheet"
        href="/journal-caisse/assets/css/style.css"
    >
</head>

<body>

    <div class="connexion-container">

        <div class="connexion-card">

            <h1>Journal de caisse</h1>

            <p>Connexion administrateur</p>

            <?php if ($erreur !== ""): ?>

                <div class="message-erreur">
                    <?= e($erreur) ?>
                </div>

            <?php endif; ?>

            <form method="POST" action="">

                <!-- Protection CSRF du formulaire. -->
                <input
                    type="hidden"
                    name="csrf_token"
                    value="<?= e(csrf_token()) ?>"
                >

                <div class="form-group">

                    <label for="identifiant">
                        Identifiant
                    </label>

                    <input
                        type="text"
                        id="identifiant"
                        name="identifiant"
                        required
                        autocomplete="username"
                    >

                </div>

                <div class="form-group">

                    <label for="mot_de_passe">
                        Mot de passe
                    </label>

                    <input
                        type="password"
                        id="mot_de_passe"
                        name="mot_de_passe"
                        required
                        autocomplete="current-password"
                    >

                </div>

                <button type="submit" class="btn-primary">
                    Se connecter
                </button>

            </form>

        </div>

    </div>

</body>

</html>
