
<?php
// Gestion de la modification d'un administrateur secondaire.

require_once __DIR__ . "/../../config/authentification.php";
require_once __DIR__ . "/../../config/connexion.php";
require_once __DIR__ . "/../../includes/fonctions.php";

// Seul l'administrateur principal peut modifier un compte.
exiger_administrateur_principal();

// Vérifier l'identifiant transmis dans l'URL.
$id = filter_input(INPUT_GET, "id", FILTER_VALIDATE_INT);

if (!$id || $id <= 0) {
    exit("Identifiant invalide.");
}

// Récupérer les informations de l'administrateur.
$requete = $pdo->prepare("
    SELECT id, nom, identifiant, role, statut
    FROM administrateur
    WHERE id = :id
    LIMIT 1
");
$requete->execute(["id" => $id]);

$administrateur = $requete->fetch();

if (!$administrateur) {
    exit("Administrateur introuvable.");
}

// Empêcher la modification du compte principal.
if ($administrateur["role"] !== "secondaire") {
    exit("Le compte principal ne peut pas être modifié depuis cette page.");
}

$erreur = "";
$succes = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    // Vérifier le jeton de sécurité CSRF.
    csrf_verifier();

    $nom = trim($_POST["nom"] ?? "");
    $identifiant = trim($_POST["identifiant"] ?? "");

    // Vérifier les champs.
    if ($nom === "" || $identifiant === "") {
        $erreur = "Tous les champs sont obligatoires.";
    } elseif (strlen($nom) > 100 || strlen($identifiant) > 100) {
        $erreur = "Le nom et l'identifiant ne doivent pas dépasser 100 caractères.";
    } else {

        // Vérifier que l'identifiant n'est pas déjà utilisé
        // par un autre administrateur.
        $verification = $pdo->prepare("
            SELECT id
            FROM administrateur
            WHERE identifiant = :identifiant
            AND id != :id
            LIMIT 1
        ");

        $verification->execute([
            "identifiant" => $identifiant,
            "id" => $id
        ]);

        if ($verification->fetch()) {
            $erreur = "Cet identifiant est déjà utilisé.";
        } else {

            // Mettre à jour les informations du compte.
            $miseAJour = $pdo->prepare("
                UPDATE administrateur
                SET nom = :nom,
                    identifiant = :identifiant
                WHERE id = :id
                AND role = 'secondaire'
            ");

            try {
                $miseAJour->execute([
                    "nom" => $nom,
                    "identifiant" => $identifiant,
                    "id" => $id
                ]);

                // Renouveler le jeton CSRF après l'opération.
                $_SESSION["csrf_token"] = bin2hex(random_bytes(32));

                header("Location: index.php");
                exit;

            } catch (PDOException $e) {
                error_log($e->getMessage());
                $erreur = "Une erreur est survenue lors de la modification.";
            }
        }
    }

    // Conserver les valeurs saisies en cas d'erreur.
    $administrateur["nom"] = $nom;
    $administrateur["identifiant"] = $identifiant;
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Modifier un administrateur</title>

    <link rel="stylesheet" href="../../assets/css/style.css">
</head>

<body>

    <main class="container">

        <h1>Modifier un administrateur</h1>

        <?php if ($erreur !== ""): ?>
            <p style="color: red;">
                <?= e($erreur) ?>
            </p>
        <?php endif; ?>

        <form method="POST">

            <input
                type="hidden"
                name="csrf_token"
                value="<?= e(csrf_token()) ?>"
            >

            <div>
                <label for="nom">Nom de l'administrateur</label>

                <input
                    type="text"
                    id="nom"
                    name="nom"
                    maxlength="100"
                    value="<?= e($administrateur["nom"]) ?>"
                    required
                >
            </div>

            <div>
                <label for="identifiant">Identifiant de connexion</label>

                <input
                    type="text"
                    id="identifiant"
                    name="identifiant"
                    maxlength="100"
                    value="<?= e($administrateur["identifiant"]) ?>"
                    required
                >
            </div>

            <button type="submit">Enregistrer les modifications</button>

        </form>

        <p>
            <a href="index.php">Retour à la liste des administrateurs</a>
        </p>

    </main>

</body>
</html>
