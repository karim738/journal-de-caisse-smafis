
<?php
// Ce fichier permet à l'administrateur principal
// d'activer ou de désactiver un administrateur secondaire.

require_once __DIR__ . "/../../config/authentification.php";
require_once __DIR__ . "/../../config/connexion.php";
require_once __DIR__ . "/../../includes/fonctions.php";

// Seul l'administrateur principal peut effectuer cette action.
exiger_administrateur_principal();

// Cette opération doit obligatoirement être envoyée par POST.
if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    http_response_code(405);
    exit("Méthode non autorisée.");
}

// Vérifier le jeton CSRF.
csrf_verifier();

// Récupérer et vérifier les données envoyées.
$id = filter_input(INPUT_POST, "id", FILTER_VALIDATE_INT);
$action = $_POST["action"] ?? "";

if (!$id || $id <= 0) {
    exit("Identifiant invalide.");
}

if (!in_array($action, ["activer", "desactiver"], true)) {
    exit("Action invalide.");
}

// Vérifier que le compte existe et qu'il est secondaire.
$requete = $pdo->prepare("
    SELECT id, role, statut
    FROM administrateur
    WHERE id = :id
    LIMIT 1
");

$requete->execute(["id" => $id]);
$administrateur = $requete->fetch();

if (!$administrateur) {
    exit("Administrateur introuvable.");
}

// Le compte principal ne peut pas être modifié ici.
if ($administrateur["role"] !== "secondaire") {
    http_response_code(403);
    exit("Le compte principal ne peut pas être modifié ici.");
}

// Déterminer le nouveau statut.
$nouveauStatut = ($action === "activer") ? "actif" : "inactif";

try {
    $miseAJour = $pdo->prepare("
        UPDATE administrateur
        SET statut = :statut
        WHERE id = :id
        AND role = 'secondaire'
    ");

    $miseAJour->execute([
        "statut" => $nouveauStatut,
        "id" => $id
    ]);

    // Renouveler le jeton CSRF.
    $_SESSION["csrf_token"] = bin2hex(random_bytes(32));

    header("Location: index.php");
    exit;

} catch (PDOException $e) {
    error_log($e->getMessage());

    http_response_code(500);
    exit("Une erreur est survenue lors de la modification du statut.");
}
