
<?php

// Charger les fichiers nécessaires.
require_once __DIR__ . "/../../config/authentification.php";
require_once __DIR__ . "/../../config/connexion.php";
require_once __DIR__ . "/../../includes/fonctions.php";

// Réserver cette page à l'administrateur principal.
exiger_administrateur_principal();

// Récupérer tous les comptes administrateurs.
$requete = $pdo->query(
    "SELECT
        id,
        nom,
        identifiant,
        role,
        statut,
        date_creation
     FROM administrateur
     ORDER BY
        CASE
            WHEN role = 'principal' THEN 0
            ELSE 1
        END,
        nom ASC"
);

$administrateurs = $requete->fetchAll();

?>

<!DOCTYPE html>
<html lang="fr">

<head>

    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Gestion des administrateurs</title>

    <link
        rel="stylesheet"
        href="/journal-caisse/assets/css/style.css"
    >

</head>

<body>

    <div class="container">

        <h1>Gestion des administrateurs</h1>

        <p>
            Consultez et gérez les comptes des administrateurs
            de votre application.
        </p>

        <p>
            <a href="creer.php">
                Ajouter un administrateur
            </a>
        </p>

        <div class="table-responsive">

            <table>

                <thead>

                    <tr>
                        <th>ID</th>
                        <th>Nom</th>
                        <th>Identifiant</th>
                        <th>Rôle</th>
                        <th>Statut</th>
                        <th>Date de création</th>
                        <th>Actions</th>
                    </tr>

                </thead>

                <tbody>

                    <?php if (count($administrateurs) > 0): ?>

                        <?php foreach ($administrateurs as $administrateur): ?>

                            <tr>

                                <td>
                                    <?= e($administrateur["id"]) ?>
                                </td>

                                <td>
                                    <?= e($administrateur["nom"]) ?>
                                </td>

                                <td>
                                    <?= e($administrateur["identifiant"]) ?>
                                </td>

                                <td>

                                    <?php if ($administrateur["role"] === "principal"): ?>

                                        Administrateur principal

                                    <?php else: ?>

                                        Administrateur secondaire

                                    <?php endif; ?>

                                </td>

                                <td>

                                    <?php if ($administrateur["statut"] === "actif"): ?>

                                        Actif

                                    <?php else: ?>

                                        Inactif

                                    <?php endif; ?>

                                </td>

                                <td>
                                    <?= e($administrateur["date_creation"]) ?>
                                </td>

                                <td>

                                    <?php if ($administrateur["role"] === "secondaire"): ?>

                                        <!-- Modifier les informations du compte. -->
                                        <a
                                            class="admin-action-icon admin-action-edit"
                                            href="modifier.php?id=<?= (int) $administrateur["id"] ?>"
                                            aria-label="Modifier le compte de <?= e($administrateur["nom"]) ?>"
                                            title="Modifier"
                                        >
                                            <svg viewBox="0 0 24 24" aria-hidden="true" focusable="false">
                                                <path d="M12 20h9"></path>
                                                <path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L8 18l-4 1 1-4Z"></path>
                                            </svg>
                                        </a>

                                        <?php if ($administrateur["statut"] === "actif"): ?>

                                            <!-- Désactiver le compte secondaire. -->
                                            <form
                                                method="POST"
                                                action="statut.php"
                                                onsubmit="return confirm('Désactiver ce compte ?');"
                                            >

                                                <input
                                                    type="hidden"
                                                    name="csrf_token"
                                                    value="<?= e(csrf_token()) ?>"
                                                >

                                                <input
                                                    type="hidden"
                                                    name="id"
                                                    value="<?= (int) $administrateur["id"] ?>"
                                                >

                                                <input
                                                    type="hidden"
                                                    name="action"
                                                    value="desactiver"
                                                >

                                                <button
                                                    type="submit"
                                                    class="admin-action-icon admin-action-status"
                                                    aria-label="Désactiver le compte de <?= e($administrateur["nom"]) ?>"
                                                    title="Désactiver"
                                                >
                                                    <svg viewBox="0 0 24 24" aria-hidden="true" focusable="false">
                                                        <path d="M12 2v10"></path>
                                                        <path d="M5.2 5.2a9 9 0 1 0 13.6 0"></path>
                                                    </svg>
                                                </button>

                                            </form>

                                        <?php else: ?>

                                            <!-- Activer le compte secondaire. -->
                                            <form
                                                method="POST"
                                                action="statut.php"
                                                onsubmit="return confirm('Activer ce compte ?');"
                                            >

                                                <input
                                                    type="hidden"
                                                    name="csrf_token"
                                                    value="<?= e(csrf_token()) ?>"
                                                >

                                                <input
                                                    type="hidden"
                                                    name="id"
                                                    value="<?= (int) $administrateur["id"] ?>"
                                                >

                                                <input
                                                    type="hidden"
                                                    name="action"
                                                    value="activer"
                                                >

                                                <button
                                                    type="submit"
                                                    class="admin-action-icon admin-action-status"
                                                    aria-label="Activer le compte de <?= e($administrateur["nom"]) ?>"
                                                    title="Activer"
                                                >
                                                    <svg viewBox="0 0 24 24" aria-hidden="true" focusable="false">
                                                        <path d="m5 12 4 4L19 6"></path>
                                                    </svg>
                                                </button>

                                            </form>

                                        <?php endif; ?>

                                        <!-- Supprimer définitivement le compte secondaire. -->
                                        <form
                                            method="POST"
                                            action="supprimer.php"
                                            onsubmit="return confirm('Attention ! Voulez-vous vraiment supprimer définitivement ce compte ?');"
                                        >

                                            <input
                                                type="hidden"
                                                name="csrf_token"
                                                value="<?= e(csrf_token()) ?>"
                                            >

                                            <input
                                                type="hidden"
                                                name="id"
                                                value="<?= (int) $administrateur["id"] ?>"
                                            >

                                            <button
                                                type="submit"
                                                class="admin-action-icon admin-action-delete"
                                                aria-label="Supprimer le compte de <?= e($administrateur["nom"]) ?>"
                                                title="Supprimer"
                                            >
                                                <svg viewBox="0 0 24 24" aria-hidden="true" focusable="false">
                                                    <path d="M3 6h18"></path>
                                                    <path d="M8 6V4h8v2"></path>
                                                    <path d="m19 6-1 14H6L5 6"></path>
                                                    <path d="M10 11v5M14 11v5"></path>
                                                </svg>
                                            </button>

                                        </form>

                                    <?php else: ?>

                                        <span>
                                            Compte principal
                                        </span>

                                    <?php endif; ?>

                                </td>

                            </tr>

                        <?php endforeach; ?>

                    <?php else: ?>

                        <tr>

                            <td colspan="7">
                                Aucun administrateur enregistré.
                            </td>

                        </tr>

                    <?php endif; ?>

                </tbody>

            </table>

        </div>

        <p>
            <a href="/journal-caisse/index.php">
                Retour au tableau de bord
            </a>
        </p>

    </div>

</body>

</html>
