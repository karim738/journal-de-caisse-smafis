
<?php

// Charger les fichiers nécessaires.
require_once __DIR__ . "/../../config/authentification.php";
require_once __DIR__ . "/../../config/connexion.php";
require_once __DIR__ . "/../../includes/fonctions.php";

// Seul l'administrateur principal peut créer un compte.
exiger_administrateur_principal();

// Initialiser les variables.
$erreur = "";
$succes = "";

$nom = "";
$identifiant = "";

// Traiter le formulaire après son envoi.
if ($_SERVER["REQUEST_METHOD"] === "POST") {

    // Vérifier le jeton CSRF.
    csrf_verifier();

    // Récupérer et nettoyer les informations.
    $nom = trim($_POST["nom"] ?? "");
    $identifiant = trim($_POST["identifiant"] ?? "");

    // Ne pas modifier le mot de passe avec trim().
    $motDePasse = $_POST["mot_de_passe"] ?? "";
    $confirmation = $_POST["confirmation"] ?? "";

    // Vérifier les champs obligatoires.
    if (
        $nom === ""
        || $identifiant === ""
        || $motDePasse === ""
        || $confirmation === ""
    ) {

        $erreur = "Veuillez remplir tous les champs.";

    } elseif (strlen($nom) > 100 || strlen($identifiant) > 100) {

        $erreur = "Le nom ou l'identifiant est trop long.";

    } elseif (strlen($motDePasse) < 12) {

        $erreur = "Le mot de passe doit contenir au moins 12 caractères.";

    } elseif (strlen($motDePasse) > 72) {

        $erreur = "Le mot de passe ne doit pas dépasser 72 octets.";

    } elseif ($motDePasse !== $confirmation) {

        $erreur = "Les deux mots de passe ne correspondent pas.";

    } else {

        try {

            // Vérifier que l'identifiant n'existe pas déjà.
            $verification = $pdo->prepare(
                "SELECT id
                 FROM administrateur
                 WHERE identifiant = :identifiant
                 LIMIT 1"
            );

            $verification->execute([
                "identifiant" => $identifiant
            ]);

            if ($verification->fetch()) {

                $erreur = "Cet identifiant est déjà utilisé.";

            } else {

                // Transformer le mot de passe en empreinte sécurisée.
                $motDePasseSecurise = password_hash(
                    $motDePasse,
                    PASSWORD_DEFAULT
                );

                // Enregistrer le nouvel administrateur secondaire.
                $requete = $pdo->prepare(
                    "INSERT INTO administrateur
                    (nom, identifiant, mot_de_passe, role, statut)
                    VALUES
                    (:nom, :identifiant, :mot_de_passe, 'secondaire', 'actif')"
                );

                $requete->execute([
                    "nom" => $nom,
                    "identifiant" => $identifiant,
                    "mot_de_passe" => $motDePasseSecurise
                ]);

                // Réinitialiser les champs après la création.
                $nom = "";
                $identifiant = "";

                // Régénérer le jeton CSRF.
                $_SESSION["csrf_token"] = bin2hex(random_bytes(32));

                $succes = "Le compte administrateur secondaire a été créé avec succès.";
            }

        } catch (PDOException $exception) {

            // Journaliser l'erreur sans révéler les détails à l'utilisateur.
            error_log(
                "Erreur lors de la création d'un administrateur : "
                . $exception->getMessage()
            );

            // Gérer notamment une éventuelle collision d'identifiant.
            if ($exception->getCode() === "23000") {

                $erreur = "Cet identifiant est déjà utilisé.";

            } else {

                $erreur = "Une erreur technique empêche la création du compte.";
            }
        }
    }
}

?>

<!DOCTYPE html>
<html lang="fr">

<head>

    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Créer un administrateur</title>

    <link
        rel="stylesheet"
        href="/journal-caisse/assets/css/style.css"
    >

</head>

<body>

    <div class="container">

        <h1>Créer un administrateur secondaire</h1>

        <p>
            Remplissez les informations pour créer un nouveau compte.
        </p>

        <?php if ($erreur !== ""): ?>

            <div class="message-erreur">
                <?= e($erreur) ?>
            </div>

        <?php endif; ?>

        <?php if ($succes !== ""): ?>

            <div class="message-succes">
                <?= e($succes) ?>
            </div>

        <?php endif; ?>

        <form method="POST" action="">

            <!-- Protection CSRF du formulaire. -->
            <input
                type="hidden"
                name="csrf_token"
                value="<?= e(csrf_token()) ?>"
            >

            <div class="form-group">

                <label for="nom">Nom de l'administrateur</label>

                <input
                    type="text"
                    id="nom"
                    name="nom"
                    maxlength="100"
                    value="<?= e($nom) ?>"
                    required
                >

            </div>

            <div class="form-group">

                <label for="identifiant">Identifiant de connexion</label>

                <input
                    type="text"
                    id="identifiant"
                    name="identifiant"
                    maxlength="100"
                    value="<?= e($identifiant) ?>"
                    autocomplete="username"
                    required
                >

            </div>

            <div class="form-group">

                <label for="mot_de_passe">Mot de passe</label>

                <input
                    type="password"
                    id="mot_de_passe"
                    name="mot_de_passe"
                    minlength="12"
                    maxlength="72"
                    autocomplete="new-password"
                    required
                >

                <small>
                    Minimum 12 caractères et maximum 72 octets.
                </small>

            </div>

            <div class="form-group">

                <label for="confirmation">
                    Confirmer le mot de passe
                </label>

                <input
                    type="password"
                    id="confirmation"
                    name="confirmation"
                    minlength="12"
                    maxlength="72"
                    autocomplete="new-password"
                    required
                >

            </div>

            <button type="submit" class="btn-primary">
                Créer le compte
            </button>

        </form>

        <p>
            <a href="/journal-caisse/admin/administrateurs/index.php">
                Retour à la liste des administrateurs
            </a>
        </p>

    </div>

</body>

</html>
