
<?php

// Charger les fichiers nécessaires.
require_once __DIR__ . "/../../config/authentification.php";
require_once __DIR__ . "/../../config/connexion.php";
require_once __DIR__ . "/../../includes/fonctions.php";

// Seul l'administrateur principal peut supprimer un compte.
exiger_administrateur_principal();

// Autoriser uniquement les requêtes POST.
if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    http_response_code(405);
    exit("Méthode non autorisée.");
}

// Vérifier le jeton CSRF.
csrf_verifier();

// Récupérer et vérifier l'identifiant.
$id = filter_input(INPUT_POST, "id", FILTER_VALIDATE_INT);

if (!$id || $id <= 0) {
    exit("Identifiant invalide.");
}

// Vérifier que le compte existe et qu'il est secondaire.
$requete = $pdo->prepare("
    SELECT id, role
    FROM administrateur
    WHERE id = :id
    LIMIT 1
");

$requete->execute(["id" => $id]);

$administrateur = $requete->fetch();

if (!$administrateur) {
    exit("Administrateur introuvable.");
}

// Interdire la suppression du compte principal.
if ($administrateur["role"] !== "secondaire") {
    http_response_code(403);
    exit("Le compte principal ne peut pas être supprimé.");
}

try {

    // Supprimer uniquement le compte secondaire sélectionné.
    $suppression = $pdo->prepare("
        DELETE FROM administrateur
        WHERE id = :id
        AND role = 'secondaire'
    ");

    $suppression->execute(["id" => $id]);

    // Renouveler le jeton CSRF.
    $_SESSION["csrf_token"] = bin2hex(random_bytes(32));

    // Retourner à la liste des administrateurs.
    header("Location: index.php");
    exit;

} catch (PDOException $e) {

    // Enregistrer l'erreur technique dans les journaux.
    error_log($e->getMessage());

    http_response_code(500);
    exit("Impossible de supprimer ce compte pour le moment.");
}
