
-- =====================================================
-- PROJET : JOURNAL DE CAISSE - LOCATION DE VEHICULES
-- ROLE : Creer la base de donnees et ses tables
-- IMPORTANT : Aucune donnee client ou vehicule importee
-- =====================================================

CREATE DATABASE IF NOT EXISTS journal_caisse
CHARACTER SET utf8mb4
COLLATE utf8mb4_unicode_ci;

USE journal_caisse;

-- 1. TABLE DES CLIENTS
CREATE TABLE client (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    nom VARCHAR(150) NOT NULL,
    telephone VARCHAR(30),
    email VARCHAR(150),
    adresse VARCHAR(255),
    date_creation TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- 2. TABLE DES VEHICULES
CREATE TABLE vehicule (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    marque_modele VARCHAR(150) NOT NULL,
    immatriculation VARCHAR(50) NOT NULL UNIQUE,
    annee SMALLINT UNSIGNED,
    tarif_journalier DECIMAL(12,2) NOT NULL DEFAULT 0,
    statut ENUM('disponible', 'loue', 'maintenance')
        NOT NULL DEFAULT 'disponible',
    date_creation TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- 3. TABLE DES LOCATIONS
CREATE TABLE location (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    client_id INT UNSIGNED NOT NULL,
    vehicule_id INT UNSIGNED NOT NULL,
    date_debut DATE NOT NULL,
    date_fin DATE NOT NULL,
    tarif_journalier DECIMAL(12,2) NOT NULL,
    montant_total DECIMAL(12,2) NOT NULL,
    statut ENUM('prevue', 'en_cours', 'terminee', 'annulee')
        NOT NULL DEFAULT 'prevue',
    observations TEXT,
    date_creation TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT fk_location_client
        FOREIGN KEY (client_id) REFERENCES client(id),

    CONSTRAINT fk_location_vehicule
        FOREIGN KEY (vehicule_id) REFERENCES vehicule(id)
) ENGINE=InnoDB;

-- 4. TABLE DES CATEGORIES DE DEPENSES
CREATE TABLE categorie_depense (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    nom VARCHAR(100) NOT NULL UNIQUE,
    description VARCHAR(255)
) ENGINE=InnoDB;

INSERT INTO categorie_depense (nom) VALUES
    ('carburant'),
    ('entretien'),
    ('assurance');

-- 5. TABLE DES MOUVEMENTS DE CAISSE
-- Une entree correspond a de l'argent reellement encaisse.
-- Une sortie correspond a une depense reellement payee.
CREATE TABLE mouvement_caisse (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    date_operation DATE NOT NULL,
    type_operation ENUM('entree', 'sortie') NOT NULL,
    montant DECIMAL(12,2) NOT NULL,
    libelle VARCHAR(255) NOT NULL,

    client_id INT UNSIGNED NULL,
    location_id INT UNSIGNED NULL,
    categorie_depense_id INT UNSIGNED NULL,

    moyen_paiement ENUM(
        'especes',
        'mobile_money',
        'virement',
        'cheque',
        'autre'
    ) NOT NULL DEFAULT 'especes',

    observations TEXT,
    date_creation TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT fk_mouvement_client
        FOREIGN KEY (client_id) REFERENCES client(id)
        ON DELETE SET NULL,

    CONSTRAINT fk_mouvement_location
        FOREIGN KEY (location_id) REFERENCES location(id)
        ON DELETE SET NULL,

    CONSTRAINT fk_mouvement_categorie
        FOREIGN KEY (categorie_depense_id)
        REFERENCES categorie_depense(id)
        ON DELETE SET NULL,

    CONSTRAINT chk_montant_positif
        CHECK (montant > 0),

    INDEX idx_date_operation (date_operation),
    INDEX idx_type_operation (type_operation)
) ENGINE=InnoDB;
