
<?php

// 1. Charger les protections de sécurité et démarrer la session.
require_once __DIR__ . "/../../config/securite.php";

// 2. Charger la connexion à la base de données.
require_once __DIR__ . "/../../config/connexion.php";

// 3. Charger les fonctions communes.
require_once __DIR__ . "/../../includes/fonctions.php";

// 4. Charger le système d'authentification.
require_once __DIR__ . "/../../config/authentification.php";

// 5. Vérifier que l'administrateur est connecté.
exiger_connexion();

// 6. Récupérer les locations avec les informations des clients et des véhicules.
$requete = $pdo->query(
    "SELECT
        l.id,
        l.date_debut,
        l.date_fin,
        l.tarif_journalier,
        l.montant_total,
        l.statut,
        c.nom AS nom_client,
        v.marque_modele,
        v.immatriculation
    FROM location l
    INNER JOIN client c ON l.client_id = c.id
    INNER JOIN vehicule v ON l.vehicule_id = v.id
    ORDER BY l.id DESC"
);

$locations = $requete->fetchAll();

// Traduire les statuts techniques en libellés français.
$statuts = [
    "prevue"   => "Prévue",
    "en_cours" => "En cours",
    "terminee" => "Terminée",
    "annulee"  => "Annulée"
];

// Charger l'en-tête et le menu de navigation.
require_once __DIR__ . "/../../includes/header.php";
require_once __DIR__ . "/../../includes/sidebar.php";
?>

<div class="main-content">

    <!-- Titre et description de la page -->
    <h1 class="page-title">Gestion des locations</h1>

    <p class="page-description">
        Consulte les locations de véhicules et les montants associés.
    </p>

    <!-- Afficher les messages de confirmation et d'erreur -->
    <?php if (isset($_GET["ajout"]) && $_GET["ajout"] === "success"): ?>

        <div class="message-success">
            La location a été enregistrée avec succès.
        </div>

    <?php elseif (
        isset($_GET["modification"])
        && $_GET["modification"] === "success"
    ): ?>

        <div class="message-success">
            La location a été modifiée avec succès.
        </div>

    <?php elseif (
        isset($_GET["statut"])
        && $_GET["statut"] === "demarrage"
    ): ?>

        <div class="message-success">
            La location a démarré avec succès.
        </div>

    <?php elseif (
        isset($_GET["statut"])
        && $_GET["statut"] === "terminee"
    ): ?>

        <div class="message-success">
            La location a été terminée avec succès.
        </div>

    <?php elseif (
        isset($_GET["statut"])
        && $_GET["statut"] === "annulation"
    ): ?>

        <div class="message-success">
            La location a été annulée avec succès.
        </div>

    <?php elseif (
        isset($_GET["erreur"])
        && $_GET["erreur"] === "introuvable"
    ): ?>

        <div class="message-error">
            La location demandée est introuvable.
        </div>

    <?php elseif (
        isset($_GET["erreur"])
        && $_GET["erreur"] === "id_invalide"
    ): ?>

        <div class="message-error">
            L'identifiant de la location est invalide.
        </div>

    <?php elseif (
        isset($_GET["erreur"])
        && $_GET["erreur"] === "modification_interdite"
    ): ?>

        <div class="message-error">
            Cette location ne peut pas être modifiée dans son état actuel.
        </div>

    <?php elseif (
        isset($_GET["erreur"])
        && $_GET["erreur"] === "statut_invalide"
    ): ?>

        <div class="message-error">
            Le statut demandé est invalide.
        </div>

    <?php elseif (
        isset($_GET["erreur"])
        && $_GET["erreur"] === "changement_refuse"
    ): ?>

        <div class="message-error">
            Le changement de statut a été refusé.
            Vérifie l'état de la location et du véhicule.
        </div>

    <?php elseif (
        isset($_GET["erreur"])
        && $_GET["erreur"] === "technique"
    ): ?>

        <div class="message-error">
            Une erreur technique empêche cette opération.
        </div>

    <?php endif; ?>

    <!-- Bouton permettant d'ajouter une nouvelle location -->
    <div style="margin-top: 20px;">
        <a href="ajouter.php" class="btn-primary">
            + Ajouter une location
        </a>
    </div>

    <!-- Tableau des locations enregistrées -->
    <div class="table-container">

        <table class="data-table">

            <thead>
                <tr>
                    <th>Client</th>
                    <th>Véhicule</th>
                    <th>Début</th>
                    <th>Fin</th>
                    <th>Tarif / jour</th>
                    <th>Montant total</th>
                    <th>Statut</th>
                    <th>Actions</th>
                </tr>
            </thead>

            <tbody>

                <!-- Afficher un message si aucune location n'existe -->
                <?php if (empty($locations)): ?>

                    <tr>
                        <td colspan="8">
                            Aucune location n'est enregistrée pour le moment.
                        </td>
                    </tr>

                <?php else: ?>

                    <!-- Parcourir toutes les locations -->
                    <?php foreach ($locations as $location): ?>

                        <tr>

                            <!-- Informations du client -->
                            <td>
                                <?= e($location["nom_client"]) ?>
                            </td>

                            <!-- Informations du véhicule -->
                            <td>
                                <?= e($location["marque_modele"]) ?>
                                — <?= e($location["immatriculation"]) ?>
                            </td>

                            <!-- Dates de la location -->
                            <td>
                                <?= e($location["date_debut"]) ?>
                            </td>

                            <td>
                                <?= e($location["date_fin"]) ?>
                            </td>

                            <!-- Tarif journalier -->
                            <td>
                                <?= number_format(
                                    (float) $location["tarif_journalier"],
                                    0,
                                    ",",
                                    " "
                                ) ?> FCFA
                            </td>

                            <!-- Montant total de la location -->
                            <td>
                                <?= number_format(
                                    (float) $location["montant_total"],
                                    0,
                                    ",",
                                    " "
                                ) ?> FCFA
                            </td>

                            <!-- Statut traduit en français -->
                            <td>
                                <?= e(
                                    $statuts[$location["statut"]]
                                    ?? "Inconnu"
                                ) ?>
                            </td>

                            <!-- Afficher les actions selon le statut -->
                            <td>

                                <?php if ($location["statut"] === "prevue"): ?>

                                    <!-- Modifier une location prévue -->
                                    <a
                                        href="modifier.php?id=<?= (int) $location['id'] ?>"
                                        class="icon-action icon-action-edit"
                                        aria-label="Modifier la location n°<?= (int) $location['id'] ?>"
                                        title="Modifier"
                                    >
                                        <svg viewBox="0 0 24 24" aria-hidden="true" focusable="false">
                                            <path d="M12 20h9"></path>
                                            <path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L8 18l-4 1 1-4Z"></path>
                                        </svg>
                                    </a>

                                    <!-- Annuler une location prévue -->
                                    <form
                                        action="../../traitements/locations/changer_statut.php"
                                        method="POST"
                                        style="display: inline;"
                                        onsubmit="return confirm('Voulez-vous vraiment annuler cette location ?');"
                                    >
                                        <input
                                            type="hidden"
                                            name="csrf_token"
                                            value="<?= e(csrf_token()) ?>"
                                        >

                                        <input
                                            type="hidden"
                                            name="id"
                                            value="<?= (int) $location['id'] ?>"
                                        >

                                        <input
                                            type="hidden"
                                            name="nouveau_statut"
                                            value="annulee"
                                        >

                                        <button
                                            type="submit"
                                            class="btn-danger"
                                        >
                                            Annuler
                                        </button>
                                    </form>

                                    <!-- Démarrer une location prévue -->
                                    <form
                                        action="../../traitements/locations/changer_statut.php"
                                        method="POST"
                                        style="display: inline;"
                                        onsubmit="return confirm('Voulez-vous démarrer cette location ?');"
                                    >
                                        <input
                                            type="hidden"
                                            name="csrf_token"
                                            value="<?= e(csrf_token()) ?>"
                                        >

                                        <input
                                            type="hidden"
                                            name="id"
                                            value="<?= (int) $location['id'] ?>"
                                        >

                                        <input
                                            type="hidden"
                                            name="nouveau_statut"
                                            value="en_cours"
                                        >

                                        <button
                                            type="submit"
                                            class="btn-primary"
                                        >
                                            Démarrer
                                        </button>
                                    </form>

                                <?php elseif ($location["statut"] === "en_cours"): ?>

                                    <!-- Terminer une location en cours -->
                                    <form
                                        action="../../traitements/locations/changer_statut.php"
                                        method="POST"
                                        style="display: inline;"
                                        onsubmit="return confirm('Confirmer la fin de cette location ?');"
                                    >
                                        <input
                                            type="hidden"
                                            name="csrf_token"
                                            value="<?= e(csrf_token()) ?>"
                                        >

                                        <input
                                            type="hidden"
                                            name="id"
                                            value="<?= (int) $location['id'] ?>"
                                        >

                                        <input
                                            type="hidden"
                                            name="nouveau_statut"
                                            value="terminee"
                                        >

                                        <button
                                            type="submit"
                                            class="btn-primary"
                                        >
                                            Terminer
                                        </button>
                                    </form>

                                <?php else: ?>

                                    <!-- Aucune action pour une location terminée ou annulée -->
                                    <span>
                                        Aucune action disponible
                                    </span>

                                <?php endif; ?>

                            </td>

                        </tr>

                    <?php endforeach; ?>

                <?php endif; ?>

            </tbody>

        </table>

    </div>

</div>

<?php
// Charger le pied de page commun.
require_once __DIR__ . "/../../includes/footer.php";
?>
