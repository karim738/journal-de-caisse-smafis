
<?php
// Charger les paramètres de sécurité, la connexion et les fonctions communes.
require_once __DIR__ . "/../../config/securite.php";
require_once __DIR__ . "/../../config/connexion.php";
require_once __DIR__ . "/../../includes/fonctions.php";

// Récupérer les clients enregistrés pour remplir la liste déroulante.
$requeteClients = $pdo->query(
    "SELECT id, nom, telephone
     FROM client
     ORDER BY nom ASC"
);
$clients = $requeteClients->fetchAll();

// Récupérer uniquement les véhicules actuellement disponibles.
$requeteVehicules = $pdo->query(
    "SELECT id, marque_modele, immatriculation, tarif_journalier
     FROM vehicule
     WHERE statut = 'disponible'
     ORDER BY marque_modele ASC"
);
$vehicules = $requeteVehicules->fetchAll();

// Afficher l'en-tête et le menu de navigation.
require_once __DIR__ . "/../../includes/header.php";
require_once __DIR__ . "/../../includes/sidebar.php";
?>

<div class="main-content">

    <h1 class="page-title">Ajouter une location</h1>

    <p class="page-description">
        Sélectionne un client et un véhicule, puis renseigne les dates de location.
    </p>

    <?php if (empty($clients)): ?>
        <div class="message-success">
            Aucun client n'est enregistré. Ajoute d'abord un client.
        </div>
    <?php endif; ?>

    <?php if (empty($vehicules)): ?>
        <div class="message-success">
            Aucun véhicule n'est disponible. Vérifie la liste des véhicules.
        </div>
    <?php endif; ?>

    <div class="dashboard-card">

        <form action="../../traitements/locations/ajouter.php" method="POST">

            <!-- Jeton de sécurité du formulaire. -->
            <input
                type="hidden"
                name="csrf_token"
                value="<?= e(csrf_token()) ?>"
            >

            <div class="form-group">
                <label for="client_id">Client </label>

                <select id="client_id" name="client_id" required>
                    <option value="">-- Choisir un client --</option>

                    <?php foreach ($clients as $client): ?>
                        <option value="<?= e($client["id"]) ?>">
                            <?= e($client["nom"]) ?>
                            <?php if (!empty($client["telephone"])): ?>
                                — <?= e($client["telephone"]) ?>
                            <?php endif; ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="form-group">
                <label for="vehicule_id">Véhicule disponible </label>

                <select id="vehicule_id" name="vehicule_id" required>
                    <option value="">-- Choisir un véhicule --</option>

                    <?php foreach ($vehicules as $vehicule): ?>
                        <option
                            value="<?= e($vehicule["id"]) ?>"
                            data-tarif="<?= e($vehicule["tarif_journalier"]) ?>"
                        >
                            <?= e($vehicule["marque_modele"]) ?>
                            — <?= e($vehicule["immatriculation"]) ?>
                            — <?= number_format((float) $vehicule["tarif_journalier"], 0, ",", " ") ?> FCFA/jour
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="form-group">
                <label for="date_debut">Date de début </label>
                <input
                    type="date"
                    id="date_debut"
                    name="date_debut"
                    required
                >
            </div>

            <div class="form-group">
                <label for="date_fin">Date de fin </label>
                <input
                    type="date"
                    id="date_fin"
                    name="date_fin"
                    required
                >
            </div>

            <div class="form-group">
                <label for="tarif_journalier">Tarif journalier (FCFA) </label>
                <input
                    type="number"
                    id="tarif_journalier"
                    name="tarif_journalier"
                    min="1"
                    step="1"
                    required
                    readonly
                >
            </div>

            <div class="form-group">
                <label for="montant_total">Montant total estimé (FCFA)</label>
                <input
                    type="number"
                    id="montant_total"
                    name="montant_total"
                    readonly
                    placeholder="Calcul automatique"
                >
                <small>
                    Le calcul sera vérifié côté serveur avant l'enregistrement.
                </small>
            </div>

            <div class="form-group">
                <label for="observations">Observations</label>
                <textarea
                    id="observations"
                    name="observations"
                    rows="4"
                    maxlength="2000"
                    placeholder="Informations complémentaires sur la location"
                ></textarea>
            </div>

            <div class="form-actions">
                <button type="submit" class="btn-primary">
                    Enregistrer la location
                </button>

                <a href="index.php" class="btn-secondary">
                    Annuler
                </a>
            </div>

        </form>

    </div>

</div>

<script>
// Récupérer les champs du formulaire.
const selectVehicule = document.getElementById("vehicule_id");
const champTarif = document.getElementById("tarif_journalier");
const champDebut = document.getElementById("date_debut");
const champFin = document.getElementById("date_fin");
const champMontant = document.getElementById("montant_total");

// Calculer le tarif et le montant estimé.
function calculerMontant() {
    const option = selectVehicule.options[selectVehicule.selectedIndex];
    const tarif = Number(option?.dataset.tarif || 0);

    champTarif.value = tarif > 0 ? tarif : "";

    if (!champDebut.value || !champFin.value || tarif <= 0) {
        champMontant.value = "";
        return;
    }

    // Une journée de location est comptée, même si début et fin sont identiques.
    const debut = new Date(champDebut.value + "T00:00:00");
    const fin = new Date(champFin.value + "T00:00:00");

    if (fin < debut) {
        champMontant.value = "";
        return;
    }

    const nombreJours = Math.round((fin - debut) / 86400000) + 1;
    champMontant.value = tarif * nombreJours;
}

// Recalculer dès qu'un véhicule ou une date change.
selectVehicule.addEventListener("change", calculerMontant);
champDebut.addEventListener("change", calculerMontant);
champFin.addEventListener("change", calculerMontant);
</script>

<?php require_once __DIR__ . "/../../includes/footer.php"; ?>
