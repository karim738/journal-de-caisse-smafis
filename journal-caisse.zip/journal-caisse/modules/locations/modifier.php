
<?php
// Démarrer la session et charger les outils nécessaires.
require_once __DIR__ . "/../../config/securite.php";
require_once __DIR__ . "/../../config/connexion.php";
require_once __DIR__ . "/../../includes/fonctions.php";

// Récupérer l'identifiant de la location dans l'URL.
$idBrut = $_GET["id"] ?? null;
$id = is_string($idBrut) ? filter_var($idBrut, FILTER_VALIDATE_INT) : false;

// Vérifier que l'identifiant est valide.
if ($id === false || $id === null || $id < 1) {
    header("Location: index.php?erreur=id_invalide");
    exit;
}

// Rechercher la location et les informations du client et du véhicule.
$requete = $pdo->prepare(
    "SELECT
        l.id,
        l.client_id,
        l.vehicule_id,
        l.date_debut,
        l.date_fin,
        l.tarif_journalier,
        l.montant_total,
        l.statut,
        l.observations,
        c.nom AS nom_client,
        v.marque_modele,
        v.immatriculation
     FROM location l
     INNER JOIN client c ON l.client_id = c.id
     INNER JOIN vehicule v ON l.vehicule_id = v.id
     WHERE l.id = :id"
);

$requete->execute([":id" => $id]);
$location = $requete->fetch();

// Si la location n'existe pas, revenir à la liste.
if (!$location) {
    header("Location: index.php?erreur=introuvable");
    exit;
}

// Pour cette première version, seule une location prévue est modifiable.
if ($location["statut"] !== "prevue") {
    header("Location: index.php?erreur=modification_interdite");
    exit;
}

// Charger les clients pour la liste déroulante.
$requeteClients = $pdo->query(
    "SELECT id, nom, telephone
     FROM client
     ORDER BY nom ASC"
);
$clients = $requeteClients->fetchAll();

// Charger les véhicules disponibles et le véhicule déjà associé.
// Cela permet de conserver le véhicule actuel même s'il n'est plus disponible.
$requeteVehicules = $pdo->prepare(
    "SELECT id, marque_modele, immatriculation, tarif_journalier, statut
     FROM vehicule
     WHERE statut = 'disponible' OR id = :vehicule_id
     ORDER BY marque_modele ASC"
);
$requeteVehicules->execute([
    ":vehicule_id" => $location["vehicule_id"]
]);
$vehicules = $requeteVehicules->fetchAll();

require_once __DIR__ . "/../../includes/header.php";
require_once __DIR__ . "/../../includes/sidebar.php";
?>

<div class="main-content">

    <h1 class="page-title">Modifier une location</h1>

    <p class="page-description">
        Modifie les informations de cette location prévue.
    </p>

    <form
        action="../../traitements/locations/modifier.php"
        method="POST"
        class="form-container"
    >

        <!-- Jeton de sécurité contre les requêtes CSRF. -->
        <input
            type="hidden"
            name="csrf_token"
            value="<?= e(csrf_token()) ?>"
        >

        <!-- Identifiant de la location à modifier. -->
        <input
            type="hidden"
            name="id"
            value="<?= (int) $location['id'] ?>"
        >

        <div class="form-group">
            <label for="client_id">Client</label>

            <select id="client_id" name="client_id" required>
                <?php foreach ($clients as $client): ?>
                    <option
                        value="<?= (int) $client['id'] ?>"
                        <?= (int) $client['id'] === (int) $location['client_id'] ? 'selected' : '' ?>
                    >
                        <?= e($client['nom']) ?>
                        — <?= e($client['telephone'] ?? '') ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="form-group">
            <label for="vehicule_id">Véhicule</label>

            <select id="vehicule_id" name="vehicule_id" required>
                <?php foreach ($vehicules as $vehicule): ?>
                    <option
                        value="<?= (int) $vehicule['id'] ?>"
                        data-tarif="<?= (int) $vehicule['tarif_journalier'] ?>"
                        <?= (int) $vehicule['id'] === (int) $location['vehicule_id'] ? 'selected' : '' ?>
                    >
                        <?= e($vehicule['marque_modele']) ?>
                        — <?= e($vehicule['immatriculation']) ?>
                        (<?= number_format((float) $vehicule['tarif_journalier'], 0, ',', ' ') ?> FCFA/jour)
                    </option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="form-group">
            <label for="date_debut">Date de début</label>

            <input
                type="date"
                id="date_debut"
                name="date_debut"
                value="<?= e($location['date_debut']) ?>"
                required
            >
        </div>

        <div class="form-group">
            <label for="date_fin">Date de fin</label>

            <input
                type="date"
                id="date_fin"
                name="date_fin"
                value="<?= e($location['date_fin']) ?>"
                required
            >
        </div>

        <div class="form-group">
            <label for="tarif_journalier">Tarif journalier (FCFA)</label>

            <input
                type="number"
                id="tarif_journalier"
                value="<?= (int) $location['tarif_journalier'] ?>"
                readonly
            >
        </div>

        <div class="form-group">
            <label for="montant_total">Montant total (FCFA)</label>

            <input
                type="number"
                id="montant_total"
                value="<?= (int) $location['montant_total'] ?>"
                readonly
            >
        </div>

        <div class="form-group">
            <label for="observations">Observations</label>

            <textarea
                id="observations"
                name="observations"
                rows="4"
            ><?= e($location['observations'] ?? '') ?></textarea>
        </div>

        <button type="submit" class="btn-primary">
            Enregistrer les modifications
        </button>

        <a href="index.php" class="btn-secondary">
            Retour à la liste
        </a>

    </form>

</div>

<script>
// Mettre à jour le tarif selon le véhicule choisi.
const selectVehicule = document.getElementById("vehicule_id");
const champTarif = document.getElementById("tarif_journalier");
const champMontant = document.getElementById("montant_total");
const champDebut = document.getElementById("date_debut");
const champFin = document.getElementById("date_fin");

function calculerMontant() {
    const option = selectVehicule.options[selectVehicule.selectedIndex];
    const tarif = Number(option?.dataset.tarif || 0);

    champTarif.value = tarif;

    if (!champDebut.value || !champFin.value || champFin.value < champDebut.value) {
        champMontant.value = 0;
        return;
    }

    // Le jour de début et le jour de fin sont tous les deux facturés.
    const debut = new Date(champDebut.value + "T00:00:00");
    const fin = new Date(champFin.value + "T00:00:00");
    const nombreJours = Math.round((fin - debut) / 86400000) + 1;

    champMontant.value = tarif * nombreJours;
}

selectVehicule.addEventListener("change", calculerMontant);
champDebut.addEventListener("change", calculerMontant);
champFin.addEventListener("change", calculerMontant);

// Calculer le montant dès l'ouverture de la page.
calculerMontant();
</script>

<?php require_once __DIR__ . "/../../includes/footer.php"; ?>
