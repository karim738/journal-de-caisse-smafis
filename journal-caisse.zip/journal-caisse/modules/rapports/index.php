<?php

// ==================================================
// 1. CHARGEMENT DES FICHIERS NÉCESSAIRES
// ==================================================

// Charger les protections de sécurité et démarrer la session.
require_once __DIR__ . "/../../config/securite.php";

// Charger la connexion à la base de données MySQL.
require_once __DIR__ . "/../../config/connexion.php";

// Charger les fonctions communes du projet.
require_once __DIR__ . "/../../includes/fonctions.php";

// Charger le système d'authentification.
require_once __DIR__ . "/../../config/authentification.php";

// Vérifier que l'administrateur est connecté.
exiger_connexion();
// ==================================================
// 2. RÉCUPÉRATION ET VALIDATION DES DATES
// ==================================================

// Date du premier jour du mois en cours.
$dateDebutDefaut = date("Y-m-01");

// Date du jour.
$dateFinDefaut = date("Y-m-d");

// Récupérer les dates envoyées par le formulaire.
$dateDebut = $_GET["date_debut"] ?? $dateDebutDefaut;
$dateFin = $_GET["date_fin"] ?? $dateFinDefaut;


// Vérifier qu'une date respecte le format AAAA-MM-JJ.
function dateRapportValide($date): bool
{
    if (!is_string($date)) {
        return false;
    }

    $dateFormatee = DateTime::createFromFormat("!Y-m-d", $date);

    return $dateFormatee !== false
        && $dateFormatee->format("Y-m-d") === $date;
}


// Vérifier les dates reçues.
if (!dateRapportValide($dateDebut)) {
    $dateDebut = $dateDebutDefaut;
}

if (!dateRapportValide($dateFin)) {
    $dateFin = $dateFinDefaut;
}

// Vérifier que la date de début ne dépasse pas la date de fin.
if ($dateDebut > $dateFin) {
    $dateDebut = $dateDebutDefaut;
    $dateFin = $dateFinDefaut;
}


// ==================================================
// 3. CALCUL DES RECETTES, DÉPENSES ET SOLDE
// ==================================================

$requeteTotaux = $pdo->prepare(
    "SELECT
        COALESCE(
            SUM(CASE
                WHEN type_operation = 'entree' THEN montant
                ELSE 0
            END), 0
        ) AS total_entrees,

        COALESCE(
            SUM(CASE
                WHEN type_operation = 'sortie' THEN montant
                ELSE 0
            END), 0
        ) AS total_sorties

     FROM mouvement_caisse

     WHERE date_operation BETWEEN :date_debut AND :date_fin"
);

$requeteTotaux->execute([
    ":date_debut" => $dateDebut,
    ":date_fin" => $dateFin
]);

$totaux = $requeteTotaux->fetch();

// Convertir les résultats en nombres.
$totalEntrees = (float) $totaux["total_entrees"];
$totalSorties = (float) $totaux["total_sorties"];

// Calculer le solde de la période.
$solde = $totalEntrees - $totalSorties;


// ==================================================
// 4. RÉCUPÉRATION DES DÉPENSES PAR CATÉGORIE
// ==================================================

$requeteDepenses = $pdo->prepare(
    "SELECT
        COALESCE(cd.nom, 'Sans catégorie') AS categorie,
        COUNT(mc.id) AS nombre_operations,
        SUM(mc.montant) AS montant_total

     FROM mouvement_caisse mc

     LEFT JOIN categorie_depense cd
        ON mc.categorie_depense_id = cd.id

     WHERE mc.type_operation = 'sortie'
       AND mc.date_operation BETWEEN :date_debut AND :date_fin

     GROUP BY cd.id, cd.nom

     ORDER BY montant_total DESC"
);

$requeteDepenses->execute([
    ":date_debut" => $dateDebut,
    ":date_fin" => $dateFin
]);

$depenses = $requeteDepenses->fetchAll();


// ==================================================
// 5. RÉCUPÉRATION DES OPÉRATIONS DE LA PÉRIODE
// ==================================================

$requeteOperations = $pdo->prepare(
    "SELECT
        mc.date_operation,
        mc.libelle,
        mc.type_operation,
        mc.montant,
        mc.moyen_paiement,
        c.nom AS nom_client,
        cd.nom AS nom_categorie

     FROM mouvement_caisse mc

     LEFT JOIN client c
        ON mc.client_id = c.id

     LEFT JOIN categorie_depense cd
        ON mc.categorie_depense_id = cd.id

     WHERE mc.date_operation BETWEEN :date_debut AND :date_fin

     ORDER BY mc.date_operation DESC, mc.id DESC"
);

$requeteOperations->execute([
    ":date_debut" => $dateDebut,
    ":date_fin" => $dateFin
]);

$operations = $requeteOperations->fetchAll();

$moyensPaiement = [
    "especes" => "Espèces",
    "mobile_money" => "Mobile Money",
    "virement" => "Virement",
    "cheque" => "Chèque",
    "autre" => "Autre"
];


// ==================================================
// 6. CHARGEMENT DES ÉLÉMENTS COMMUNS
// ==================================================

require_once __DIR__ . "/../../includes/header.php";
require_once __DIR__ . "/../../includes/sidebar.php";
?>

<div class="main-content">

    <h1 class="page-title">Rapports financiers</h1>

    <p class="page-description">
        Consulte les recettes, les dépenses et le solde de ton entreprise.
    </p>


    <!-- ==========================================
         7. FILTRE PAR PÉRIODE
         ========================================== -->

    <form method="GET" action="index.php">

        <div class="form-group">

            <label for="date_debut">
                Date de début
            </label>

            <input
                type="date"
                id="date_debut"
                name="date_debut"
                value="<?= e($dateDebut) ?>"
                required
            >

        </div>

        <div class="form-group">

            <label for="date_fin">
                Date de fin
            </label>

            <input
                type="date"
                id="date_fin"
                name="date_fin"
                value="<?= e($dateFin) ?>"
                required
            >

        </div>

        <button type="submit" class="btn-primary">
            Filtrer le rapport
        </button>

        <a href="index.php" class="btn-secondary">
            Réinitialiser
        </a>

    </form>

    
<!-- Bouton pour exporter les opérations de la période sélectionnée -->
<div style="margin: 15px 0 25px;">
    <a
        href="exporter.php?date_debut=<?= e($dateDebut) ?>&date_fin=<?= e($dateFin) ?>"
        class="btn-primary"
        style="display: inline-block; text-decoration: none;"
    >
        Télécharger le rapport CSV
    </a>
</div>



    <!-- ==========================================
         8. STATISTIQUES FINANCIÈRES
         ========================================== -->

    <h2>Situation financière</h2>

    <div class="dashboard-grid">

        <div class="dashboard-card">

            <h3>Total des recettes</h3>

            <p>
                <?= number_format($totalEntrees, 0, ",", " ") ?> FCFA
            </p>

        </div>


        <div class="dashboard-card">

            <h3>Total des dépenses</h3>

            <p>
                <?= number_format($totalSorties, 0, ",", " ") ?> FCFA
            </p>

        </div>


        <div class="dashboard-card">

            <h3>Solde de la période</h3>

            <p>
                <?= number_format($solde, 0, ",", " ") ?> FCFA
            </p>

        </div>

    </div>

    
<!-- ==========================================
     9. GRAPHIQUE DES RECETTES ET DES DÉPENSES
     ========================================== -->

<h2>Comparaison des recettes et des dépenses</h2>

<div class="dashboard-card" style="margin-bottom: 25px;">
    <div style="position: relative; width: 100%; height: 350px;">
        <canvas id="graphiqueFinancier"></canvas>
    </div>
</div>

<!-- Charger la bibliothèque Chart.js -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<script>
document.addEventListener("DOMContentLoaded", function () {

    // Récupérer la zone où le graphique sera dessiné.
    const zoneGraphique = document.getElementById("graphiqueFinancier");

    // Récupérer les montants calculés par PHP.
    const recettes = <?= json_encode($totalEntrees) ?>;
    const depenses = <?= json_encode($totalSorties) ?>;

    // Créer le graphique uniquement si la zone existe.
    if (zoneGraphique) {

        new Chart(zoneGraphique, {
            type: "bar",

            data: {
                labels: ["Recettes", "Dépenses"],

                datasets: [{
                    label: "Montant en FCFA",
                    data: [recettes, depenses],
                    backgroundColor: [
                        "#1dbb58",
                        "#ef4444"
                    ],
                    borderRadius: 6
                }]
            },

            options: {
                responsive: true,
                maintainAspectRatio: false,

                plugins: {
                    legend: {
                        display: false
                    },

                    tooltip: {
                        callbacks: {
                            label: function (contexte) {
                                return contexte.parsed.y
                                    .toLocaleString("fr-FR")
                                    + " FCFA";
                            }
                        }
                    }
                },

                scales: {
                    y: {
                        beginAtZero: true,

                        ticks: {
                            callback: function (valeur) {
                                return valeur.toLocaleString("fr-FR")
                                    + " FCFA";
                            }
                        }
                    }
                }
            }
        });
    }
});
</script>



    <!-- ==========================================
         9. DÉPENSES PAR CATÉGORIE
         ========================================== -->

    <h2>Dépenses par catégorie</h2>

    <div class="table-container">

        <table>

            <thead>

                <tr>
                    <th>Catégorie</th>
                    <th>Nombre d'opérations</th>
                    <th>Montant total</th>
                </tr>

            </thead>

            <tbody>

                <?php if (empty($depenses)): ?>

                    <tr>
                        <td colspan="3">
                            Aucune dépense enregistrée pour cette période.
                        </td>
                    </tr>

                <?php else: ?>

                    <?php foreach ($depenses as $depense): ?>

                        <tr>

                            <td><?= e($depense["categorie"]) ?></td>

                            <td>
                                <?= (int) $depense["nombre_operations"] ?>
                            </td>

                            <td>
                                <?= number_format(
                                    (float) $depense["montant_total"],
                                    0,
                                    ",",
                                    " "
                                ) ?> FCFA
                            </td>

                        </tr>

                    <?php endforeach; ?>

                <?php endif; ?>

            </tbody>

        </table>

    </div>


    <!-- ==========================================
         10. HISTORIQUE DES OPÉRATIONS
         ========================================== -->

    <section class="report-history dashboard-card" aria-labelledby="report-history-title">
        <div class="report-section-heading">
            <div>
                <h2 id="report-history-title">Historique des opérations</h2>
                <p>Les mouvements de caisse enregistrés sur la période sélectionnée.</p>
            </div>
            <span class="report-count">
                <?= count($operations) ?>
                <?= count($operations) === 1 ? "opération" : "opérations" ?>
            </span>
        </div>

        <div class="table-container report-history-table">
            <table class="data-table" aria-label="Historique des opérations de caisse">
                <thead>
                    <tr>
                        <th scope="col">Date</th>
                        <th scope="col">Libellé</th>
                        <th scope="col">Type</th>
                        <th scope="col">Montant</th>
                        <th scope="col">Paiement</th>
                        <th scope="col">Client</th>
                        <th scope="col">Catégorie</th>
                    </tr>
                </thead>

                <tbody>
                    <?php if (empty($operations)): ?>
                        <tr>
                            <td class="report-history-empty" colspan="7">
                                Aucune opération n’a été enregistrée sur cette période.
                            </td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($operations as $operation): ?>
                            <?php $estUneEntree = $operation["type_operation"] === "entree"; ?>
                            <tr>
                                <td>
                                    <?= e(date("d/m/Y", strtotime($operation["date_operation"]))) ?>
                                </td>
                                <td class="report-operation-label">
                                    <?= e($operation["libelle"]) ?>
                                </td>
                                <td>
                                    <span class="operation-badge<?= $estUneEntree ? " operation-badge--income" : " operation-badge--expense" ?>">
                                        <?= $estUneEntree ? "Entrée" : "Sortie" ?>
                                    </span>
                                </td>
                                <td class="report-operation-amount<?= $estUneEntree ? " report-operation-amount--income" : " report-operation-amount--expense" ?>">
                                    <?= number_format(
                                        (float) $operation["montant"],
                                        0,
                                        ",",
                                        " "
                                    ) ?> FCFA
                                </td>
                                <td>
                                    <?= e(
                                        $moyensPaiement[$operation["moyen_paiement"]]
                                        ?? $operation["moyen_paiement"]
                                    ) ?>
                                </td>
                                <td><?= e($operation["nom_client"] ?? "—") ?></td>
                                <td><?= e($operation["nom_categorie"] ?? "—") ?></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </section>

</div>

<?php
// Charger le pied de page commun.
require_once __DIR__ . "/../../includes/footer.php";
?>
