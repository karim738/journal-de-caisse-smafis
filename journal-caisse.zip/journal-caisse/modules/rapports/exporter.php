
<?php

require_once __DIR__ . "/../../config/authentification.php";

exiger_connexion();
// ============================================
// 1. CHARGER LA CONFIGURATION ET LA CONNEXION
// ============================================

// Charger la sécurité de l'application.
require_once __DIR__ . '/../../config/securite.php';

// Charger la connexion PDO à la base de données.
require_once __DIR__ . '/../../config/connexion.php';

// ============================================
// 2. RÉCUPÉRER ET VALIDER LES DATES
// ============================================

// Si aucune date n'est fournie, utiliser le mois en cours.
$dateDebut = $_GET['date_debut'] ?? date('Y-m-01');
$dateFin = $_GET['date_fin'] ?? date('Y-m-d');

// Vérifier qu'une date respecte réellement le format AAAA-MM-JJ.
function dateValide(string $date): bool
{
    $dateFormatee = DateTimeImmutable::createFromFormat('!Y-m-d', $date);

    return $dateFormatee !== false
        && $dateFormatee->format('Y-m-d') === $date;
}

// Refuser les dates invalides.
if (
    !is_string($dateDebut)
    || !is_string($dateFin)
    || !dateValide($dateDebut)
    || !dateValide($dateFin)
) {
    http_response_code(400);
    exit('Dates invalides. Veuillez utiliser le format AAAA-MM-JJ.');
}

// Refuser une période incohérente.
if ($dateDebut > $dateFin) {
    http_response_code(400);
    exit('La date de début doit précéder la date de fin.');
}

// ============================================
// 3. PRÉPARER LA REQUÊTE SQL
// ============================================

// Récupérer les opérations et les informations associées.
$sql = "
    SELECT
        m.date_operation,
        m.type_operation,
        m.montant,
        m.libelle,
        cl.nom AS nom_client,
        cat.nom AS categorie_depense,
        m.moyen_paiement,
        m.observations
    FROM mouvement_caisse AS m
    LEFT JOIN client AS cl
        ON cl.id = m.client_id
    LEFT JOIN categorie_depense AS cat
        ON cat.id = m.categorie_depense_id
    WHERE m.date_operation BETWEEN :date_debut AND :date_fin
    ORDER BY m.date_operation DESC
";

$requete = $pdo->prepare($sql);

// Transmettre les dates séparément pour éviter les injections SQL.
$requete->execute([
    'date_debut' => $dateDebut,
    'date_fin' => $dateFin
]);

// ============================================
// 4. PRÉPARER LE FICHIER CSV
// ============================================

// Éviter les formules dangereuses dans les cellules de texte
// lorsqu'un fichier est ouvert dans un tableur.
function securiserCelluleCSV($valeur): string
{
    $texte = (string) ($valeur ?? '');

    if (preg_match('/^[\x00-\x20]*[=+\-@]/', $texte)) {
        return "'" . $texte;
    }

    return $texte;
}

// Envoyer les en-têtes qui déclenchent le téléchargement.
$nomFichier = 'rapport_caisse_' . $dateDebut . '_' . $dateFin . '.csv';

header('Content-Type: text/csv; charset=UTF-8');
header(
    'Content-Disposition: attachment; filename="' . $nomFichier . '"'
);
header('Cache-Control: no-store, no-cache, must-revalidate');

// Ouvrir la sortie pour écrire directement dans la réponse HTTP.
$sortie = fopen('php://output', 'w');

if ($sortie === false) {
    http_response_code(500);
    exit('Impossible de générer le fichier CSV.');
}

// BOM UTF-8 pour améliorer l'affichage des accents dans Excel.
fwrite($sortie, "\xEF\xBB\xBF");

// Utiliser le point-virgule, pratique avec les paramètres régionaux français.
$separateur = ';';

// ============================================
// 5. ÉCRIRE LES TITRES DES COLONNES
// ============================================

fputcsv($sortie, [
    'Date',
    'Type d’opération',
    'Montant (FCFA)',
    'Libellé',
    'Client',
    'Catégorie de dépense',
    'Moyen de paiement',
    'Observations'
], $separateur, '"', '');

// ============================================
// 6. ÉCRIRE LES OPÉRATIONS
// ============================================

while ($operation = $requete->fetch(PDO::FETCH_ASSOC)) {
    fputcsv($sortie, [
        securiserCelluleCSV($operation['date_operation']),
        securiserCelluleCSV($operation['type_operation']),
        $operation['montant'],
        securiserCelluleCSV($operation['libelle']),
        securiserCelluleCSV($operation['nom_client']),
        securiserCelluleCSV($operation['categorie_depense']),
        securiserCelluleCSV($operation['moyen_paiement']),
        securiserCelluleCSV($operation['observations'])
    ], $separateur, '"', '');
}

// Fermer le flux et terminer le script.
fclose($sortie);
exit;
