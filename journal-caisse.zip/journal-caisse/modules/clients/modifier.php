
<?php

// 1. Charger les protections de sécurité.
require_once __DIR__ . "/../../config/securite.php";

// 2. Charger les fonctions communes.
require_once __DIR__ . "/../../includes/fonctions.php";

// 3. Charger la connexion à la base de données.
require_once __DIR__ . "/../../config/connexion.php";

// 4. Vérifier que l'identifiant du client est valide.
$id = filter_input(INPUT_GET, "id", FILTER_VALIDATE_INT);

if ($id === false || $id === null || $id < 1) {
    header("Location: index.php");
    exit;
}

// 5. Rechercher le client à modifier avec une requête préparée.
$requete = $pdo->prepare(
    "SELECT id, nom, telephone, email, adresse
     FROM client
     WHERE id = :id"
);

$requete->execute([
    ":id" => $id
]);

$client = $requete->fetch();

// 6. Vérifier que le client existe.
if (!$client) {
    http_response_code(404);
    exit("Client introuvable.");
}

// 7. Charger les éléments communs de la page.
require_once __DIR__ . "/../../includes/header.php";
require_once __DIR__ . "/../../includes/sidebar.php";
?>

<!-- Contenu principal -->
<div class="main-content">

    <h1 class="page-title">Modifier un client</h1>

    <p class="page-description">
        Modifiez les informations du client, puis enregistrez les changements.
    </p>

    <div class="dashboard-card">

        <form
            action="../../traitements/clients/modifier.php"
            method="POST"
        >

            <!-- Jeton de protection CSRF -->
            <input
                type="hidden"
                name="csrf_token"
                value="<?= e(csrf_token()) ?>"
            >

            <!-- Identifiant du client à modifier -->
            <input
                type="hidden"
                name="id"
                value="<?= e($client["id"]) ?>"
            >

            <!-- Nom du client -->
            <div class="form-group">
                <label for="nom">Nom complet *</label>

                <input
                    type="text"
                    id="nom"
                    name="nom"
                    maxlength="150"
                    value="<?= e($client["nom"]) ?>"
                    required
                    autocomplete="name"
                >
            </div>

            <!-- Téléphone -->
            <div class="form-group">
                <label for="telephone">Téléphone</label>

                <input
                    type="tel"
                    id="telephone"
                    name="telephone"
                    maxlength="30"
                    value="<?= e($client["telephone"] ?? "") ?>"
                    autocomplete="tel"
                >
            </div>

            <!-- Email -->
            <div class="form-group">
                <label for="email">Adresse email</label>

                <input
                    type="email"
                    id="email"
                    name="email"
                    maxlength="254"
                    value="<?= e($client["email"] ?? "") ?>"
                    autocomplete="email"
                >
            </div>

            <!-- Adresse -->
            <div class="form-group">
                <label for="adresse">Adresse</label>

                <textarea
                    id="adresse"
                    name="adresse"
                    rows="3"
                    maxlength="500"
                    autocomplete="street-address"
                ><?= e($client["adresse"] ?? "") ?></textarea>
            </div>

            <!-- Boutons -->
            <div class="form-actions">

                <button type="submit" class="btn-primary">
                    Enregistrer les modifications
                </button>

                <a href="index.php" class="btn-secondary">
                    Annuler
                </a>

            </div>

        </form>

    </div>

</div>

<?php
// 8. Charger le pied de page.
require_once __DIR__ . "/../../includes/footer.php";
?>
