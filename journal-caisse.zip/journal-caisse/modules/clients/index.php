<?php

// 1. Charger les protections de sécurité et démarrer la session.
require_once __DIR__ . "/../../config/securite.php";

// 2. Charger la connexion à la base de données.
require_once __DIR__ . "/../../config/connexion.php";

// 3. Charger les fonctions communes.
require_once __DIR__ . "/../../includes/fonctions.php";

// 4. Charger le système d'authentification.
require_once __DIR__ . "/../../config/authentification.php";

// 5. Vérifier que l'administrateur est connecté.
exiger_connexion();

// 6. Récupérer les clients enregistrés dans la base de données.
$requete = $pdo->query(
    "SELECT id, nom, telephone, email, date_creation
     FROM client
     ORDER BY nom ASC"
);

$clients = $requete->fetchAll();

// 5. Récupérer le message éventuel après une opération.
$ajoutReussi = isset($_GET["ajout"])
    && $_GET["ajout"] === "success";

$modificationReussie = isset($_GET["modification"])
    && $_GET["modification"] === "success";

// 6. Charger les éléments communs de la page.
require_once __DIR__ . "/../../includes/header.php";
require_once __DIR__ . "/../../includes/sidebar.php";
?>

<!-- Contenu principal -->
<div class="main-content">

    <h1 class="page-title">Gestion des clients</h1>

    <p class="page-description">
        Consultez et gérez les clients de votre activité de location.
    </p>

    <!-- Messages de confirmation -->
    <?php if ($ajoutReussi): ?>
        <div class="message-success" role="status">
            Le client a été enregistré avec succès.
        </div>
    <?php endif; ?>

    <?php if ($modificationReussie): ?>
        <div class="message-success" role="status">
            Les informations du client ont été modifiées avec succès.
        </div>
    <?php endif; ?>

    <!-- Bouton d'ajout -->
    <div class="form-actions">
        <a
            href="ajouter.php"
            class="btn-primary"
        >
            + Ajouter un client
        </a>
    </div>

    <!-- Tableau des clients -->
    <div class="dashboard-card">

        <?php if (!empty($clients)): ?>

            <div class="table-container">

                <table class="data-table">

                    <thead>
                        <tr>
                            <th>N°</th>
                            <th>Nom du client</th>
                            <th>Téléphone</th>
                            <th>Email</th>
                            <th>Date d'enregistrement</th>
                            <th>Actions</th>
                        </tr>
                    </thead>

                    <tbody>

                        <?php foreach ($clients as $client): ?>

                            <tr>
                                <td><?= e($client["id"]) ?></td>

                                <td><?= e($client["nom"]) ?></td>

                                <td>
                                    <?= e($client["telephone"] ?? "") ?>
                                </td>

                                <td>
                                    <?= e($client["email"] ?? "") ?>
                                </td>

                                <td>
                                    <?= e($client["date_creation"]) ?>
                                </td>

                               
<td>
    <!-- Bouton pour modifier les informations du client -->
    <a
        href="modifier.php?id=<?= e($client["id"]) ?>"
        class="icon-action icon-action-edit"
        aria-label="Modifier le client <?= e($client["nom"]) ?>"
        title="Modifier"
    >
        <svg viewBox="0 0 24 24" aria-hidden="true" focusable="false">
            <path d="M12 20h9"></path>
            <path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L8 18l-4 1 1-4Z"></path>
        </svg>
    </a>

    <!-- Formulaire de suppression envoyé uniquement en POST -->
    <form
        action="../../traitements/clients/supprimer.php"
        method="POST"
        style="display: inline;"
        onsubmit="return confirm('Voulez-vous vraiment supprimer ce client ?');"
    >
        <!-- Identifiant du client à supprimer -->
        <input
            type="hidden"
            name="id"
            value="<?= e($client["id"]) ?>"
        >

        <!-- Jeton de sécurité contre les requêtes CSRF -->
        <input
            type="hidden"
            name="csrf_token"
            value="<?= e(csrf_token()) ?>"
        >

        <button
            type="submit"
            class="icon-action icon-action-delete"
            aria-label="Supprimer le client <?= e($client["nom"]) ?>"
            title="Supprimer"
        >
            <svg viewBox="0 0 24 24" aria-hidden="true" focusable="false">
                <path d="M3 6h18"></path>
                <path d="M8 6V4h8v2"></path>
                <path d="m19 6-1 14H6L5 6"></path>
                <path d="M10 11v5M14 11v5"></path>
            </svg>
        </button>
    </form>
</td>

                                
                            </tr>

                        <?php endforeach; ?>

                    </tbody>

                </table>

            </div>

        <?php else: ?>

            <p>Aucun client n'est enregistré pour le moment.</p>

            <p>
                Clique sur « Ajouter un client » pour enregistrer
                ton premier client.
            </p>

        <?php endif; ?>

    </div>

</div>

<?php
// 7. Charger le pied de page commun.
require_once __DIR__ . "/../../includes/footer.php";
?>
