
<?php
// 1. Charger les protections de sécurité.
require_once __DIR__ . "/../../config/securite.php";

// 2. Charger les fonctions communes.
require_once __DIR__ . "/../../includes/fonctions.php";

// 3. Charger l'en-tête HTML et le CSS commun.
require_once __DIR__ . "/../../includes/header.php";

// 4. Charger le menu latéral.
require_once __DIR__ . "/../../includes/sidebar.php";
?>

<!-- Contenu principal -->
<div class="main-content">

    <h1 class="page-title">Ajouter un client</h1>

    <p class="page-description">
        Remplissez les informations du nouveau client.
    </p>

    <div class="dashboard-card">

        <form
            action="../../traitements/clients/ajouter.php"
            method="POST"
        >

            <!-- Jeton de protection CSRF -->
            <input
                type="hidden"
                name="csrf_token"
                value="<?= e(csrf_token()) ?>"
            >

            <!-- Nom du client -->
            <div class="form-group">
                <label for="nom">Nom complet *</label>

                <input
                    type="text"
                    id="nom"
                    name="nom"
                    maxlength="150"
                    required
                    autocomplete="name"
                    placeholder="Exemple : Koffi Jean"
                >
            </div>

            <!-- Téléphone -->
            <div class="form-group">
                <label for="telephone">Téléphone</label>

                <input
                    type="tel"
                    id="telephone"
                    name="telephone"
                    maxlength="30"
                    autocomplete="tel"
                    placeholder="Exemple : 0700000000"
                >
            </div>

            <!-- Adresse email -->
            <div class="form-group">
                <label for="email">Adresse email</label>

                <input
                    type="email"
                    id="email"
                    name="email"
                    maxlength="254"
                    autocomplete="email"
                    placeholder="Exemple : client@email.com"
                >
            </div>

            <!-- Adresse -->
            <div class="form-group">
                <label for="adresse">Adresse</label>

                <textarea
                    id="adresse"
                    name="adresse"
                    rows="3"
                    maxlength="500"
                    autocomplete="street-address"
                    placeholder="Ville, quartier ou adresse du client"
                ></textarea>
            </div>

            <!-- Boutons d'action -->
            <div class="form-actions">

                <button type="submit" class="btn-primary">
                    Enregistrer le client
                </button>

                <a href="index.php" class="btn-secondary">
                    Annuler
                </a>

            </div>

        </form>

    </div>

</div>

<?php
// 5. Charger le pied de page.
require_once __DIR__ . "/../../includes/footer.php";
?>
