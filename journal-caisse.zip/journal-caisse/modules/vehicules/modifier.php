
<?php
// Charger la sécurité, la connexion à MySQL et les fonctions communes.
require_once __DIR__ . "/../../config/securite.php";
require_once __DIR__ . "/../../config/connexion.php";
require_once __DIR__ . "/../../includes/fonctions.php";

// Récupérer l'identifiant du véhicule transmis dans l'adresse URL.
$idBrut = $_GET["id"] ?? null;

// Vérifier que l'identifiant est bien un nombre entier positif.
$id = is_string($idBrut)
    ? filter_var($idBrut, FILTER_VALIDATE_INT)
    : false;

if ($id === false || $id === null || $id < 1) {
    header("Location: index.php?erreur=introuvable");
    exit;
}

// Rechercher le véhicule correspondant à cet identifiant.
$requete = $pdo->prepare(
    "SELECT id, marque_modele, immatriculation, annee,
            tarif_journalier, statut
     FROM vehicule
     WHERE id = :id"
);

$requete->execute([":id" => $id]);
$vehicule = $requete->fetch();

// Si le véhicule n'existe pas, revenir à la liste.
if (!$vehicule) {
    header("Location: index.php?erreur=introuvable");
    exit;
}

// Afficher l'en-tête et le menu de navigation.
require_once __DIR__ . "/../../includes/header.php";
require_once __DIR__ . "/../../includes/sidebar.php";
?>

<div class="main-content">

    <h1 class="page-title">Modifier un véhicule</h1>

    <p class="page-description">
        Modifie les informations du véhicule sélectionné.
    </p>

    <div class="dashboard-card">

        <!-- Envoyer les modifications au traitement PHP. -->
        <form action="../../traitements/vehicules/modifier.php" method="POST">

            <!-- Transmettre l'identifiant du véhicule. -->
            <input
                type="hidden"
                name="id"
                value="<?= e($vehicule["id"]) ?>"
            >

            <!-- Jeton de sécurité contre les soumissions non autorisées. -->
            <input
                type="hidden"
                name="csrf_token"
                value="<?= e(csrf_token()) ?>"
            >

            <div class="form-group">
                <label for="marque_modele">Marque et modèle *</label>
                <input
                    type="text"
                    id="marque_modele"
                    name="marque_modele"
                    maxlength="150"
                    required
                    value="<?= e($vehicule["marque_modele"]) ?>"
                >
            </div>

            <div class="form-group">
                <label for="immatriculation">Immatriculation *</label>
                <input
                    type="text"
                    id="immatriculation"
                    name="immatriculation"
                    maxlength="30"
                    required
                    value="<?= e($vehicule["immatriculation"]) ?>"
                >
            </div>

            <div class="form-group">
                <label for="annee">Année de fabrication</label>
                <input
                    type="number"
                    id="annee"
                    name="annee"
                    min="1900"
                    max="<?= date("Y") + 1 ?>"
                    value="<?= $vehicule["annee"] !== null
                        ? e($vehicule["annee"])
                        : "" ?>"
                >
            </div>

            <div class="form-group">
                <label for="tarif_journalier">Tarif journalier (FCFA) *</label>
                <input
                    type="number"
                    id="tarif_journalier"
                    name="tarif_journalier"
                    min="1"
                    step="1"
                    required
                    value="<?= e($vehicule["tarif_journalier"]) ?>"
                >
            </div>

            <div class="form-group">
                <label for="statut">Statut du véhicule *</label>
                <select id="statut" name="statut" required>
                    <option
                        value="disponible"
                        <?= $vehicule["statut"] === "disponible" ? "selected" : "" ?>
                    >
                        Disponible
                    </option>

                    <option
                        value="maintenance"
                        <?= $vehicule["statut"] === "maintenance" ? "selected" : "" ?>
                    >
                        En maintenance
                    </option>

                    <?php if ($vehicule["statut"] === "loue"): ?>
                        <option value="loue" selected>Loué</option>
                    <?php endif; ?>
                </select>
            </div>

            <div class="form-actions">
                <button type="submit" class="btn-primary">
                    Enregistrer les modifications
                </button>

                <a href="index.php" class="btn-secondary">
                    Annuler
                </a>
            </div>

        </form>

    </div>

</div>

<?php require_once __DIR__ . "/../../includes/footer.php"; ?>
