
<?php
// Charger les paramètres de sécurité et les fonctions communes.
require_once __DIR__ . "/../../config/securite.php";
require_once __DIR__ . "/../../includes/fonctions.php";

// Afficher l'en-tête et le menu de navigation.
require_once __DIR__ . "/../../includes/header.php";
require_once __DIR__ . "/../../includes/sidebar.php";
?>

<div class="main-content">

    <h1 class="page-title">Ajouter un véhicule</h1>

    <p class="page-description">
        Remplissez les informations du véhicule à ajouter au parc automobile.
    </p>

    <div class="dashboard-card">

        <!-- Envoyer les informations au fichier de traitement. -->
        <form action="../../traitements/vehicules/ajouter.php" method="POST">

            <!-- Jeton de sécurité contre les soumissions non autorisées. -->
            <input
                type="hidden"
                name="csrf_token"
                value="<?= e(csrf_token()) ?>"
            >

            <div class="form-group">
                <label for="marque_modele">Marque et modèle </label>
                <input
                    type="text"
                    id="marque_modele"
                    name="marque_modele"
                    maxlength="150"
                    required
                    placeholder="Exemple : Toyota Corolla"
                >
            </div>

            <div class="form-group">
                <label for="immatriculation">Immatriculation </label>
                <input
                    type="text"
                    id="immatriculation"
                    name="immatriculation"
                    maxlength="30"
                    required
                    placeholder="Exemple : AB-1234-CD"
                >
            </div>

            <div class="form-group">
                <label for="annee">Année de fabrication</label>
                <input
                    type="number"
                    id="annee"
                    name="annee"
                    min="1900"
                    max="<?= date('Y') + 1 ?>"
                    placeholder="Exemple : 2022"
                >
            </div>

            <div class="form-group">
                <label for="tarif_journalier">Tarif journalier (FCFA) </label>
                <input
                    type="number"
                    id="tarif_journalier"
                    name="tarif_journalier"
                    min="1"
                    step="1"
                    required
                    placeholder="Exemple : 25000"
                >
            </div>

            <div class="form-group">
                <label for="statut">Statut du véhicule </label>
                <select id="statut" name="statut" required>
                    <option value="disponible">Disponible</option>
                    <option value="maintenance">En maintenance</option>
                </select>
            </div>

            <div class="form-actions">
                <button type="submit" class="btn-primary">
                    Enregistrer le véhicule
                </button>

                <a href="index.php" class="btn-secondary">
                    Annuler
                </a>
            </div>

        </form>

    </div>

</div>

<?php require_once __DIR__ . "/../../includes/footer.php"; ?>
