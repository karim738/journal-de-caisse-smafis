
<?php

// 1. Charger les protections de sécurité et démarrer la session.
require_once __DIR__ . "/../../config/securite.php";

// 2. Charger la connexion à la base de données.
require_once __DIR__ . "/../../config/connexion.php";

// 3. Charger les fonctions communes.
require_once __DIR__ . "/../../includes/fonctions.php";

// 4. Charger le système d'authentification.
require_once __DIR__ . "/../../config/authentification.php";

// 5. Vérifier que l'administrateur est connecté.
exiger_connexion();

// 6. Récupérer les véhicules enregistrés.
$requete = $pdo->query(
    "SELECT id, marque_modele, immatriculation, annee,
            tarif_journalier, statut
     FROM vehicule
     ORDER BY id DESC"
);

$vehicules = $requete->fetchAll();

// Afficher l'en-tête et le menu.
require_once __DIR__ . "/../../includes/header.php";
require_once __DIR__ . "/../../includes/sidebar.php";
?>

<div class="main-content">

    <h1 class="page-title">Gestion des véhicules</h1>

    <p class="page-description">
        Consulte les véhicules enregistrés dans ton parc automobile.
    </p>

    <?php if (isset($_GET["ajout"]) && $_GET["ajout"] === "success"): ?>
        <div class="message-success">
            Le véhicule a été enregistré avec succès.
        </div>
    <?php endif; ?>

    <?php if (isset($_GET["erreur"]) && $_GET["erreur"] === "introuvable"): ?>
        <div class="message-success">
            Le véhicule demandé est introuvable.
        </div>
    <?php endif; ?>
<?php if (isset($_GET["modification"]) && $_GET["modification"] === "success"): ?>
    <div class="message-success">
        Le véhicule a été modifié avec succès.
    </div>
<?php endif; ?>

<?php if (isset($_GET["suppression"]) && $_GET["suppression"] === "success"): ?>
    <div class="message-success">
        Le véhicule a été supprimé avec succès.
    </div>
<?php endif; ?>

<?php if (isset($_GET["erreur"]) && $_GET["erreur"] === "historique"): ?>
    <div class="message-success">
        Impossible de supprimer ce véhicule : il possède un historique de location.
    </div>
<?php endif; ?>
    <div style="margin-top: 20px;">
        <a href="ajouter.php" class="btn-primary">
            + Ajouter un véhicule
        </a>
    </div>

    <div class="table-container">

        <table class="data-table">

            <thead>
                <tr>
                    <th>Marque et modèle</th>
                    <th>Immatriculation</th>
                    <th>Année</th>
                    <th>Tarif journalier</th>
                    <th>Statut</th>
                    <th>Actions</th>
                </tr>
            </thead>

            <tbody>

                <?php if (empty($vehicules)): ?>

                    <tr>
                        <td colspan="6">
                            Aucun véhicule n'est enregistré pour le moment.
                        </td>
                    </tr>

                <?php else: ?>

                    <?php foreach ($vehicules as $vehicule): ?>

                        <tr>
                            <td><?= e($vehicule["marque_modele"]) ?></td>

                            <td><?= e($vehicule["immatriculation"]) ?></td>

                            <td>
                                <?= $vehicule["annee"] !== null
                                    ? e($vehicule["annee"])
                                    : "Non renseignée" ?>
                            </td>

                            <td>
                                <?= number_format(
                                    (float) $vehicule["tarif_journalier"],
                                    0,
                                    ",",
                                    " "
                                ) ?> FCFA
                            </td>

                            <td>
                                <?php
                                // Traduire les statuts techniques en français.
                                $statuts = [
                                    "disponible" => "Disponible",
                                    "loue" => "Loué",
                                    "maintenance" => "En maintenance"
                                ];
                                ?>
                                <?= e($statuts[$vehicule["statut"]] ?? "Inconnu") ?>
                            </td>
                          <td>
    <!-- Bouton pour modifier le véhicule sélectionné. -->
    <a
        href="modifier.php?id=<?= e($vehicule["id"]) ?>"
        class="icon-action icon-action-edit"
        aria-label="Modifier le véhicule <?= e($vehicule["marque_modele"]) ?>"
        title="Modifier"
    >
        <svg viewBox="0 0 24 24" aria-hidden="true" focusable="false">
            <path d="M12 20h9"></path>
            <path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L8 18l-4 1 1-4Z"></path>
        </svg>
    </a>

    <!-- Formulaire sécurisé pour supprimer le véhicule. -->
    <form
        action="../../traitements/vehicules/supprimer.php"
        method="POST"
        style="display: inline;"
        onsubmit="return confirm('Voulez-vous vraiment supprimer ce véhicule ?');"
    >
        <input
            type="hidden"
            name="id"
            value="<?= e($vehicule["id"]) ?>"
        >

        <input
            type="hidden"
            name="csrf_token"
            value="<?= e(csrf_token()) ?>"
        >

        <button
            type="submit"
            class="icon-action icon-action-delete"
            aria-label="Supprimer le véhicule <?= e($vehicule["marque_modele"]) ?>"
            title="Supprimer"
        >
            <svg viewBox="0 0 24 24" aria-hidden="true" focusable="false">
                <path d="M3 6h18"></path>
                <path d="M8 6V4h8v2"></path>
                <path d="m19 6-1 14H6L5 6"></path>
                <path d="M10 11v5M14 11v5"></path>
            </svg>
        </button>
    </form>
</td>

                        </tr>

                    <?php endforeach; ?>

                <?php endif; ?>

            </tbody>

        </table>

    </div>

</div>

<?php require_once __DIR__ . "/../../includes/footer.php"; ?>
