<?php

// ==================================================
// 1. CHARGEMENT DES FICHIERS NÉCESSAIRES
// ==================================================

// Charger les protections de sécurité et démarrer la session.
require_once __DIR__ . "/../../config/securite.php";

// Charger la connexion à la base de données MySQL.
require_once __DIR__ . "/../../config/connexion.php";

// Charger les fonctions communes du projet.
require_once __DIR__ . "/../../includes/fonctions.php";

// Charger le système d'authentification.
require_once __DIR__ . "/../../config/authentification.php";

// Vérifier que l'administrateur est connecté.
exiger_connexion();

// ==================================================
// 2. RÉCUPÉRATION DES OPÉRATIONS DE CAISSE
// ==================================================

// Récupérer les opérations, de la plus récente à la plus ancienne.
// Les jointures permettent de récupérer le nom du client
// et la catégorie de dépense lorsqu'ils sont renseignés.

$requete = $pdo->query(
    "SELECT
        mc.id,
        mc.date_operation,
        mc.type_operation,
        mc.montant,
        mc.libelle,
        mc.moyen_paiement,
        mc.observations,
        c.nom AS nom_client,
        cd.nom AS nom_categorie
    FROM mouvement_caisse mc
    LEFT JOIN client c
        ON mc.client_id = c.id
    LEFT JOIN categorie_depense cd
        ON mc.categorie_depense_id = cd.id
    ORDER BY mc.date_operation DESC, mc.id DESC"
);

$operations = $requete->fetchAll();


// ==================================================
// 3. CALCUL DES TOTAUX ET DU SOLDE DE CAISSE
// ==================================================

// Additionner séparément toutes les entrées et les sorties.
// COALESCE renvoie 0 lorsqu'aucun mouvement n'est enregistré.

$requeteTotaux = $pdo->query(
    "SELECT
        COALESCE(
            SUM(CASE
                WHEN type_operation = 'entree' THEN montant
                ELSE 0
            END),
            0
        ) AS total_entrees,

        COALESCE(
            SUM(CASE
                WHEN type_operation = 'sortie' THEN montant
                ELSE 0
            END),
            0
        ) AS total_sorties

    FROM mouvement_caisse"
);

$totaux = $requeteTotaux->fetch();

// Convertir les résultats en nombres pour effectuer le calcul.
$totalEntrees = (float) $totaux["total_entrees"];
$totalSorties = (float) $totaux["total_sorties"];

// Le solde est égal aux entrées moins les sorties.
$soldeCaisse = $totalEntrees - $totalSorties;


// ==================================================
// 4. PRÉPARATION DES LIBELLÉS À AFFICHER
// ==================================================

// Traduire les valeurs techniques en français.
$types = [
    "entree" => "Entrée",
    "sortie" => "Sortie"
];

// Traduire les moyens de paiement.
$moyensPaiement = [
    "especes" => "Espèces",
    "mobile_money" => "Mobile Money",
    "virement" => "Virement",
    "cheque" => "Chèque",
    "autre" => "Autre"
];


// ==================================================
// 5. AFFICHAGE DES ÉLÉMENTS COMMUNS
// ==================================================

require_once __DIR__ . "/../../includes/header.php";
require_once __DIR__ . "/../../includes/sidebar.php";
?>

<div class="main-content">

    <!-- Titre et description de la page -->
    <h1 class="page-title">Gestion de la caisse</h1>

    <p class="page-description">
        Consulte les entrées et les sorties d'argent de l'entreprise.
    </p>


    <!-- ==========================================
         6. MESSAGE DE CONFIRMATION
         ========================================== -->

    <?php if (isset($_GET["ajout"]) && $_GET["ajout"] === "success"): ?>

        <div class="message-success">
            L'opération de caisse a été enregistrée avec succès.
        </div>

    <?php endif; ?>


    <!-- ==========================================
         7. RÉSUMÉ FINANCIER
         ========================================== -->

    <div class="dashboard-grid">

        <!-- Total des entrées -->
        <div class="dashboard-card">
            <h3>Total des entrées</h3>

            <p class="dashboard-number">
                <?= number_format($totalEntrees, 0, ",", " ") ?> FCFA
            </p>
        </div>

        <!-- Total des sorties -->
        <div class="dashboard-card">
            <h3>Total des sorties</h3>

            <p class="dashboard-number">
                <?= number_format($totalSorties, 0, ",", " ") ?> FCFA
            </p>
        </div>

        <!-- Solde calculé -->
        <div class="dashboard-card">
            <h3>Solde de caisse</h3>

            <p class="dashboard-number">
                <?= number_format($soldeCaisse, 0, ",", " ") ?> FCFA
            </p>
        </div>

    </div>


    <!-- ==========================================
         8. BOUTON D'AJOUT
         ========================================== -->

    <div style="margin-top: 20px; margin-bottom: 20px;">

        <a href="ajouter.php" class="btn-primary">
            + Ajouter une opération
        </a>

    </div>


    <!-- ==========================================
         9. TABLEAU DES OPÉRATIONS
         ========================================== -->

    <div class="table-container">

        <table class="data-table">

            <!-- En-têtes du tableau -->
            <thead>
                <tr>
                    <th>Date</th>
                    <th>Libellé</th>
                    <th>Type</th>
                    <th>Montant</th>
                    <th>Moyen de paiement</th>
                    <th>Client</th>
                    <th>Catégorie</th>
                </tr>
            </thead>


            <!-- Contenu du tableau -->
            <tbody>

                <?php if (empty($operations)): ?>

                    <!-- Message lorsque la caisse est vide -->
                    <tr>
                        <td colspan="7">
                            Aucune opération de caisse n'est enregistrée.
                        </td>
                    </tr>

                <?php else: ?>

                    <!-- Parcourir toutes les opérations récupérées -->
                    <?php foreach ($operations as $operation): ?>

                        <tr>

                            <!-- Date de l'opération -->
                            <td>
                                <?= e($operation["date_operation"]) ?>
                            </td>

                            <!-- Description de l'opération -->
                            <td>
                                <?= e($operation["libelle"]) ?>
                            </td>

                            <!-- Type : entrée ou sortie -->
                            <td>
                                <?= e(
                                    $types[$operation["type_operation"]] ?? "Inconnu"
                                ) ?>
                            </td>

                            <!-- Montant en FCFA -->
                            <td>
                                <?= number_format(
                                    (float) $operation["montant"],
                                    0,
                                    ",",
                                    " "
                                ) ?> FCFA
                            </td>

                            <!-- Moyen de paiement -->
                            <td>
                                <?= e(
                                    $moyensPaiement[$operation["moyen_paiement"]]
                                    ?? "Autre"
                                ) ?>
                            </td>

                            <!-- Client associé, s'il existe -->
                            <td>
                                <?= e($operation["nom_client"] ?? "—") ?>
                            </td>

                            <!-- Catégorie associée, s'il y en a une -->
                            <td>
                                <?= e($operation["nom_categorie"] ?? "—") ?>
                            </td>

                        </tr>

                    <?php endforeach; ?>

                <?php endif; ?>

            </tbody>

        </table>

    </div>

</div>

<?php
// Charger le pied de page et fermer la structure HTML.
require_once __DIR__ . "/../../includes/footer.php";
?>
