
<?php

// 1. Démarrer la session et charger la sécurité.
require_once __DIR__ . "/../../config/securite.php";

// 2. Charger la connexion à la base de données.
require_once __DIR__ . "/../../config/connexion.php";

// 3. Charger les fonctions communes.
require_once __DIR__ . "/../../includes/fonctions.php";

// 4. Charger le système d'authentification.
require_once __DIR__ . "/../../config/authentification.php";

// 5. Vérifier que l'administrateur est connecté.
exiger_connexion();

// Récupérer les clients pour les proposer dans le formulaire.
$requeteClients = $pdo->query(
    "SELECT id, nom FROM client ORDER BY nom ASC"
);
$clients = $requeteClients->fetchAll();

// Récupérer les locations pour permettre d'associer un paiement.
$requeteLocations = $pdo->query(
    "SELECT l.id, c.nom, v.marque_modele,
            l.date_debut, l.date_fin, l.montant_total
     FROM location l
     INNER JOIN client c ON l.client_id = c.id
     INNER JOIN vehicule v ON l.vehicule_id = v.id
     ORDER BY l.id DESC"
);
$locations = $requeteLocations->fetchAll();

// Récupérer les catégories de dépenses.
$requeteCategories = $pdo->query(
    "SELECT id, nom FROM categorie_depense ORDER BY nom ASC"
);
$categories = $requeteCategories->fetchAll();

// Charger les éléments communs de la page.
require_once __DIR__ . "/../../includes/header.php";
require_once __DIR__ . "/../../includes/sidebar.php";
?>

<div class="main-content">
    <h1 class="page-title">Ajouter une opération de caisse</h1>

    <p class="page-description">
        Enregistre une entrée ou une sortie d'argent.
    </p>

    <form action="../../traitements/caisse/ajouter.php"
          method="POST">

        <!-- Protection du formulaire contre les requêtes CSRF. -->
        <input type="hidden"
               name="csrf_token"
               value="<?= e(csrf_token()) ?>">

        <div class="form-group">
            <label for="date_operation">Date de l'opération</label>
            <input type="date"
                   id="date_operation"
                   name="date_operation"
                   value="<?= e(date('d-m-Y')) ?>"
                   required>
        </div>

        <div class="form-group">
            <label for="type_operation">Type d'opération</label>
            <select id="type_operation"
                    name="type_operation"
                    required>
                <option value="">Choisir le type</option>
                <option value="entree">Entrée d'argent</option>
                <option value="sortie">Sortie d'argent</option>
            </select>
        </div>

        <div class="form-group">
            <label for="montant">Montant (FCFA)</label>
            <input type="number"
                   id="montant"
                   name="montant"
                   min="1"
                   step="1"
                   required>
        </div>

        <div class="form-group">
            <label for="libelle">Libellé de l'opération</label>
            <input type="text"
                   id="libelle"
                   name="libelle"
                   maxlength="255"
                   placeholder="Ex. : Paiement location ou achat de carburant"
                   required>
        </div>

        <div class="form-group">
            <label for="moyen_paiement">Moyen de paiement</label>
            <select id="moyen_paiement"
                    name="moyen_paiement"
                    required>
                <option value="">Choisir un moyen de paiement</option>
                <option value="especes">Espèces</option>
                <option value="mobile_money">Mobile Money</option>
                <option value="virement">Virement bancaire</option>
                <option value="cheque">Chèque</option>
                <option value="autre">Autre</option>
            </select>
        </div>

        <div class="form-group">
            <label for="client_id">Client associé (facultatif)</label>
            <select id="client_id" name="client_id">
                <option value="">Aucun client</option>

                <?php foreach ($clients as $client): ?>
                    <option value="<?= (int) $client['id'] ?>">
                        <?= e($client['nom']) ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="form-group">
            <label for="location_id">Location associée (facultatif)</label>
            <select id="location_id" name="location_id">
                <option value="">Aucune location</option>

                <?php foreach ($locations as $location): ?>
                    <option value="<?= (int) $location['id'] ?>">
                        <?= e($location['nom']) ?> —
                        <?= e($location['marque_modele']) ?> —
                        <?= e($location['date_debut']) ?>
                        au <?= e($location['date_fin']) ?> —
                        <?= number_format((float) $location['montant_total'], 0, ',', ' ') ?> FCFA
                    </option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="form-group">
            <label for="categorie_depense_id">
                Catégorie de dépense
            </label>
            <select id="categorie_depense_id"
                    name="categorie_depense_id">
                <option value="">Choisir une catégorie</option>
                <?php foreach ($categories as $categorie): ?>
                    <option value="<?= (int) $categorie['id'] ?>">
                        <?= e($categorie['nom']) ?>
                    </option>
                <?php endforeach; ?>
            </select>
            <small id="aide_categorie">
                La catégorie est obligatoire pour une sortie d'argent.
            </small>
        </div>

        <div class="form-group">
            <label for="observations">Observations (facultatif)</label>
            <textarea id="observations"
                      name="observations"
                      rows="4"
                      maxlength="2000"
                      placeholder="Informations complémentaires"></textarea>
        </div>

        <button type="submit" class="btn-primary">
            Enregistrer l'opération
        </button>

        <a href="index.php" class="btn-secondary">Retour</a>
    </form>
</div>

<script>
document.addEventListener("DOMContentLoaded", function () {
    const typeOperation = document.getElementById("type_operation");
    const categorie = document.getElementById("categorie_depense_id");
    const aideCategorie = document.getElementById("aide_categorie");

    function actualiserCategorie() {
        const sortie = typeOperation.value === "sortie";

        categorie.disabled = !sortie;
        categorie.required = sortie;

        if (!sortie) {
            categorie.value = "";
            aideCategorie.textContent =
                "La catégorie est utilisée uniquement pour les sorties d'argent.";
        } else if (categorie.options.length === 1) {
            aideCategorie.textContent =
                "Aucune catégorie n'est enregistrée. Ajoute des catégories dans la base de données.";
        } else {
            aideCategorie.textContent =
                "Sélectionne la catégorie correspondant à cette dépense.";
        }
    }

    typeOperation.addEventListener("change", actualiserCategorie);
    actualiserCategorie();
});
</script>

<?php require_once __DIR__ . "/../../includes/footer.php"; ?>
