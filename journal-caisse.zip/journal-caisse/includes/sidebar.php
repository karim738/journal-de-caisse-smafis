
<?php

/**
 * ============================================================
 * 1. CONFIGURATION GÉNÉRALE
 * ============================================================
 */

// Chemin de base du projet sur le serveur.
$baseUrl = "/journal-caisse/";

// Récupération du chemin de la page actuelle, sans les paramètres URL.
$currentPath = parse_url(
    $_SERVER["REQUEST_URI"] ?? "/",
    PHP_URL_PATH
) ?: "/";

// Normalisation du chemin actuel.
$currentPath = "/" . trim($currentPath, "/");

// Normalisation du chemin de base.
$basePath = "/" . trim($baseUrl, "/");

// Détermination du chemin relatif à l'application.
if (
    $currentPath === $basePath
    || $currentPath === $basePath . "/"
) {
    $relativePath = "";
} elseif (strpos($currentPath, $basePath . "/") === 0) {
    $relativePath = substr(
        $currentPath,
        strlen($basePath) + 1
    );
} else {
    $relativePath = ltrim($currentPath, "/");
}

/**
 * ============================================================
 * 2. MENU DE NAVIGATION
 * ============================================================
 */

$navigation = [
    [
        "label" => "Vue d'ensemble",
        "href"  => $baseUrl,
        "icon"  => "⌂",
        "match" => ["", "index.php"]
    ],
    [
        "label" => "Locations",
        "href"  => $baseUrl . "modules/locations/index.php",
        "icon"  => "↗",
        "match" => ["modules/locations"]
    ],
    [
        "label" => "Véhicules",
        "href"  => $baseUrl . "modules/vehicules/index.php",
        "icon"  => "🚗",
        "match" => ["modules/vehicules"]
    ],
    [
        "label" => "Clients",
        "href"  => $baseUrl . "modules/clients/index.php",
        "icon"  => "👥",
        "match" => ["modules/clients"]
    ],
    [
        "label" => "Journal de caisse",
        "href"  => $baseUrl . "modules/caisse/index.php",
        "icon"  => "◷",
        "match" => ["modules/caisse"]
    ],
    [
        "label" => "Rapports",
        "href"  => $baseUrl . "modules/rapports/index.php",
        "icon"  => "▥",
        "match" => ["modules/rapports"]
    ]
];

/**
 * ============================================================
 * 3. DÉTECTION DU MODULE ACTIF
 * ============================================================
 */

// Vérifie si le chemin courant appartient au module indiqué.
$isNavigationActive = static function (
    string $relativePath,
    array $item
): bool {
    foreach ($item["match"] as $match) {

        // Gestion de la page d'accueil.
        if (
            $match === ""
            && ($relativePath === "" || $relativePath === "index.php")
        ) {
            return true;
        }

        // Correspondance avec le chemin du module et ses sous-pages.
        if (
            $match !== ""
            && (
                $relativePath === $match
                || strpos($relativePath, $match . "/") === 0
            )
        ) {
            return true;
        }
    }

    return false;
};

/**
 * ============================================================
 * 4. INFORMATIONS DE L'ADMINISTRATEUR ET DATE
 * ============================================================
 */

// Nom de l'administrateur enregistré dans la session.
$nomAdministrateur = $_SESSION["administrateur_nom"] ?? "Administrateur";

// Vérification du nom pour éviter une valeur vide ou inattendue.
if (
    !is_string($nomAdministrateur)
    || trim($nomAdministrateur) === ""
) {
    $nomAdministrateur = "Administrateur";
}

$motsNomAdministrateur = preg_split(
    '/\s+/u',
    trim($nomAdministrateur),
    -1,
    PREG_SPLIT_NO_EMPTY
);
$initialesAdministrateur = "";

if (is_array($motsNomAdministrateur)) {
    foreach (array_slice($motsNomAdministrateur, 0, 2) as $mot) {
        $initialesAdministrateur .= function_exists("mb_substr")
            ? mb_substr($mot, 0, 1, "UTF-8")
            : substr($mot, 0, 1);
    }
}

$initialesAdministrateur = function_exists("mb_strtoupper")
    ? mb_strtoupper($initialesAdministrateur, "UTF-8")
    : strtoupper($initialesAdministrateur);
$initialesAdministrateur = $initialesAdministrateur !== ""
    ? $initialesAdministrateur
    : "A";

// Date du jour selon le fuseau horaire de la Côte d'Ivoire.
$dateDuJour = (new DateTimeImmutable(
    "now",
    new DateTimeZone("Africa/Abidjan")
))->format("d/m/Y");

// Année actuelle pour le pied de page.
$anneeActuelle = (new DateTimeImmutable(
    "now",
    new DateTimeZone("Africa/Abidjan")
))->format("Y");

?>

<!-- Conteneur principal de l'application -->
<div class="app-shell">

    <!-- ======================================================
         MENU LATÉRAL
         ====================================================== -->
    <aside class="sidebar" id="app-sidebar">

        <!-- Logo et lien vers l'accueil -->
        <a
            class="brand"
            href="<?= e($baseUrl) ?>"
            aria-label="Journal de caisse, accueil"
        >
            <span class="brand-mark" aria-hidden="true">J</span>

            <span class="brand-copy">
                <strong>Journal</strong>
                <small>GESTION DE FLOTTE</small>
            </span>
        </a>

        <!-- Titre de la navigation -->
        <div class="sidebar-section-label">
            ESPACE DE TRAVAIL
        </div>

        <!-- Liens vers les modules -->
        <nav class="primary-nav" aria-label="Navigation principale">

            <?php foreach ($navigation as $item): ?>

                <?php
                // Détermine si le lien correspond à la page actuelle.
                $isActive = $isNavigationActive($relativePath, $item);
                ?>

                <a
                    class="nav-link<?= $isActive ? " is-active" : "" ?>"
                    href="<?= e($item["href"]) ?>"
                    <?= $isActive ? 'aria-current="page"' : "" ?>
                >
                    <!-- Icône du module -->
                    <span class="nav-icon" aria-hidden="true">
                        <?= e($item["icon"]) ?>
                    </span>

                    <!-- Libellé du module -->
                    <span><?= e($item["label"]) ?></span>

                    <!-- Indicateur de la page active -->
                    <?php if ($isActive): ?>
                        <span
                            class="nav-indicator"
                            aria-hidden="true"
                        ></span>
                    <?php endif; ?>
                </a>

            <?php endforeach; ?>

        </nav>

        <!-- Bas du menu latéral -->
        <div class="sidebar-bottom">

            <!-- Signature de l'application -->
            <div class="sidebar-footer">
                Doss-Dev<span>•</span><?= e($anneeActuelle) ?>
            </div>

        </div>

    </aside>

    <!-- ======================================================
         ESPACE DE TRAVAIL
         ====================================================== -->
    <div class="workspace">

        <!-- Barre supérieure -->
        <header class="topbar">

            <!-- Bouton d'ouverture du menu sur mobile -->
            <button
                class="menu-toggle"
                type="button"
                aria-label="Ouvrir le menu"
                aria-controls="app-sidebar"
                aria-expanded="false"
                data-menu-toggle
            >
                <span></span>
                <span></span>
                <span></span>
            </button>

            <!-- Recherche dans le tableau affiché -->
            <label class="global-search">

                <span class="search-icon" aria-hidden="true">⌕</span>

                <input
                    type="search"
                    placeholder="Rechercher dans ce tableau…"
                    aria-label="Rechercher dans le tableau affiché"
                    aria-keyshortcuts="Control+K Meta+K"
                    data-table-search
                >

                <kbd data-search-shortcut>recherche</kbd>

            </label>

            <!-- Date actuelle -->
            <div class="topbar-date">
                <span><?= e($dateDuJour) ?></span>
            </div>

            <!-- ==================================================
                 PROFIL ADMINISTRATEUR
                 ================================================== -->
            <details class="profile-menu" data-profile-menu>

                <!-- Bouton ouvrant le menu du profil -->
                <summary
                    class="profile-menu-trigger"
                    aria-label="Ouvrir le menu du profil de <?= e($nomAdministrateur) ?>"
                    title="<?= e($nomAdministrateur) ?>"
                >
                    <!-- Avatar du compte administrateur -->
                    <span
                        class="profile-menu-avatar"
                        aria-hidden="true"
                    ><?= e($initialesAdministrateur) ?>
                    </span>
                </summary>

                <!-- Contenu du menu déroulant -->
                <div class="profile-menu-dropdown">

                    <!-- Informations du compte -->
                    <div class="profile-menu-account">

                        <span
                            class="profile-menu-account-avatar"
                            aria-hidden="true"
                        ><?= e($initialesAdministrateur) ?></span>

                        <span>
                            <strong>
                                <?= e($nomAdministrateur) ?>
                            </strong>

                            <small>Administrateur</small>
                        </span>

                    </div>

                    <!-- Accès à la page du compte -->
                    <a
                        class="profile-menu-item"
                        href="<?= e($baseUrl) ?>admin/compte/index.php"
                    >
                        <svg viewBox="0 0 20 20" aria-hidden="true">
                            <circle cx="10" cy="6.5" r="3"></circle>
                            <path d="M4.5 16v-1a5.5 5.5 0 0 1 11 0v1z"></path>
                        </svg>
                        Mon profil
                    </a>

                    <!-- Formulaire de déconnexion sécurisé -->
                    <form
                        class="topbar-logout-form"
                        method="POST"
                        action="<?= e($baseUrl) ?>admin/deconnexion.php"
                        onsubmit="return confirm('Voulez-vous vraiment vous déconnecter ?');"
                    >
                        <!-- Jeton de protection CSRF -->
                        <input
                            type="hidden"
                            name="csrf_token"
                            value="<?= e(csrf_token()) ?>"
                        >

                        <!-- Bouton de déconnexion -->
                        <button
                            class="topbar-logout"
                            type="submit"
                        >
                            <span
                                class="topbar-logout-icon"
                                aria-hidden="true"
                            >
                                <svg viewBox="0 0 20 20" aria-hidden="true">
                                    <path d="M8 4H4v12h4M11 6l4 4-4 4m4-4H8"></path>
                                </svg>
                            </span>

                            <span class="topbar-logout-label">
                                Déconnexion
                            </span>
                        </button>

                    </form>

                </div>

            </details>

        </header>
