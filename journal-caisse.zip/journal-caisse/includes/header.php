<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="theme-color" content="#111a2e">
    <title>Journal de caisse | Gestion de flotte</title>
    <link
        rel="stylesheet"
        href="/journal-caisse/assets/css/style.css?v=<?= (int) filemtime(__DIR__ . "/../assets/css/style.css") ?>"
    >
</head>

<body>
