    </div>
</div>
<div class="sidebar-backdrop" data-menu-backdrop></div>
<script src="/journal-caisse/assets/js/app.js" defer></script>
</body>
</html>
