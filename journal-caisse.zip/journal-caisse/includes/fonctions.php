
<?php

/**
 * Protège une valeur avant de l'afficher dans une page HTML.
 *
 * Exemple :
 * echo e($client["nom"]);
 *
 * Les caractères spéciaux sont convertis pour éviter
 * qu'un texte saisi soit interprété comme du code HTML.
 *
 * @param mixed $valeur Valeur à afficher.
 * @return string Valeur sécurisée pour le HTML.
 */
function e($valeur): string
{
    return htmlspecialchars(
        (string) $valeur,
        ENT_QUOTES | ENT_SUBSTITUTE,
        "UTF-8"
    );
}


/**
 * Crée un jeton CSRF pour sécuriser les formulaires.
 *
 * Le jeton est conservé dans la session de l'utilisateur.
 */
function csrf_token(): string
{
    // Créer le jeton uniquement s'il n'existe pas encore.
    if (
        !isset($_SESSION["csrf_token"])
        || !is_string($_SESSION["csrf_token"])
    ) {
        $_SESSION["csrf_token"] = bin2hex(random_bytes(32));
    }

    return $_SESSION["csrf_token"];
}

/**
 * Vérifie le jeton CSRF envoyé par un formulaire.
 *
 * En cas d'absence ou d'invalidité, la requête est refusée.
 */
function csrf_verifier(): void
{
    // Récupérer le jeton envoyé par le formulaire.
    $jetonFormulaire = $_POST["csrf_token"] ?? null;

    // Récupérer le jeton conservé dans la session.
    $jetonSession = $_SESSION["csrf_token"] ?? null;

    // Refuser la requête si les jetons sont absents ou invalides.
    if (
        !is_string($jetonFormulaire)
        || !is_string($jetonSession)
        || !hash_equals($jetonSession, $jetonFormulaire)
    ) {
        http_response_code(403);
        exit("Requête refusée. Rechargez le formulaire et réessayez.");
    }
}
