
<?php

// Paramètres de connexion à la base de données.
$serveur = "localhost";
$baseDeDonnees = "journal_caisse";
$utilisateur = "root";
$motDePasse = ""; // Configuration habituelle de WAMP en local.
$charset = "utf8mb4";

// Construction de l'adresse de connexion PDO.
$dsn = "mysql:host=$serveur;dbname=$baseDeDonnees;charset=$charset";

// Options pour rendre les requêtes PDO plus sûres et prévisibles.
$options = [
    // Les erreurs SQL déclenchent des exceptions.
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,

    // Les résultats sont retournés sous forme de tableaux associatifs.
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,

    // Utilisation des requêtes préparées natives lorsque possible.
    PDO::ATTR_EMULATE_PREPARES => false
];

try {
    // Tentative de connexion à MySQL.
    $pdo = new PDO($dsn, $utilisateur, $motDePasse, $options);

} catch (PDOException $erreur) {

    // Enregistrer les détails techniques dans les journaux du serveur.
    // Ne jamais afficher le message SQL détaillé aux visiteurs.
    error_log("Erreur de connexion à la base journal_caisse : " . $erreur->getMessage());

    // Indiquer que le serveur n'a pas pu traiter la demande.
    http_response_code(500);

    // Afficher un message neutre sans révéler les paramètres de connexion.
    exit("Une erreur technique empêche temporairement l'accès à l'application.");
}
