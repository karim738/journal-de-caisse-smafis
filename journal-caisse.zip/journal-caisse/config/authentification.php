<?php

// Ce fichier contient les fonctions qui protègent
// les pages de l'application et contrôlent les droits d'accès.

require_once __DIR__ . "/securite.php";

/**
 * Vérifie si un administrateur est connecté.
 *
 * On vérifie que son identifiant est bien un entier
 * enregistré dans la session.
 */
function administrateur_connecte(): bool
{
    return isset($_SESSION["administrateur_id"])
        && is_int($_SESSION["administrateur_id"]);
}

/**
 * Vérifie si l'administrateur connecté possède le rôle principal.
 */
function administrateur_principal(): bool
{
    return administrateur_connecte()
        && isset($_SESSION["administrateur_role"])
        && $_SESSION["administrateur_role"] === "principal";
}

/**
 * Vérifie si l'administrateur connecté possède le rôle secondaire.
 */
function administrateur_secondaire(): bool
{
    return administrateur_connecte()
        && isset($_SESSION["administrateur_role"])
        && $_SESSION["administrateur_role"] === "secondaire";
}

/**
 * Empêche l'accès à une page si aucun administrateur
 * n'est connecté.
 */
function exiger_connexion(): void
{
    if (!administrateur_connecte()) {
        header("Location: /journal-caisse/admin/connexion.php");
        exit;
    }
}

/**
 * Réserve une page à l'administrateur principal.
 *
 * Si un administrateur secondaire tente d'accéder
 * à cette page, l'accès est refusé.
 */
function exiger_administrateur_principal(): void
{
    // Vérifier d'abord que l'utilisateur est connecté.
    exiger_connexion();

    // Vérifier ensuite qu'il possède le rôle principal.
    if (!administrateur_principal()) {
        http_response_code(403);

        exit("Accès refusé : vous ne disposez pas des droits nécessaires.");
    }
}