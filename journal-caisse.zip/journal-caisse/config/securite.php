
<?php
// Empêche l'affichage des erreurs techniques aux visiteurs.
// En développement, nous pourrons les consulter dans les journaux de PHP.
ini_set("display_errors", "0");
ini_set("log_errors", "1");

// Configure la session avant son démarrage.
if (session_status() === PHP_SESSION_NONE) {

    // Empêche JavaScript de lire directement le cookie de session.
    ini_set("session.cookie_httponly", "1");

    // Autorise le cookie uniquement dans le contexte adapté.
    // En local HTTP, false permet de tester avec WAMP.
    // En production HTTPS, cette valeur devra être true.
    ini_set("session.cookie_secure", "0");

    // Limite l'envoi du cookie lors de navigations externes.
    ini_set("session.cookie_samesite", "Lax");

    // Démarre la session PHP.
    session_start();
}
