
<?php

require_once __DIR__ . "/../../config/authentification.php";

exiger_connexion();
// Charger la sécurité et les fonctions communes.
require_once __DIR__ . "/../../config/securite.php";
require_once __DIR__ . "/../../includes/fonctions.php";

// Accepter uniquement les données envoyées par un formulaire POST.
if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    header("Location: ../../modules/vehicules/index.php");
    exit;
}

// Vérifier le jeton de sécurité du formulaire.
csrf_verifier();

// Récupérer les informations envoyées par le formulaire.
$idBrut = $_POST["id"] ?? null;
$marqueModele = trim($_POST["marque_modele"] ?? "");
$immatriculation = trim($_POST["immatriculation"] ?? "");
$anneeBrute = trim($_POST["annee"] ?? "");
$tarifBrut = trim($_POST["tarif_journalier"] ?? "");
$statut = $_POST["statut"] ?? "";

// Vérifier l'identifiant du véhicule.
$id = is_string($idBrut)
    ? filter_var($idBrut, FILTER_VALIDATE_INT)
    : false;

if ($id === false || $id === null || $id < 1) {
    http_response_code(400);
    exit("Identifiant du véhicule invalide.");
}

// Préparer la liste des erreurs de validation.
$erreurs = [];

// Vérifier la marque et le modèle.
if ($marqueModele === "" || strlen($marqueModele) > 150) {
    $erreurs[] = "La marque et le modèle sont obligatoires (150 caractères maximum).";
}

// Vérifier l'immatriculation.
if ($immatriculation === "" || strlen($immatriculation) > 30) {
    $erreurs[] = "L'immatriculation est obligatoire (30 caractères maximum).";
}

// Vérifier l'année de fabrication.
$annee = null;

if ($anneeBrute !== "") {
    $anneeValidee = filter_var($anneeBrute, FILTER_VALIDATE_INT);

    if (
        $anneeValidee === false ||
        $anneeValidee < 1900 ||
        $anneeValidee > (int) date("Y") + 1
    ) {
        $erreurs[] = "L'année de fabrication est invalide.";
    } else {
        $annee = $anneeValidee;
    }
}

// Vérifier le tarif journalier.
$tarif = filter_var($tarifBrut, FILTER_VALIDATE_INT);

if ($tarif === false || $tarif < 1) {
    $erreurs[] = "Le tarif journalier doit être un entier supérieur à zéro.";
}

// Vérifier le statut demandé.
if (!in_array($statut, ["disponible", "maintenance", "loue"], true)) {
    $erreurs[] = "Le statut du véhicule est invalide.";
}

// Si les données sont incorrectes, arrêter le traitement.
if (!empty($erreurs)) {
    http_response_code(422);
    exit("Modification refusée : " . implode(" ", $erreurs));
}

// Charger la connexion à la base de données.
require_once __DIR__ . "/../../config/connexion.php";

try {
    // Vérifier que le véhicule existe et récupérer son statut actuel.
    $requeteVerification = $pdo->prepare(
        "SELECT statut FROM vehicule WHERE id = :id"
    );
    $requeteVerification->execute([":id" => $id]);
    $vehiculeExistant = $requeteVerification->fetch();

    if (!$vehiculeExistant) {
        header("Location: ../../modules/vehicules/index.php?erreur=introuvable");
        exit;
    }

    // Empêcher de changer manuellement le statut d'un véhicule loué.
    if (
        $vehiculeExistant["statut"] === "loue" &&
        $statut !== "loue"
    ) {
        http_response_code(422);
        exit("Ce véhicule est marqué comme loué. Son statut doit être géré par le module des locations.");
    }

    // Préparer la mise à jour des informations du véhicule.
    $requete = $pdo->prepare(
        "UPDATE vehicule
         SET marque_modele = :marque_modele,
             immatriculation = :immatriculation,
             annee = :annee,
             tarif_journalier = :tarif_journalier,
             statut = :statut
         WHERE id = :id"
    );

    // Exécuter la modification avec des paramètres sécurisés.
    $requete->execute([
        ":marque_modele" => $marqueModele,
        ":immatriculation" => $immatriculation,
        ":annee" => $annee,
        ":tarif_journalier" => $tarif,
        ":statut" => $statut,
        ":id" => $id
    ]);

    // Revenir à la liste après une modification réussie.
    header("Location: ../../modules/vehicules/index.php?modification=success");
    exit;

} catch (PDOException $erreur) {
    // Enregistrer le détail technique sans l'afficher au visiteur.
    error_log("Erreur lors de la modification d'un véhicule : " . $erreur->getMessage());

    // Détecter une immatriculation déjà utilisée.
    if (
        $erreur->getCode() === "23000" ||
        (isset($erreur->errorInfo[1]) && (int) $erreur->errorInfo[1] === 1062)
    ) {
        http_response_code(409);
        exit("Cette immatriculation est déjà utilisée par un autre véhicule.");
    }

    http_response_code(500);
    exit("Une erreur technique empêche la modification du véhicule.");
}
