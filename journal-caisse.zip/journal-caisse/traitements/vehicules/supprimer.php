
<?php

require_once __DIR__ . "/../../config/authentification.php";

exiger_connexion();
// Charger les paramètres de sécurité et les fonctions communes.
require_once __DIR__ . "/../../config/securite.php";
require_once __DIR__ . "/../../includes/fonctions.php";

// La suppression doit obligatoirement passer par un formulaire POST.
if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    header("Location: ../../modules/vehicules/index.php");
    exit;
}

// Vérifier le jeton CSRF pour empêcher les requêtes non autorisées.
csrf_verifier();

// Récupérer et vérifier l'identifiant du véhicule.
$idBrut = $_POST["id"] ?? null;

$id = is_string($idBrut)
    ? filter_var($idBrut, FILTER_VALIDATE_INT)
    : false;

if ($id === false || $id === null || $id < 1) {
    http_response_code(400);
    exit("Identifiant du véhicule invalide.");
}

// Charger la connexion à la base de données.
require_once __DIR__ . "/../../config/connexion.php";

try {
    // Vérifier que le véhicule existe.
    $requete = $pdo->prepare(
        "SELECT id FROM vehicule WHERE id = :id"
    );
    $requete->execute([":id" => $id]);

    if (!$requete->fetch()) {
        header("Location: ../../modules/vehicules/index.php?erreur=introuvable");
        exit;
    }

    // Vérifier si le véhicule est déjà utilisé dans une location.
    $requeteLocations = $pdo->prepare(
        "SELECT COUNT(*) FROM location WHERE vehicule_id = :id"
    );
    $requeteLocations->execute([":id" => $id]);

    $nombreLocations = (int) $requeteLocations->fetchColumn();

    // Empêcher la suppression si un historique de location existe.
    if ($nombreLocations > 0) {
        header("Location: ../../modules/vehicules/index.php?erreur=historique");
        exit;
    }

    // Supprimer le véhicule uniquement s'il n'a pas d'historique.
    $requeteSuppression = $pdo->prepare(
        "DELETE FROM vehicule WHERE id = :id"
    );
    $requeteSuppression->execute([":id" => $id]);

    // Revenir à la liste après la suppression.
    header("Location: ../../modules/vehicules/index.php?suppression=success");
    exit;

} catch (PDOException $erreur) {
    // Conserver le détail technique dans les journaux du serveur.
    error_log("Erreur lors de la suppression d'un véhicule : " . $erreur->getMessage());

    http_response_code(500);
    exit("Une erreur technique empêche la suppression du véhicule.");
}
