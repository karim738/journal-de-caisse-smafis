
<?php

require_once __DIR__ . "/../../config/authentification.php";

exiger_connexion();
// Charger les paramètres de sécurité et les fonctions communes.
require_once __DIR__ . "/../../config/securite.php";
require_once __DIR__ . "/../../includes/fonctions.php";

// Accepter uniquement les formulaires envoyés avec la méthode POST.
if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    header("Location: ../../modules/vehicules/ajouter.php");
    exit;
}

// Vérifier que le jeton de sécurité du formulaire est valide.
csrf_verifier();

// Récupérer les informations envoyées par le formulaire.
$marqueModele = trim($_POST["marque_modele"] ?? "");
$immatriculation = trim($_POST["immatriculation"] ?? "");
$anneeBrute = trim($_POST["annee"] ?? "");
$tarifBrut = trim($_POST["tarif_journalier"] ?? "");
$statut = $_POST["statut"] ?? "";

// Préparer une liste pour enregistrer les erreurs de validation.
$erreurs = [];

// Vérifier la marque et le modèle.
if (
    $marqueModele === "" ||
    strlen($marqueModele) > 150
) {
    $erreurs[] = "La marque et le modèle sont obligatoires (150 caractères maximum).";
}

// Vérifier l'immatriculation.
if (
    $immatriculation === "" ||
    strlen($immatriculation) > 30
) {
    $erreurs[] = "L'immatriculation est obligatoire (30 caractères maximum).";
}

// Vérifier l'année si elle a été renseignée.
$annee = null;

if ($anneeBrute !== "") {
    $anneeValidee = filter_var($anneeBrute, FILTER_VALIDATE_INT);

    if (
        $anneeValidee === false ||
        $anneeValidee < 1900 ||
        $anneeValidee > (int) date("Y") + 1
    ) {
        $erreurs[] = "L'année de fabrication est invalide.";
    } else {
        $annee = $anneeValidee;
    }
}

// Vérifier que le tarif est un nombre entier positif.
$tarif = filter_var($tarifBrut, FILTER_VALIDATE_INT);

if ($tarif === false || $tarif < 1) {
    $erreurs[] = "Le tarif journalier doit être un nombre entier supérieur à zéro.";
}

// Autoriser uniquement les statuts prévus pour l'ajout.
if (!in_array($statut, ["disponible", "maintenance"], true)) {
    $erreurs[] = "Le statut du véhicule est invalide.";
}

// Si des erreurs existent, les afficher sans enregistrer le véhicule.
if (!empty($erreurs)) {
    http_response_code(422);

    require_once __DIR__ . "/../../includes/header.php";
    require_once __DIR__ . "/../../includes/sidebar.php";
    ?>

    <div class="main-content">
        <h1 class="page-title">Vérification du véhicule</h1>

        <div class="message-success" style="border-left-color: #dc2626; background: #fef2f2; color: #991b1b;">
            <p>Le véhicule n'a pas été enregistré. Corrige les erreurs suivantes :</p>

            <ul>
                <?php foreach ($erreurs as $erreur): ?>
                    <li><?= e($erreur) ?></li>
                <?php endforeach; ?>
            </ul>
        </div>

        <a href="../../modules/vehicules/ajouter.php" class="btn-primary">
            Retour au formulaire
        </a>
    </div>

    <?php
    require_once __DIR__ . "/../../includes/footer.php";
    exit;
}

// Charger la connexion à la base de données.
require_once __DIR__ . "/../../config/connexion.php";

try {
    // Préparer la requête SQL pour éviter les injections SQL.
    $requete = $pdo->prepare(
        "INSERT INTO vehicule
        (marque_modele, immatriculation, annee, tarif_journalier, statut)
        VALUES
        (:marque_modele, :immatriculation, :annee, :tarif_journalier, :statut)"
    );

    // Exécuter la requête avec les valeurs validées.
    $requete->execute([
        ":marque_modele" => $marqueModele,
        ":immatriculation" => $immatriculation,
        ":annee" => $annee,
        ":tarif_journalier" => $tarif,
        ":statut" => $statut
    ]);

    // Rediriger vers la future liste des véhicules.
    header("Location: ../../modules/vehicules/index.php?ajout=success");
    exit;

} catch (PDOException $erreur) {
    // Enregistrer le détail technique dans le journal du serveur.
    error_log("Erreur lors de l'ajout d'un véhicule : " . $erreur->getMessage());

    // Détecter une immatriculation déjà enregistrée.
    if (
        $erreur->getCode() === "23000" ||
        (isset($erreur->errorInfo[1]) && (int) $erreur->errorInfo[1] === 1062)
    ) {
        http_response_code(409);
        exit("Cette immatriculation est déjà enregistrée. Vérifie le numéro du véhicule.");
    }

    http_response_code(500);
    exit("Une erreur technique empêche l'enregistrement du véhicule.");
}
