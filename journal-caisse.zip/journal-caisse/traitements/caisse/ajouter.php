
<?php

// ==================================================
// 1. CHARGEMENT DES FICHIERS NÉCESSAIRES
// ==================================================

// Charger la sécurité de session.
require_once __DIR__ . "/../../config/securite.php";

// Charger la connexion à la base de données.
require_once __DIR__ . "/../../config/connexion.php";

// Charger les fonctions communes.
require_once __DIR__ . "/../../includes/fonctions.php";

// Charger le système d'authentification.
require_once __DIR__ . "/../../config/authentification.php";

// Vérifier que l'administrateur est connecté.
exiger_connexion();


// ==================================================
// 2. VÉRIFICATION DE LA REQUÊTE
// ==================================================

// Accepter uniquement les formulaires envoyés avec POST.
if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    header("Location: ../../modules/caisse/index.php");
    exit;
}

// Vérifier le jeton CSRF.
csrf_verifier();


// ==================================================
// 3. RÉCUPÉRATION DES DONNÉES
// ==================================================

// Récupérer les valeurs envoyées par le formulaire.
$dateOperation = $_POST["date_operation"] ?? "";
$typeOperation = $_POST["type_operation"] ?? "";
$montantBrut = $_POST["montant"] ?? "";
$libelleBrut = $_POST["libelle"] ?? "";
$moyenPaiement = $_POST["moyen_paiement"] ?? "";
$clientBrut = $_POST["client_id"] ?? "";
$locationBrut = $_POST["location_id"] ?? "";
$categorieBrut = $_POST["categorie_depense_id"] ?? "";
$observationsBrutes = $_POST["observations"] ?? "";

// Vérifier les types avant de nettoyer les textes.
$libelle = is_string($libelleBrut)
    ? trim($libelleBrut)
    : "";

$observations = is_string($observationsBrutes)
    ? trim($observationsBrutes)
    : "";


// ==================================================
// 4. FONCTIONS DE VALIDATION
// ==================================================

// Vérifier que la date respecte le format AAAA-MM-JJ.
function dateOperationValide(string $date): bool
{
    $dateFormatee = DateTime::createFromFormat("!d-m-Y", $date);

    return $dateFormatee !== false
        && $dateFormatee->format("d-m-Y") === $date;
}

// Convertir un identifiant facultatif en entier.
// Une valeur vide signifie qu'aucun élément n'est associé.
function convertirIdentifiantFacultatif($valeur)
{
    if ($valeur === "") {
        return null;
    }

    if (!is_string($valeur)) {
        return false;
    }

    $identifiant = filter_var($valeur, FILTER_VALIDATE_INT);

    if ($identifiant === false || $identifiant < 1) {
        return false;
    }

    return $identifiant;
}

// Convertir les identifiants facultatifs.
$clientId = convertirIdentifiantFacultatif($clientBrut);
$locationId = convertirIdentifiantFacultatif($locationBrut);
$categorieId = convertirIdentifiantFacultatif($categorieBrut);


// ==================================================
// 5. VALIDATION DES CHAMPS
// ==================================================

$erreurs = [];

// Vérifier la date.
if (
    !is_string($dateOperation)
    || !dateOperationValide($dateOperation)
) {
    $erreurs[] = "La date de l'opération est invalide.";
}

// Vérifier le type d'opération.
if (
    !is_string($typeOperation)
    || !in_array($typeOperation, ["entree", "sortie"], true)
) {
    $erreurs[] = "Le type d'opération est invalide.";
}

// Vérifier le montant.
// Le montant doit être un entier positif.
if (
    !is_string($montantBrut)
    || !preg_match('/^[0-9]+$/', $montantBrut)
    || (float) $montantBrut <= 0
    || (float) $montantBrut > 999999999999
) {
    $erreurs[] = "Le montant doit être un nombre entier positif valide.";
}

// Vérifier le libellé.
if (
    $libelle === ""
    || strlen($libelle) > 255
) {
    $erreurs[] = "Le libellé est obligatoire et ne doit pas dépasser 255 caractères.";
}

// Vérifier le moyen de paiement.
$moyensAutorises = [
    "especes",
    "mobile_money",
    "virement",
    "cheque",
    "autre"
];

if (
    !is_string($moyenPaiement)
    || !in_array($moyenPaiement, $moyensAutorises, true)
) {
    $erreurs[] = "Le moyen de paiement est invalide.";
}

// Vérifier les identifiants facultatifs.
if ($clientId === false) {
    $erreurs[] = "Le client sélectionné est invalide.";
}

if ($locationId === false) {
    $erreurs[] = "La location sélectionnée est invalide.";
}

if ($categorieId === false) {
    $erreurs[] = "La catégorie sélectionnée est invalide.";
}

// Vérifier les observations.
if (
    !is_string($observationsBrutes)
    || strlen($observations) > 2000
) {
    $erreurs[] = "Les observations ne doivent pas dépasser 2 000 caractères.";
}

// Une catégorie de dépense ne peut être associée qu'à une sortie.
if (
    $typeOperation === "entree"
    && $categorieId !== null
) {
    $erreurs[] = "Une catégorie de dépense ne peut être associée qu'à une sortie.";
}

// Une catégorie est obligatoire pour une sortie.
if (
    $typeOperation === "sortie"
    && $categorieId === null
) {
    $erreurs[] = "Choisis une catégorie pour cette dépense.";
}

// Une location doit obligatoirement être associée à un client.
if (
    $locationId !== null
    && $clientId === null
) {
    $erreurs[] = "Sélectionne également le client associé à la location.";
}

// Arrêter le traitement si des erreurs sont détectées.
if (!empty($erreurs)) {
    http_response_code(422);

    exit(
        "Opération non enregistrée : "
        . e(implode(" ", $erreurs))
    );
}


// ==================================================
// 6. ENREGISTREMENT DANS LA BASE DE DONNÉES
// ==================================================

try {

    // Convertir le montant en entier.
    $montant = (int) $montantBrut;

    // Commencer une transaction.
    $pdo->beginTransaction();


    // --------------------------------------------------
    // Vérifier que le client existe.
    // --------------------------------------------------

    if ($clientId !== null) {

        $requeteClient = $pdo->prepare(
            "SELECT id
             FROM client
             WHERE id = :id"
        );

        $requeteClient->execute([
            ":id" => $clientId
        ]);

        if (!$requeteClient->fetch()) {
            throw new RuntimeException(
                "Le client sélectionné n'existe pas."
            );
        }
    }


    // --------------------------------------------------
    // Vérifier que la location existe et correspond au client.
    // --------------------------------------------------

    if ($locationId !== null) {

        $requeteLocation = $pdo->prepare(
            "SELECT id, client_id
             FROM location
             WHERE id = :id"
        );

        $requeteLocation->execute([
            ":id" => $locationId
        ]);

        $location = $requeteLocation->fetch();

        if (!$location) {
            throw new RuntimeException(
                "La location sélectionnée n'existe pas."
            );
        }

        if ((int) $location["client_id"] !== $clientId) {
            throw new RuntimeException(
                "Le client sélectionné ne correspond pas à cette location."
            );
        }
    }


    // --------------------------------------------------
    // Vérifier que la catégorie de dépense existe.
    // --------------------------------------------------

    if ($categorieId !== null) {

        $requeteCategorie = $pdo->prepare(
            "SELECT id
             FROM categorie_depense
             WHERE id = :id"
        );

        $requeteCategorie->execute([
            ":id" => $categorieId
        ]);

        if (!$requeteCategorie->fetch()) {
            throw new RuntimeException(
                "La catégorie sélectionnée n'existe pas."
            );
        }
    }


    // --------------------------------------------------
    // Préparer la requête d'insertion.
    // --------------------------------------------------

    $requeteAjout = $pdo->prepare(
        "INSERT INTO mouvement_caisse
        (
            date_operation,
            type_operation,
            montant,
            libelle,
            client_id,
            location_id,
            categorie_depense_id,
            moyen_paiement,
            observations
        )
        VALUES
        (
            :date_operation,
            :type_operation,
            :montant,
            :libelle,
            :client_id,
            :location_id,
            :categorie_depense_id,
            :moyen_paiement,
            :observations
        )"
    );

    // Enregistrer l'opération avec des paramètres préparés.
    $requeteAjout->execute([
        ":date_operation" => $dateOperation,
        ":type_operation" => $typeOperation,
        ":montant" => $montant,
        ":libelle" => $libelle,
        ":client_id" => $clientId,
        ":location_id" => $locationId,
        ":categorie_depense_id" => $categorieId,
        ":moyen_paiement" => $moyenPaiement,
        ":observations" => $observations !== ""
            ? $observations
            : null
    ]);


    // --------------------------------------------------
    // Valider définitivement l'enregistrement.
    // --------------------------------------------------

    $pdo->commit();

    // Rediriger vers la liste des opérations.
    header(
        "Location: ../../modules/caisse/index.php?ajout=success"
    );

    exit;


// ==================================================
// 7. GESTION DES ERREURS
// ==================================================

} catch (PDOException $erreur) {

    // Annuler la transaction en cas d'erreur SQL.
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }

    // Enregistrer les détails dans les journaux du serveur.
    error_log(
        "Erreur SQL lors de l'ajout d'une opération de caisse : "
        . $erreur->getMessage()
    );

    http_response_code(500);

    exit(
        "Une erreur technique empêche l'enregistrement de l'opération."
    );


} catch (RuntimeException $erreur) {

    // Annuler la transaction si une règle métier est violée.
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }

    // Enregistrer le motif du refus.
    error_log(
        "Opération de caisse refusée : "
        . $erreur->getMessage()
    );

    http_response_code(422);

    exit(
        "Opération non enregistrée : "
        . e($erreur->getMessage())
    );
}
