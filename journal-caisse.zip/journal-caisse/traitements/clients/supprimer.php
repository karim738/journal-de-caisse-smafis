
<?php

require_once __DIR__ . "/../../config/authentification.php";

exiger_connexion();
// 1. Charger la sécurité et les fonctions communes.
require_once __DIR__ . "/../../config/securite.php";
require_once __DIR__ . "/../../includes/fonctions.php";

// 2. Autoriser uniquement les demandes envoyées par formulaire POST.
if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    header("Location: ../../modules/clients/index.php");
    exit;
}

// 3. Vérifier le jeton CSRF avant toute opération.
csrf_verifier();

// 4. Récupérer et vérifier l'identifiant du client.
$idBrut = $_POST["id"] ?? null;

if (!is_string($idBrut)) {
    http_response_code(400);
    exit("Identifiant du client invalide.");
}

$id = filter_var($idBrut, FILTER_VALIDATE_INT);

if ($id === false || $id === null || $id < 1) {
    http_response_code(400);
    exit("Identifiant du client invalide.");
}

// 5. Charger la connexion à MySQL.
require_once __DIR__ . "/../../config/connexion.php";

try {
    // 6. Vérifier que le client existe.
    $requete = $pdo->prepare(
        "SELECT id FROM client WHERE id = :id"
    );
    $requete->execute([":id" => $id]);

    if (!$requete->fetch()) {
        header("Location: ../../modules/clients/index.php?erreur=introuvable");
        exit;
    }

    // 7. Vérifier si le client possède des locations.
    $requeteLocations = $pdo->prepare(
        "SELECT COUNT(*) FROM location WHERE client_id = :id"
    );
    $requeteLocations->execute([":id" => $id]);
    $nombreLocations = (int) $requeteLocations->fetchColumn();

    // 8. Vérifier si le client est lié à des mouvements de caisse.
    $requeteCaisse = $pdo->prepare(
        "SELECT COUNT(*) FROM mouvement_caisse WHERE client_id = :id"
    );
    $requeteCaisse->execute([":id" => $id]);
    $nombreMouvements = (int) $requeteCaisse->fetchColumn();

    // 9. Protéger l'historique financier.
    if ($nombreLocations > 0 || $nombreMouvements > 0) {
        header("Location: ../../modules/clients/index.php?erreur=historique");
        exit;
    }

    // 10. Supprimer le client uniquement s'il n'a aucun historique lié.
    $requeteSuppression = $pdo->prepare(
        "DELETE FROM client WHERE id = :id"
    );
    $requeteSuppression->execute([":id" => $id]);

    // 11. Confirmer la suppression en revenant à la liste.
    header("Location: ../../modules/clients/index.php?suppression=success");
    exit;

} catch (PDOException $erreur) {
    // Enregistrer les détails techniques sans les montrer à l'utilisateur.
    error_log("Erreur lors de la suppression d'un client : " . $erreur->getMessage());

    http_response_code(500);
    exit("Une erreur technique empêche la suppression du client.");
}
