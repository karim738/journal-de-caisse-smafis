
<?php

require_once __DIR__ . "/../../config/authentification.php";

exiger_connexion();
// 1. Charger les outils de sécurité et les fonctions communes.
require_once __DIR__ . "/../../config/securite.php";
require_once __DIR__ . "/../../includes/fonctions.php";

// 2. Accepter uniquement les formulaires envoyés avec la méthode POST.
if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    header("Location: ../../modules/clients/index.php");
    exit;
}

// 3. Vérifier le jeton CSRF pour empêcher les soumissions non autorisées.
csrf_verifier();

// 4. Récupérer les informations envoyées par le formulaire.
$idBrut = $_POST["id"] ?? null;
$nom = $_POST["nom"] ?? "";
$telephone = $_POST["telephone"] ?? "";
$email = $_POST["email"] ?? "";
$adresse = $_POST["adresse"] ?? "";

// 5. Vérifier que les données reçues sont bien des chaînes de caractères.
if (
    !is_string($idBrut) ||
    !is_string($nom) ||
    !is_string($telephone) ||
    !is_string($email) ||
    !is_string($adresse)
) {
    http_response_code(400);
    exit("Les données envoyées sont invalides.");
}

// 6. Vérifier que l'identifiant est un nombre entier positif.
$id = filter_var($idBrut, FILTER_VALIDATE_INT);

if ($id === false || $id === null || $id < 1) {
    http_response_code(400);
    exit("L'identifiant du client est invalide.");
}

// 7. Nettoyer les espaces inutiles au début et à la fin des champs.
$nom = trim($nom);
$telephone = trim($telephone);
$email = trim($email);
$adresse = trim($adresse);

// 8. Vérifier les règles de validation des données.
$erreurs = [];

if ($nom === "") {
    $erreurs[] = "Le nom du client est obligatoire.";
} elseif (mb_strlen($nom, "UTF-8") > 150) {
    $erreurs[] = "Le nom ne doit pas dépasser 150 caractères.";
}

if (mb_strlen($telephone, "UTF-8") > 30) {
    $erreurs[] = "Le téléphone ne doit pas dépasser 30 caractères.";
}

if ($email !== "" && !filter_var($email, FILTER_VALIDATE_EMAIL)) {
    $erreurs[] = "L'adresse email n'est pas valide.";
}

if (mb_strlen($email, "UTF-8") > 254) {
    $erreurs[] = "L'email ne doit pas dépasser 254 caractères.";
}

if (mb_strlen($adresse, "UTF-8") > 500) {
    $erreurs[] = "L'adresse ne doit pas dépasser 500 caractères.";
}

// 9. Afficher les erreurs sans modifier la base de données.
if (!empty($erreurs)) {
    http_response_code(422);

    require_once __DIR__ . "/../../includes/header.php";
    require_once __DIR__ . "/../../includes/sidebar.php";
    ?>
    <div class="main-content">
        <h1 class="page-title">Vérification du formulaire</h1>

        <div class="dashboard-card">
            <p>Les modifications n'ont pas été enregistrées pour les raisons suivantes :</p>

            <ul>
                <?php foreach ($erreurs as $erreur): ?>
                    <li><?= e($erreur) ?></li>
                <?php endforeach; ?>
            </ul>

            <a
                href="../../modules/clients/modifier.php?id=<?= e($id) ?>"
                class="btn-secondary"
            >
                Retour au formulaire
            </a>
        </div>
    </div>
    <?php
    require_once __DIR__ . "/../../includes/footer.php";
    exit;
}

// 10. Charger la connexion à la base de données.
require_once __DIR__ . "/../../config/connexion.php";

try {
    // Vérifier que le client existe avant de le modifier.
    $verification = $pdo->prepare(
        "SELECT id FROM client WHERE id = :id"
    );
    $verification->execute([":id" => $id]);

    if (!$verification->fetch()) {
        http_response_code(404);
        exit("Le client à modifier est introuvable.");
    }

    // Préparer la requête SQL de modification.
    $sql = "UPDATE client
            SET nom = :nom,
                telephone = :telephone,
                email = :email,
                adresse = :adresse
            WHERE id = :id";

    $requete = $pdo->prepare($sql);

    // Envoyer les nouvelles valeurs à MySQL.
    $requete->execute([
        ":nom" => $nom,
        ":telephone" => $telephone !== "" ? $telephone : null,
        ":email" => $email !== "" ? $email : null,
        ":adresse" => $adresse !== "" ? $adresse : null,
        ":id" => $id
    ]);

    // Rediriger vers la liste des clients après la modification.
    header("Location: ../../modules/clients/index.php?modification=success");
    exit;

} catch (PDOException $erreur) {
    // Conserver les détails techniques dans les journaux du serveur.
    error_log("Erreur lors de la modification d'un client : " . $erreur->getMessage());

    http_response_code(500);
    exit("Une erreur technique empêche la modification du client. Veuillez réessayer ultérieurement.");
}
