
<?php

require_once __DIR__ . "/../../config/authentification.php";

exiger_connexion();

// 1. Charger les protections de sécurité.
require_once __DIR__ . "/../../config/securite.php";

// 2. Charger les fonctions communes.
require_once __DIR__ . "/../../includes/fonctions.php";

// 3. Accepter uniquement les formulaires envoyés en POST.
if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    header("Location: ../../modules/clients/ajouter.php");
    exit;
}

// 4. Vérifier le jeton CSRF avant de traiter les données.
csrf_verifier();

// 5. Récupérer les données en vérifiant leur type.
$nom = $_POST["nom"] ?? "";
$telephone = $_POST["telephone"] ?? "";
$email = $_POST["email"] ?? "";
$adresse = $_POST["adresse"] ?? "";

// Refuser les valeurs qui ne sont pas des chaînes de caractères.
if (
    !is_string($nom)
    || !is_string($telephone)
    || !is_string($email)
    || !is_string($adresse)
) {
    http_response_code(400);
    exit("Les données envoyées sont invalides.");
}

// 6. Nettoyer les espaces inutiles au début et à la fin.
$nom = trim($nom);
$telephone = trim($telephone);
$email = trim($email);
$adresse = trim($adresse);

// 7. Préparer la liste des erreurs de validation.
$erreurs = [];

// Vérifier le nom obligatoire.
if ($nom === "") {
    $erreurs[] = "Le nom du client est obligatoire.";
} elseif (mb_strlen($nom, "UTF-8") > 150) {
    $erreurs[] = "Le nom ne doit pas dépasser 150 caractères.";
}

// Vérifier la longueur du téléphone.
if (mb_strlen($telephone, "UTF-8") > 30) {
    $erreurs[] = "Le téléphone ne doit pas dépasser 30 caractères.";
}

// Vérifier l'adresse email si elle est renseignée.
if ($email !== "" && !filter_var($email, FILTER_VALIDATE_EMAIL)) {
    $erreurs[] = "L'adresse email n'est pas valide.";
}

if (mb_strlen($email, "UTF-8") > 254) {
    $erreurs[] = "L'email ne doit pas dépasser 254 caractères.";
}

// Vérifier la longueur de l'adresse.
if (mb_strlen($adresse, "UTF-8") > 500) {
    $erreurs[] = "L'adresse ne doit pas dépasser 500 caractères.";
}

// 8. Si les données sont invalides, afficher les erreurs.
if (!empty($erreurs)) {

    http_response_code(422);

    require_once __DIR__ . "/../../includes/header.php";
    require_once __DIR__ . "/../../includes/sidebar.php";
    ?>

    <div class="main-content">

        <h1 class="page-title">Vérification du formulaire</h1>

        <div class="dashboard-card">

            <p>Le client n'a pas été enregistré pour les raisons suivantes :</p>

            <ul>
                <?php foreach ($erreurs as $erreur): ?>
                    <li><?= e($erreur) ?></li>
                <?php endforeach; ?>
            </ul>

            <a href="../../modules/clients/ajouter.php" class="btn-secondary">
                Retour au formulaire
            </a>

        </div>

    </div>

    <?php
    require_once __DIR__ . "/../../includes/footer.php";
    exit;
}

// 9. Charger la connexion à la base de données.
require_once __DIR__ . "/../../config/connexion.php";

try {

    // 10. Préparer la requête SQL.
    $sql = "INSERT INTO client
                (nom, telephone, email, adresse)
            VALUES
                (:nom, :telephone, :email, :adresse)";

    $requete = $pdo->prepare($sql);

    // 11. Exécuter la requête avec les données validées.
    $requete->execute([
        ":nom" => $nom,
        ":telephone" => $telephone !== "" ? $telephone : null,
        ":email" => $email !== "" ? $email : null,
        ":adresse" => $adresse !== "" ? $adresse : null
    ]);

    // 12. Rediriger vers la liste après l'enregistrement.
    header("Location: ../../modules/clients/index.php?ajout=success");
    exit;

} catch (PDOException $erreur) {

    // Enregistrer les détails techniques dans les journaux du serveur.
    error_log("Erreur lors de l'ajout d'un client : " . $erreur->getMessage());

    // Ne pas révéler les détails SQL au visiteur.
    http_response_code(500);

    exit(
        "Une erreur technique empêche l'enregistrement du client. "
        . "Veuillez réessayer ultérieurement."
    );
}
