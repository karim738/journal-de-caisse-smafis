
<?php

// ==================================================
// 1. CHARGEMENT DES FICHIERS NÉCESSAIRES
// ==================================================

// Charger les protections de sécurité et démarrer la session.
require_once __DIR__ . "/../../config/securite.php";

// Charger la connexion à la base de données.
require_once __DIR__ . "/../../config/connexion.php";

// Charger les fonctions communes.
require_once __DIR__ . "/../../includes/fonctions.php";

// Charger le système d'authentification.
require_once __DIR__ . "/../../config/authentification.php";

// Vérifier que l'administrateur est connecté.
exiger_connexion();

// ==================================================
// 2. VÉRIFICATION DE LA REQUÊTE
// ==================================================

// Accepter uniquement les formulaires envoyés avec POST.
if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    header("Location: ../../modules/locations/index.php");
    exit;
}

// Vérifier le jeton CSRF du formulaire.
csrf_verifier();

// ==================================================
// 3. RÉCUPÉRATION DES DONNÉES DU FORMULAIRE
// ==================================================

// Récupérer les données envoyées par le formulaire.
$idBrut = $_POST["id"] ?? null;
$clientBrut = $_POST["client_id"] ?? null;
$vehiculeBrut = $_POST["vehicule_id"] ?? null;
$dateDebut = $_POST["date_debut"] ?? "";
$dateFin = $_POST["date_fin"] ?? "";
$observationsBrut = $_POST["observations"] ?? "";

// ==================================================
// 4. VALIDATION DES IDENTIFIANTS
// ==================================================

// Vérifier que les identifiants sont des nombres entiers.
$id = is_string($idBrut)
    ? filter_var($idBrut, FILTER_VALIDATE_INT)
    : false;

$clientId = is_string($clientBrut)
    ? filter_var($clientBrut, FILTER_VALIDATE_INT)
    : false;

$vehiculeId = is_string($vehiculeBrut)
    ? filter_var($vehiculeBrut, FILTER_VALIDATE_INT)
    : false;

// Préparer le tableau des erreurs.
$erreurs = [];

// Vérifier l'identifiant de la location.
if ($id === false || $id === null || $id < 1) {
    $erreurs[] = "L'identifiant de la location est invalide.";
}

// Vérifier l'identifiant du client.
if ($clientId === false || $clientId === null || $clientId < 1) {
    $erreurs[] = "Le client sélectionné est invalide.";
}

// Vérifier l'identifiant du véhicule.
if ($vehiculeId === false || $vehiculeId === null || $vehiculeId < 1) {
    $erreurs[] = "Le véhicule sélectionné est invalide.";
}

// ==================================================
// 5. VALIDATION DES DATES
// ==================================================

// Cette fonction vérifie que la date existe réellement.
function dateEstValide(string $date): bool
{
    $objetDate = DateTime::createFromFormat("!Y-m-d", $date);

    return $objetDate !== false
        && $objetDate->format("Y-m-d") === $date;
}

// Vérifier la date de début.
if (!is_string($dateDebut) || !dateEstValide($dateDebut)) {
    $erreurs[] = "La date de début est invalide.";
}

// Vérifier la date de fin.
if (!is_string($dateFin) || !dateEstValide($dateFin)) {
    $erreurs[] = "La date de fin est invalide.";
}

// Vérifier que la date de fin n'est pas antérieure à la date de début.
if (
    is_string($dateDebut) &&
    is_string($dateFin) &&
    dateEstValide($dateDebut) &&
    dateEstValide($dateFin) &&
    $dateFin < $dateDebut
) {
    $erreurs[] = "La date de fin doit être égale ou postérieure à la date de début.";
}

// ==================================================
// 6. VALIDATION DES OBSERVATIONS
// ==================================================

// Vérifier que les observations sont bien du texte.
if (!is_string($observationsBrut)) {
    $erreurs[] = "Les observations sont invalides.";
    $observations = "";
} else {
    // Supprimer les espaces inutiles au début et à la fin.
    $observations = trim($observationsBrut);

    // Limiter la longueur des observations.
    if (strlen($observations) > 2000) {
        $erreurs[] = "Les observations ne doivent pas dépasser 2 000 caractères.";
    }
}

// Arrêter le traitement si des erreurs sont détectées.
if (!empty($erreurs)) {
    http_response_code(422);
    exit("Modification refusée : " . implode(" ", $erreurs));
}

// ==================================================
// 7. MODIFICATION DE LA LOCATION
// ==================================================

try {

    // Commencer une transaction pour sécuriser les opérations.
    $pdo->beginTransaction();

    // --------------------------------------------------
    // 7.1 Vérifier et verrouiller la location
    // --------------------------------------------------

    $requeteLocation = $pdo->prepare(
        "SELECT id, vehicule_id, statut
         FROM location
         WHERE id = :id
         FOR UPDATE"
    );

    $requeteLocation->execute([
        ":id" => $id
    ]);

    $location = $requeteLocation->fetch();

    // Vérifier que la location existe.
    if (!$location) {
        throw new RuntimeException("Cette location n'existe pas.");
    }

    // Seules les locations prévues peuvent être modifiées.
    if ($location["statut"] !== "prevue") {
        throw new RuntimeException(
            "Seules les locations prévues peuvent être modifiées."
        );
    }

    // --------------------------------------------------
    // 7.2 Vérifier l'existence du client
    // --------------------------------------------------

    $requeteClient = $pdo->prepare(
        "SELECT id
         FROM client
         WHERE id = :id"
    );

    $requeteClient->execute([
        ":id" => $clientId
    ]);

    if (!$requeteClient->fetch()) {
        throw new RuntimeException("Le client sélectionné n'existe pas.");
    }

    // --------------------------------------------------
    // 7.3 Vérifier et verrouiller le véhicule
    // --------------------------------------------------

    $requeteVehicule = $pdo->prepare(
        "SELECT id, tarif_journalier, statut
         FROM vehicule
         WHERE id = :id
         FOR UPDATE"
    );

    $requeteVehicule->execute([
        ":id" => $vehiculeId
    ]);

    $vehicule = $requeteVehicule->fetch();

    // Vérifier que le véhicule existe.
    if (!$vehicule) {
        throw new RuntimeException("Le véhicule sélectionné n'existe pas.");
    }

    // Vérifier que le véhicule est disponible.
    if ($vehicule["statut"] !== "disponible") {
        throw new RuntimeException(
            "Le véhicule sélectionné n'est pas disponible. Vérifiez son statut avant de continuer."
        );
    }

    // --------------------------------------------------
    // 7.4 Calculer le montant de la location
    // --------------------------------------------------

    // Calculer le nombre de jours en comptant les deux dates.
    $debut = new DateTimeImmutable($dateDebut);
    $fin = new DateTimeImmutable($dateFin);

    $nombreJours = (int) $debut->diff($fin)->days + 1;

    // Récupérer le tarif journalier depuis la base de données.
    // Ne jamais utiliser un tarif envoyé par le navigateur.
    $tarifJournalier = (int) $vehicule["tarif_journalier"];

    // Vérifier que le calcul ne dépasse pas la capacité d'un entier.
    if (
        $tarifJournalier < 0 ||
        $nombreJours < 1 ||
        $nombreJours > intdiv(PHP_INT_MAX, max(1, $tarifJournalier))
    ) {
        throw new RuntimeException("Le montant de la location est invalide.");
    }

    // Calculer le montant total.
    $montantTotal = $tarifJournalier * $nombreJours;

    // --------------------------------------------------
    // 7.5 Vérifier les conflits de réservation
    // --------------------------------------------------

    // Exclure la location actuelle de la recherche des conflits.
    $requeteConflit = $pdo->prepare(
        "SELECT id
         FROM location
         WHERE vehicule_id = :vehicule_id
           AND id <> :id
           AND statut IN ('prevue', 'en_cours')
           AND date_debut <= :date_fin
           AND date_fin >= :date_debut
         LIMIT 1
         FOR UPDATE"
    );

    $requeteConflit->execute([
        ":vehicule_id" => $vehiculeId,
        ":id" => $id,
        ":date_debut" => $dateDebut,
        ":date_fin" => $dateFin
    ]);

    // Refuser la modification si une autre location chevauche la période.
    if ($requeteConflit->fetch()) {
        throw new RuntimeException(
            "Ce véhicule possède déjà une location prévue ou en cours sur cette période."
        );
    }

    // --------------------------------------------------
    // 7.6 Enregistrer les modifications
    // --------------------------------------------------

    $requeteModification = $pdo->prepare(
        "UPDATE location
         SET client_id = :client_id,
             vehicule_id = :vehicule_id,
             date_debut = :date_debut,
             date_fin = :date_fin,
             tarif_journalier = :tarif_journalier,
             montant_total = :montant_total,
             observations = :observations
         WHERE id = :id"
    );

    // Envoyer les données validées à MySQL.
    $requeteModification->execute([
        ":client_id" => $clientId,
        ":vehicule_id" => $vehiculeId,
        ":date_debut" => $dateDebut,
        ":date_fin" => $dateFin,
        ":tarif_journalier" => $tarifJournalier,
        ":montant_total" => $montantTotal,
        ":observations" => $observations !== "" ? $observations : null,
        ":id" => $id
    ]);

    // --------------------------------------------------
    // 7.7 Valider la transaction
    // --------------------------------------------------

    // Confirmer définitivement les modifications.
    $pdo->commit();

    // Rediriger vers la liste des locations.
    header("Location: ../../modules/locations/index.php?modification=success");
    exit;

} catch (RuntimeException $erreur) {

    // Annuler la transaction si une règle métier n'est pas respectée.
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }

    http_response_code(422);

    exit("Modification refusée : " . $erreur->getMessage());

} catch (PDOException $erreur) {

    // Annuler la transaction en cas d'erreur MySQL.
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }

    // Enregistrer les détails techniques dans le journal du serveur.
    error_log(
        "Erreur lors de la modification d'une location : "
        . $erreur->getMessage()
    );

    // Ne pas afficher les détails techniques à l'utilisateur.
    http_response_code(500);

    exit("Une erreur technique empêche la modification de la location.");
}
