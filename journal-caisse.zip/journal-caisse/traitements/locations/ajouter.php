
<?php

// ==================================================
// 1. CHARGEMENT DES FICHIERS NÉCESSAIRES
// ==================================================

// Charger les protections de sécurité et démarrer la session.
require_once __DIR__ . "/../../config/securite.php";

// Charger la connexion à la base de données.
require_once __DIR__ . "/../../config/connexion.php";

// Charger les fonctions communes.
require_once __DIR__ . "/../../includes/fonctions.php";

// Charger le système d'authentification.
require_once __DIR__ . "/../../config/authentification.php";

// Vérifier que l'administrateur est connecté.
exiger_connexion();

// ==================================================
// 2. VÉRIFICATION DE LA REQUÊTE
// ==================================================

// Accepter uniquement les formulaires envoyés avec POST.
if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    header("Location: ../../modules/locations/ajouter.php");
    exit;
}

// Vérifier le jeton CSRF du formulaire.
csrf_verifier();

// ==================================================
// 3. RÉCUPÉRATION DES DONNÉES DU FORMULAIRE
// ==================================================

$clientBrut = $_POST["client_id"] ?? null;
$vehiculeBrut = $_POST["vehicule_id"] ?? null;
$dateDebut = $_POST["date_debut"] ?? "";
$dateFin = $_POST["date_fin"] ?? "";
$observationsBrutes = $_POST["observations"] ?? "";

// Vérifier le type des observations avant de les traiter.
$observations = is_string($observationsBrutes)
    ? trim($observationsBrutes)
    : null;

// ==================================================
// 4. VALIDATION DES IDENTIFIANTS
// ==================================================

// Vérifier que les identifiants sont des nombres entiers.
$clientId = is_string($clientBrut)
    ? filter_var($clientBrut, FILTER_VALIDATE_INT)
    : false;

$vehiculeId = is_string($vehiculeBrut)
    ? filter_var($vehiculeBrut, FILTER_VALIDATE_INT)
    : false;

// Préparer le tableau des erreurs.
$erreurs = [];

// Vérifier l'identifiant du client.
if ($clientId === false || $clientId === null || $clientId < 1) {
    $erreurs[] = "Le client sélectionné est invalide.";
}

// Vérifier l'identifiant du véhicule.
if ($vehiculeId === false || $vehiculeId === null || $vehiculeId < 1) {
    $erreurs[] = "Le véhicule sélectionné est invalide.";
}

// ==================================================
// 5. VALIDATION DES DATES
// ==================================================

// Cette fonction vérifie que la date existe réellement.
function dateEstValide(string $date): bool
{
    $objetDate = DateTime::createFromFormat("!d-m-Y", $date);

    return $objetDate !== false
        && $objetDate->format("d-m-Y") === $date;
}

// Vérifier le format de la date de début.
if (!is_string($dateDebut) || !dateEstValide($dateDebut)) {
    $erreurs[] = "La date de début est invalide.";
}

// Vérifier le format de la date de fin.
if (!is_string($dateFin) || !dateEstValide($dateFin)) {
    $erreurs[] = "La date de fin est invalide.";
}

// Vérifier que la date de fin n'est pas antérieure au début.
if (
    is_string($dateDebut) &&
    is_string($dateFin) &&
    dateEstValide($dateDebut) &&
    dateEstValide($dateFin) &&
    $dateFin < $dateDebut
) {
    $erreurs[] = "La date de fin doit être égale ou postérieure à la date de début.";
}

// ==================================================
// 6. VALIDATION DES OBSERVATIONS
// ==================================================

// Refuser les observations qui ne sont pas du texte.
if ($observations === null) {
    $erreurs[] = "Le format des observations est invalide.";
} elseif (strlen($observations) > 2000) {
    $erreurs[] = "Les observations ne doivent pas dépasser 2 000 caractères.";
}

// Arrêter le traitement si une erreur est détectée.
if (!empty($erreurs)) {
    http_response_code(422);
    exit("Location non enregistrée : " . implode(" ", $erreurs));
}

// ==================================================
// 7. ENREGISTREMENT DE LA LOCATION
// ==================================================

try {

    // Commencer une transaction pour sécuriser les opérations.
    $pdo->beginTransaction();

    // Vérifier que le client existe réellement.
    $requeteClient = $pdo->prepare(
        "SELECT id FROM client WHERE id = :id"
    );

    $requeteClient->execute([
        ":id" => $clientId
    ]);

    if (!$requeteClient->fetch()) {
        throw new RuntimeException("Le client sélectionné n'existe pas.");
    }

    // Récupérer et verrouiller le véhicule pendant la transaction.
    $requeteVehicule = $pdo->prepare(
        "SELECT id, tarif_journalier, statut
         FROM vehicule
         WHERE id = :id
         FOR UPDATE"
    );

    $requeteVehicule->execute([
        ":id" => $vehiculeId
    ]);

    $vehicule = $requeteVehicule->fetch();

    // Vérifier que le véhicule existe.
    if (!$vehicule) {
        throw new RuntimeException("Le véhicule sélectionné n'existe pas.");
    }

    // Vérifier que le véhicule est disponible.
    if ($vehicule["statut"] !== "disponible") {
        throw new RuntimeException("Ce véhicule n'est plus disponible.");
    }

    // Calculer le nombre de jours en comptant les deux dates.
    $debut = new DateTimeImmutable($dateDebut);
    $fin = new DateTimeImmutable($dateFin);

    $nombreJours = (int) $debut->diff($fin)->days + 1;

    // Récupérer le tarif directement depuis la base de données.
    $tarifJournalier = (int) $vehicule["tarif_journalier"];

    // Vérifier que le calcul ne risque pas de dépasser la limite entière.
    if (
        $tarifJournalier < 0 ||
        $nombreJours < 1 ||
        $nombreJours > intdiv(PHP_INT_MAX, max(1, $tarifJournalier))
    ) {
        throw new RuntimeException("Le montant de la location est invalide.");
    }

    // Calculer le montant total de la location.
    $montantTotal = $tarifJournalier * $nombreJours;

    // Vérifier qu'aucune autre location ne chevauche cette période.
    $requeteConflit = $pdo->prepare(
        "SELECT id
         FROM location
         WHERE vehicule_id = :vehicule_id
           AND statut IN ('prevue', 'en_cours')
           AND date_debut <= :date_fin
           AND date_fin >= :date_debut
         LIMIT 1"
    );

    $requeteConflit->execute([
        ":vehicule_id" => $vehiculeId,
        ":date_debut" => $dateDebut,
        ":date_fin" => $dateFin
    ]);

    if ($requeteConflit->fetch()) {
        throw new RuntimeException(
            "Ce véhicule possède déjà une location prévue ou en cours sur cette période."
        );
    }

    // Préparer l'enregistrement de la nouvelle location.
    $requeteAjout = $pdo->prepare(
        "INSERT INTO location
        (
            client_id,
            vehicule_id,
            date_debut,
            date_fin,
            tarif_journalier,
            montant_total,
            statut,
            observations
        )
        VALUES
        (
            :client_id,
            :vehicule_id,
            :date_debut,
            :date_fin,
            :tarif_journalier,
            :montant_total,
            'prevue',
            :observations
        )"
    );

    // Exécuter la requête avec les données validées.
    $requeteAjout->execute([
        ":client_id" => $clientId,
        ":vehicule_id" => $vehiculeId,
        ":date_debut" => $dateDebut,
        ":date_fin" => $dateFin,
        ":tarif_journalier" => $tarifJournalier,
        ":montant_total" => $montantTotal,
        ":observations" => $observations !== "" ? $observations : null
    ]);

    // Valider définitivement l'enregistrement.
    $pdo->commit();

    // Rediriger vers la liste des locations.
    header("Location: ../../modules/locations/index.php?ajout=success");
    exit;

} catch (RuntimeException $erreur) {

    // Annuler la transaction si une règle métier n'est pas respectée.
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }

    http_response_code(422);
    exit("Location non enregistrée : " . $erreur->getMessage());

} catch (PDOException $erreur) {

    // Annuler la transaction en cas de problème avec MySQL.
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }

    // Enregistrer les détails techniques dans le journal du serveur.
    error_log(
        "Erreur lors de l'ajout d'une location : " . $erreur->getMessage()
    );

    // Afficher un message général sans exposer les détails techniques.
    http_response_code(500);
    exit("Une erreur technique empêche l'enregistrement de la location.");
}
