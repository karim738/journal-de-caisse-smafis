
<?php

// Charger la sécurité de session.
require_once __DIR__ . "/../../config/securite.php";

// Charger les fonctions communes.
require_once __DIR__ . "/../../includes/fonctions.php";

// Vérifier l'authentification de l'administrateur.
require_once __DIR__ . "/../../config/authentification.php";
exiger_connexion();

// Charger la connexion à la base de données.
require_once __DIR__ . "/../../config/connexion.php";

// Accepter uniquement les formulaires envoyés avec POST.
if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    header("Location: ../../modules/locations/index.php");
    exit;
}

// Vérifier le jeton de sécurité du formulaire.
csrf_verifier();

// Récupérer les données envoyées.
$idBrut = $_POST["id"] ?? null;
$nouveauStatut = $_POST["nouveau_statut"] ?? null;

// Vérifier l'identifiant de la location.
$id = is_string($idBrut)
    ? filter_var($idBrut, FILTER_VALIDATE_INT)
    : false;

if ($id === false || $id === null || $id < 1) {
    header("Location: ../../modules/locations/index.php?erreur=id_invalide");
    exit;
}

// Définir les changements de statut autorisés.
$transitionsAutorisees = [
    "prevue" => ["en_cours", "annulee"],
    "en_cours" => ["terminee"]
];

// Vérifier que le statut demandé est valide.
if (
    !is_string($nouveauStatut)
    || !in_array($nouveauStatut, ["en_cours", "terminee", "annulee"], true)
) {
    header("Location: ../../modules/locations/index.php?erreur=statut_invalide");
    exit;
}

try {

    // Démarrer une transaction pour sécuriser les modifications.
    $pdo->beginTransaction();

    // Verrouiller la location pendant le traitement.
    $requeteLocation = $pdo->prepare(
        "SELECT id, vehicule_id, statut, date_debut, date_fin
         FROM location
         WHERE id = :id
         FOR UPDATE"
    );

    $requeteLocation->execute([":id" => $id]);
    $location = $requeteLocation->fetch();

    // Vérifier que la location existe.
    if (!$location) {
        throw new RuntimeException("Cette location n'existe pas.");
    }

    $ancienStatut = $location["statut"];
    $vehiculeId = (int) $location["vehicule_id"];

    // Vérifier que la transition demandée est autorisée.
    if (
        !isset($transitionsAutorisees[$ancienStatut])
        || !in_array(
            $nouveauStatut,
            $transitionsAutorisees[$ancienStatut],
            true
        )
    ) {
        throw new RuntimeException(
            "Ce changement de statut n'est pas autorisé."
        );
    }

    // Verrouiller le véhicule associé à la location.
    $requeteVehicule = $pdo->prepare(
        "SELECT id, statut
         FROM vehicule
         WHERE id = :id
         FOR UPDATE"
    );

    $requeteVehicule->execute([":id" => $vehiculeId]);
    $vehicule = $requeteVehicule->fetch();

    // Vérifier que le véhicule existe.
    if (!$vehicule) {
        throw new RuntimeException(
            "Le véhicule associé à cette location est introuvable."
        );
    }

    // Vérifier les conditions avant de démarrer la location.
    if ($nouveauStatut === "en_cours") {

        // Le véhicule doit être disponible.
        if ($vehicule["statut"] !== "disponible") {
            throw new RuntimeException(
                "Ce véhicule n'est pas disponible pour démarrer la location."
            );
        }

        // Récupérer la date du jour.
        $dateAujourdhui = date("Y-m-d");

        // Vérifier que la période de location comprend la date du jour.
        if (
            $location["date_debut"] > $dateAujourdhui
            || $location["date_fin"] < $dateAujourdhui
        ) {
            throw new RuntimeException(
                "Cette location ne peut pas démarrer aujourd'hui : vérifiez ses dates."
            );
        }

        // Vérifier qu'aucune autre location n'est déjà en cours.
        $requeteAutreLocation = $pdo->prepare(
            "SELECT id
             FROM location
             WHERE vehicule_id = :vehicule_id
               AND id <> :id
               AND statut = 'en_cours'
             LIMIT 1"
        );

        $requeteAutreLocation->execute([
            ":vehicule_id" => $vehiculeId,
            ":id" => $id
        ]);

        if ($requeteAutreLocation->fetch()) {
            throw new RuntimeException(
                "Une autre location de ce véhicule est déjà en cours."
            );
        }
    }

    // Mettre à jour le statut de la location.
    $requeteModification = $pdo->prepare(
        "UPDATE location
         SET statut = :statut
         WHERE id = :id"
    );

    $requeteModification->execute([
        ":statut" => $nouveauStatut,
        ":id" => $id
    ]);

    // Synchroniser le statut du véhicule avec la location.
    if ($nouveauStatut === "en_cours") {

        // Le véhicule devient loué au démarrage.
        $requeteVehiculeStatut = $pdo->prepare(
            "UPDATE vehicule
             SET statut = 'loue'
             WHERE id = :id"
        );

        $requeteVehiculeStatut->execute([
            ":id" => $vehiculeId
        ]);

    } elseif (
        $nouveauStatut === "terminee"
        || $nouveauStatut === "annulee"
    ) {

        // Vérifier qu'il n'existe plus d'autre location en cours.
        $requeteAutreLocation = $pdo->prepare(
            "SELECT id
             FROM location
             WHERE vehicule_id = :vehicule_id
               AND statut = 'en_cours'
             LIMIT 1"
        );

        $requeteAutreLocation->execute([
            ":vehicule_id" => $vehiculeId
        ]);

        // Libérer le véhicule uniquement s'il est encore marqué comme loué.
        if (
            !$requeteAutreLocation->fetch()
            && $vehicule["statut"] === "loue"
        ) {
            $requeteVehiculeStatut = $pdo->prepare(
                "UPDATE vehicule
                 SET statut = 'disponible'
                 WHERE id = :id"
            );

            $requeteVehiculeStatut->execute([
                ":id" => $vehiculeId
            ]);
        }
    }

    // Valider définitivement les modifications.
    $pdo->commit();

    // Préparer le message de confirmation.
    $messages = [
        "en_cours" => "demarrage",
        "terminee" => "terminee",
        "annulee" => "annulation"
    ];

    $message = $messages[$nouveauStatut];

    // Rediriger vers la liste des locations.
    header(
        "Location: ../../modules/locations/index.php?statut="
        . urlencode($message)
    );
    exit;

} catch (PDOException $erreur) {

    // Annuler la transaction en cas d'erreur SQL.
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }

    // Enregistrer les détails de l'erreur dans les journaux du serveur.
    error_log(
        "Erreur SQL lors du changement de statut de la location "
        . $id . " : " . $erreur->getMessage()
    );

    header(
        "Location: ../../modules/locations/index.php?erreur=technique"
    );
    exit;

} catch (RuntimeException $erreur) {

    // Annuler les modifications si une règle métier est violée.
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }

    // Enregistrer le motif du refus.
    error_log(
        "Changement de statut refusé pour la location "
        . $id . " : " . $erreur->getMessage()
    );

    header(
        "Location: ../../modules/locations/index.php?erreur=changement_refuse"
    );
    exit;
}
