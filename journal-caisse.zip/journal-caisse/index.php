
<?php

require_once __DIR__ . "/config/authentification.php";

// Vérifier que l'administrateur est connecté.
exiger_connexion();

// ==================================================
// 1. CHARGEMENT DES FICHIERS NÉCESSAIRES
// ==================================================

// Charger les protections de sécurité.
require_once __DIR__ . "/config/securite.php";

// Établir la connexion à la base de données.
require_once __DIR__ . "/config/connexion.php";

// Charger les fonctions communes, notamment e().
require_once __DIR__ . "/includes/fonctions.php";


// ==================================================
// 2. CALCUL DES INDICATEURS FINANCIERS
// ==================================================

// Calculer les recettes et les dépenses du jour,
// ainsi que celles du mois en cours.
$requeteFinances = $pdo->query("
    SELECT
        COALESCE(SUM(
            CASE
                WHEN type_operation = 'entree'
                AND date_operation = CURDATE()
                THEN montant
                ELSE 0
            END
        ), 0) AS recettes_jour,

        COALESCE(SUM(
            CASE
                WHEN type_operation = 'sortie'
                AND date_operation = CURDATE()
                THEN montant
                ELSE 0
            END
        ), 0) AS depenses_jour,

        COALESCE(SUM(
            CASE
                WHEN type_operation = 'entree'
                AND date_operation >= DATE_FORMAT(CURDATE(), '%Y-%m-01')
                AND date_operation < DATE_ADD(
                    LAST_DAY(CURDATE()),
                    INTERVAL 1 DAY
                )
                THEN montant
                ELSE 0
            END
        ), 0) AS recettes_mois,

        COALESCE(SUM(
            CASE
                WHEN type_operation = 'sortie'
                AND date_operation >= DATE_FORMAT(CURDATE(), '%Y-%m-01')
                AND date_operation < DATE_ADD(
                    LAST_DAY(CURDATE()),
                    INTERVAL 1 DAY
                )
                THEN montant
                ELSE 0
            END
        ), 0) AS depenses_mois,

        COALESCE(SUM(
            CASE
                WHEN type_operation = 'entree' THEN montant
                WHEN type_operation = 'sortie' THEN -montant
                ELSE 0
            END
        ), 0) AS solde_general

    FROM mouvement_caisse
");

// Récupérer les résultats de la requête.
$finances = $requeteFinances->fetch(PDO::FETCH_ASSOC);


// ==================================================
// 3. NOMBRE DE CLIENTS
// ==================================================

$nombreClients = (int) $pdo
    ->query("SELECT COUNT(*) FROM client")
    ->fetchColumn();


// ==================================================
// 4. ÉTAT DU PARC AUTOMOBILE
// ==================================================

// Compter les véhicules selon leur statut actuel.
$requeteVehicules = $pdo->query("
    SELECT
        COUNT(*) AS total_vehicules,

        COALESCE(SUM(
            CASE
                WHEN statut = 'disponible' THEN 1
                ELSE 0
            END
        ), 0) AS vehicules_disponibles,

        COALESCE(SUM(
            CASE
                WHEN statut = 'loue' THEN 1
                ELSE 0
            END
        ), 0) AS vehicules_loues,

        COALESCE(SUM(
            CASE
                WHEN statut = 'maintenance' THEN 1
                ELSE 0
            END
        ), 0) AS vehicules_maintenance

    FROM vehicule
");

$vehicules = $requeteVehicules->fetch(PDO::FETCH_ASSOC);


// ==================================================
// 5. SITUATION DES LOCATIONS
// ==================================================

// Compter les locations en cours et celles prévues.
$requeteLocations = $pdo->query("
    SELECT
        COALESCE(SUM(
            CASE
                WHEN statut = 'en_cours' THEN 1
                ELSE 0
            END
        ), 0) AS locations_en_cours,

        COALESCE(SUM(
            CASE
                WHEN statut = 'prevue' THEN 1
                ELSE 0
            END
        ), 0) AS locations_prevues

    FROM location
");

$locations = $requeteLocations->fetch(PDO::FETCH_ASSOC);


// ==================================================
// 6. PRÉPARATION DES MONTANTS À AFFICHER
// ==================================================

// Formater les montants en FCFA avec des espaces.
function formaterFCFA($montant): string
{
    return number_format((float) $montant, 0, ",", " ") . " FCFA";
}


// ==================================================
// 7. CHARGEMENT DE L'INTERFACE COMMUNE
// ==================================================

require_once __DIR__ . "/includes/header.php";
require_once __DIR__ . "/includes/sidebar.php";
?>

<div class="main-content">

    <!-- Titre principal du tableau de bord -->
    <h1 class="page-title">Tableau de bord</h1>

    <p class="page-description">
        Vue générale de votre activité de location de véhicules.
    </p>


    <!-- ==========================================
         8. INDICATEURS FINANCIERS DU JOUR
         ========================================== -->

    <h2>Situation financière du jour</h2>

    <div class="dashboard-grid">

        <div class="dashboard-card">
            <h3>Recettes du jour</h3>

            <p class="dashboard-number">
                <?= formaterFCFA($finances["recettes_jour"]) ?>
            </p>
        </div>

        <div class="dashboard-card">
            <h3>Dépenses du jour</h3>

            <p class="dashboard-number">
                <?= formaterFCFA($finances["depenses_jour"]) ?>
            </p>
        </div>

        <div class="dashboard-card">
            <h3>Solde général</h3>

            <p class="dashboard-number">
                <?= formaterFCFA($finances["solde_general"]) ?>
            </p>
        </div>

    </div>


    <!-- ==========================================
         9. INDICATEURS FINANCIERS DU MOIS
         ========================================== -->

    <h2>Situation financière du mois</h2>

    <div class="dashboard-grid">

        <div class="dashboard-card">
            <h3>Recettes du mois</h3>

            <p class="dashboard-number">
                <?= formaterFCFA($finances["recettes_mois"]) ?>
            </p>
        </div>

        <div class="dashboard-card">
            <h3>Dépenses du mois</h3>

            <p class="dashboard-number">
                <?= formaterFCFA($finances["depenses_mois"]) ?>
            </p>
        </div>

        <div class="dashboard-card">
            <h3>Résultat du mois</h3>

            <p class="dashboard-number">
                <?= formaterFCFA(
                    (float) $finances["recettes_mois"]
                    - (float) $finances["depenses_mois"]
                ) ?>
            </p>
        </div>

    </div>


    <!-- ==========================================
         10. INDICATEURS DES CLIENTS ET VÉHICULES
         ========================================== -->

    <h2>Clients et parc automobile</h2>

    <div class="dashboard-grid">

        <div class="dashboard-card">
            <h3>Clients enregistrés</h3>

            <p class="dashboard-number">
                <?= $nombreClients ?>
            </p>

            <a href="modules/clients/index.php">
                Voir les clients
            </a>
        </div>

        <div class="dashboard-card">
            <h3>Total des véhicules</h3>

            <p class="dashboard-number">
                <?= (int) $vehicules["total_vehicules"] ?>
            </p>

            <a href="modules/vehicules/index.php">
                Voir les véhicules
            </a>
        </div>

        <div class="dashboard-card">
            <h3>Véhicules disponibles</h3>

            <p class="dashboard-number">
                <?= (int) $vehicules["vehicules_disponibles"] ?>
            </p>
        </div>

        <div class="dashboard-card">
            <h3>Véhicules loués</h3>

            <p class="dashboard-number">
                <?= (int) $vehicules["vehicules_loues"] ?>
            </p>
        </div>

        <div class="dashboard-card">
            <h3>Véhicules en maintenance</h3>

            <p class="dashboard-number">
                <?= (int) $vehicules["vehicules_maintenance"] ?>
            </p>
        </div>

    </div>


    <!-- ==========================================
         11. INDICATEURS DES LOCATIONS
         ========================================== -->

    <h2>Suivi des locations</h2>

    <div class="dashboard-grid">

        <div class="dashboard-card">
            <h3>Locations en cours</h3>

            <p class="dashboard-number">
                <?= (int) $locations["locations_en_cours"] ?>
            </p>

            <a href="modules/locations/index.php">
                Voir les locations
            </a>
        </div>

        <div class="dashboard-card">
            <h3>Locations prévues</h3>

            <p class="dashboard-number">
                <?= (int) $locations["locations_prevues"] ?>
            </p>
        </div>

    </div>


    <!-- ==========================================
         12. ACCÈS RAPIDES AUX MODULES
         ========================================== -->

    <h2>Accès rapides</h2>

    <div class="dashboard-grid">

        <div class="dashboard-card">
            <h3>Clients</h3>
            <p>Enregistrer et consulter les clients.</p>

            <a href="modules/clients/index.php">
                Gérer les clients
            </a>
        </div>

        <div class="dashboard-card">
            <h3>Véhicules</h3>
            <p>Consulter et gérer le parc automobile.</p>

            <a href="modules/vehicules/index.php">
                Gérer les véhicules
            </a>
        </div>

        <div class="dashboard-card">
            <h3>Locations</h3>
            <p>Suivre les locations de véhicules.</p>

            <a href="modules/locations/index.php">
                Gérer les locations
            </a>
        </div>

        <div class="dashboard-card">
            <h3>Journal de caisse</h3>
            <p>Consulter les recettes et les dépenses.</p>

            <a href="modules/caisse/index.php">
                Ouvrir la caisse
            </a>
        </div>

        <div class="dashboard-card">
            <h3>Rapports financiers</h3>
            <p>Analyser les résultats de l'entreprise.</p>

            <a href="modules/rapports/index.php">
                Consulter les rapports
            </a>
        </div>

        <?php if (administrateur_principal()): ?>
            <div class="dashboard-card">
                <h3>Administrateurs</h3>
                <p>Gérer les comptes des administrateurs.</p>

                <a href="admin/administrateurs/index.php">
                    Gérer les administrateurs
                </a>
            </div>
        <?php endif; ?>

    </div>

</div>

<?php
// Charger le pied de page commun.
require_once __DIR__ . "/includes/footer.php";
?>
