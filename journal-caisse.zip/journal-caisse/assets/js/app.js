/*
 * Fonction principale exécutée immédiatement.
 * Elle permet de regrouper les variables et les fonctions
 * pour éviter de polluer l'espace global du JavaScript.
 */
(() => {
  // Récupérer le bouton qui permet d'ouvrir et de fermer le menu.
  const menuToggle = document.querySelector("[data-menu-toggle]");

  const profileMenu = document.querySelector("[data-profile-menu]");

  // Récupérer le fond situé derrière le menu lorsqu'il est ouvert.
  const backdrop = document.querySelector("[data-menu-backdrop]");

  /*
   * Ouvrir ou fermer le menu de navigation.
   * Le paramètre isOpen indique si le menu doit être ouvert (true)
   * ou fermé (false).
   */
  const setMenuOpen = (isOpen) => {
    // Ajouter ou retirer la classe CSS qui contrôle l'affichage du menu.
    document.body.classList.toggle("menu-open", isOpen);

    // Vérifier que le bouton du menu existe avant de le modifier.
    if (menuToggle) {
      // Informer les technologies d'assistance de l'état du menu.
      menuToggle.setAttribute("aria-expanded", String(isOpen));

      // Adapter le texte accessible du bouton selon l'état du menu.
      menuToggle.setAttribute(
        "aria-label",
        isOpen ? "Fermer le menu" : "Ouvrir le menu",
      );
    }
  };

  // Vérifier que le bouton d'ouverture du menu existe.
  if (menuToggle) {
    // Au clic, inverser l'état actuel du menu.
    menuToggle.addEventListener("click", () => {
      setMenuOpen(!document.body.classList.contains("menu-open"));
    });
  }

  // Vérifier que le fond derrière le menu existe.
  if (backdrop) {
    // Fermer le menu lorsque l'utilisateur clique sur ce fond.
    backdrop.addEventListener("click", () => setMenuOpen(false));
  }

  document.addEventListener("click", (event) => {
    if (profileMenu && !profileMenu.contains(event.target)) {
      profileMenu.open = false;
    }
  });

  // Sélectionner tous les liens du menu de navigation principal.
  document.querySelectorAll(".primary-nav .nav-link").forEach((link) => {
    // Fermer le menu lorsqu'un lien est sélectionné.
    link.addEventListener("click", () => setMenuOpen(false));
  });

  // Récupérer l'élément qui affiche le raccourci de recherche.
  const searchShortcut = document.querySelector("[data-search-shortcut]");

  // Sur Mac, afficher le symbole Commande (⌘) à la place du raccourci habituel.
  if (searchShortcut && navigator.platform.includes("Mac")) {
    searchShortcut.textContent = "⌘ K";
  }

  /*
   * Écouter les touches du clavier sur toute la page.
   * Deux raccourcis sont gérés :
   * - Échap (Escape) : fermer le menu.
   * - Ctrl + K ou Commande + K : accéder à la recherche.
   */
  document.addEventListener("keydown", (event) => {
    // Vérifier si l'utilisateur appuie sur la touche Échap.
    if (event.key === "Escape") {
      // Mémoriser si le menu était ouvert avant de le fermer.
      const menuWasOpen = document.body.classList.contains("menu-open");

      // Fermer le menu.
      setMenuOpen(false);

      // Si le menu était ouvert, replacer le curseur sur son bouton.
      if (menuWasOpen && menuToggle) {
        menuToggle.focus();
      }

      if (profileMenu && profileMenu.open) {
        profileMenu.open = false;
        profileMenu.querySelector("summary").focus();
      }
    }

    // Détecter Ctrl + K sur Windows/Linux ou Commande + K sur Mac.
    if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === "k") {
      // Récupérer le champ de recherche du tableau.
      const search = document.querySelector("[data-table-search]");

      // Si le champ existe, placer le curseur dedans.
      if (search) {
        // Empêcher le navigateur d'exécuter son raccourci par défaut.
        event.preventDefault();

        // Donner le focus au champ de recherche.
        search.focus();
      }
    }
  });

  // Récupérer le champ de recherche du tableau.
  const search = document.querySelector("[data-table-search]");

  // Exécuter la recherche uniquement si le champ existe.
  if (search) {
    // Relancer le filtrage à chaque modification du texte saisi.
    search.addEventListener("input", () => {
      // Récupérer le texte saisi, supprimer les espaces inutiles
      // au début et à la fin, puis convertir le texte en minuscules.
      const term = search.value.trim().toLocaleLowerCase("fr");

      // Récupérer toutes les lignes des tableaux de données.
      const rows = Array.from(
        document.querySelectorAll(".data-table tbody tr"),
      );

      // Exclure les lignes qui contiennent une cellule couvrant
      // plusieurs colonnes, car elles affichent généralement
      // un message comme « Aucune donnée disponible ».
      const dataRows = rows.filter((row) => !row.querySelector("td[colspan]"));

      // Récupérer le message qui indique qu'aucun résultat n'est trouvé.
      const status = document.querySelector("[data-search-empty]");

      // S'il n'y a aucune ligne de données, arrêter la recherche.
      if (dataRows.length === 0) {
        return;
      }

      // Compter le nombre de lignes correspondant à la recherche.
      let visibleRows = 0;

      // Parcourir les lignes du tableau une par une.
      dataRows.forEach((row) => {
        // Vérifier si le texte de la ligne contient le terme recherché.
        const matches = row.textContent.toLocaleLowerCase("fr").includes(term);

        // Masquer la ligne si elle ne correspond pas à la recherche.
        row.hidden = !matches;

        // Ajouter une unité au compteur si la ligne correspond.
        visibleRows += matches ? 1 : 0;
      });

      // Si le message « aucun résultat » existe déjà,
      // l'afficher uniquement si la recherche est non vide
      // et qu'aucune ligne ne correspond.
      if (status) {
        status.hidden = term === "" || visibleRows > 0;
      } else if (term !== "" && visibleRows === 0) {
        // Récupérer le conteneur du tableau.
        const tableContainer = document.querySelector(".table-container");

        // Vérifier que le conteneur existe avant d'ajouter le message.
        if (tableContainer) {
          // Créer un paragraphe pour signaler l'absence de résultats.
          const emptyStatus = document.createElement("p");

          // Ajouter une classe CSS pour personnaliser son apparence.
          emptyStatus.className = "table-search-empty";

          // Ajouter un attribut permettant de retrouver ce message.
          emptyStatus.dataset.searchEmpty = "";

          // Permettre aux technologies d'assistance d'annoncer le message.
          emptyStatus.setAttribute("role", "status");

          // Définir le texte affiché à l'utilisateur.
          emptyStatus.textContent = "Aucun résultat pour cette recherche.";

          // Insérer le message juste après le tableau.
          tableContainer.insertAdjacentElement("afterend", emptyStatus);
        }
      }
    });
  }
})();
